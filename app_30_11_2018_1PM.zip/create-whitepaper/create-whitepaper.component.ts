import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';
import { CustomValidator } from '../custom/validation';
import { Press } from './press';
import { Files } from './files';
declare var $;
let uniqueId = 0;
@Component({
  selector: 'app-create-whitepaper',
  templateUrl: './create-whitepaper.component.html',
  styleUrls: ['./create-whitepaper.component.css']
})
export class CreateWhitepaperComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;	
	selectedFile:any =  null;
	pdfFile:any =  null;	
	ticket: any	=	'';
	public loading = false;
	readtextfile:any ='';
	filetextcode:any ='';
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	error:any 	=	'';
	success:any 	=	'';
	filetextsinglecode:any ='';
	fileImagetextcode:Array<String>	=	new Array<String>();
	currentFile:any ='';
	pressArray:Array<Press>=new Array<Press>();
	selectedImageFile:Array<Files>=new Array<Files>();
	currentMp4File:any ='';
	selectedMp4File:Array<Files>=new Array<Files>();
	fileMp4textcode:Array<String>	=	new Array<String>();
	currentOggFile:any ='';
	selectedOggFile:Array<Files>=new Array<Files>();
	fileOggtextcode:Array<String>	=	new Array<String>();
	currentWebmFile:any ='';
	selectedWebmFile:Array<Files>=new Array<Files>();
	fileWebmtextcode:Array<String>	=	new Array<String>();
	
	
	
	
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	    var username	=	localStorage.hasOwnProperty("username");
			if(!username){
				//this.router.navigate(['']);
			}
			
	}

	ngOnInit() {
	}
	  
  	onSubmit() {
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		 this.errors.pdf_file = '';
		   if(CustomValidator.emptyValidation(this.pdfFile)===false){
		     this.errors.pdf_file = 'PDF is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			     this.errors.pdf_file = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }  
		var arrFile = new Array();
			console.log(this.pressArray);
			console.log(this.fileMp4textcode);
			console.log(this.fileOggtextcode);
			console.log(this.fileWebmtextcode);
			return false;
			var error_flag = 0;
		 this.pressArray.forEach(function(field_value, field_index){
		     if(field_value.type==2){
			    arrFile.push(field_value.id);
			 }else{
			 // Type ckEditor
			     $('#ckeditor_error_'+field_value.id).html('');
				 if(CustomValidator.emptyValidation(field_value.data.Content)===false){
				   $('#ckeditor_error_'+field_value.id).html('This field is required.');
				     error_flag = 1;
				 }
			 
			 }
		
		 });
		 /*  Image Validation */
		 if (this.selectedImageFile.length === 0) {
			   let all_files 	=	this.pressArray; 
			   
			   arrFile.forEach(function(v, k){
				   all_files.forEach(function(field_value, field_index){
						if(field_value.type==2){
							if(field_value.data.ImageHref==undefined && field_value.id==v){
								$('#image_error_'+v).html('This field is required.');
								error_flag = 1;
							}
						}
					
					})
				   
		 	    
			   });
 
         }else{
				this.selectedImageFile.forEach(function(value, key) {
					  $('#image_error_'+value.id).html('');
					 if(CustomValidator.imageExtensionValidation(value.file)===false){
					 
						$('#image_error_'+value.id).html('Wrong format file.');
						error_flag = 1;
						
					  }
				
				});
		} 
		if(error_flag ==1){
			  return false;
		}
		
		this.CreateWhitePaper();
	  }  
  
  CreateWhitePaper() {
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			
			// create the Sub Content Block
			let content_blocks	=	[];
			let upload_file_code	=	this.fileImagetextcode;
			var formData:any 	=	"";
			var current_model_data 	=	this.data;
			var current_model 	=	this.model;
			var restAPI 	=	this.rest;
			var this_object 	=	this;
			this_object.loading = true;
			this.pressArray.forEach(function(field_value, field_index){
				var file_number:number 	=	Number(field_value.id);
				if(field_value.type==2){  
					// Image Block
					var file_name 	=	'';
					var foldername 	=	'';
					var filedata 	=	'';
					var href 		=	'';			
					
					var new_image 	=	0;
					upload_file_code.forEach(function(image_value, image_index){
						var current_file_number:number	=	Number(image_value[0]);
						
							if(file_number==current_file_number){
								file_name 	=	image_value[2];
								foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
								filedata 	=	image_value[1];
								href 		=	'';
								new_image 	=	1;
							}
						});
					if(new_image==0){
						file_name 	=	field_value.data.ImageFile.blobValue.filename;
						foldername 	=	field_value.data.ImageFile.blobValue.foldername;
						filedata 	=	field_value.data.ImageFile.blobValue.filedata;
						href 		=	field_value.data.ImageFile.blobValue.href;
						
					}
					var zoom_image 	=	"";
					if(field_value.data.ZoomImage){
						zoom_image 	=	"Yes";
					}else{
						zoom_image 	=	"No";
					}
					if(field_value.data.id==undefined){
						formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_ContentImageLayout"}}, {"name":"ImageFile","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Alt","data":{"stringValue":field_value.data.Alt}},{"name":"Tooltip","data":{"stringValue":field_value.data.Tooltip}}, {"name":"ZoomImage","data":{"stringValue":zoom_image}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_ContentImage", "createdby":current_model_data.createdby }
					}else{
						formData 	=	{"attribute":[{"name":"id", "data":{"longValue":field_value.data.id}}, {"name":"template","data":{"stringValue":"Hub_ContentImageLayout"}}, {"name":"ImageFile","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Alt","data":{"stringValue":field_value.data.Alt}},{"name":"Tooltip","data":{"stringValue":field_value.data.Tooltip}}, {"name":"ZoomImage","data":{"stringValue":zoom_image}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "id":'Hub_PageBlock_C:'+field_value.data.id, "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_ContentImage", "createdby":current_model_data.createdby }
					}
					
					
					
				}else if(field_value.type==3){
					
					
					
					
				}else{
					// Content Block
					
					if(field_value.data.id==undefined){
						formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_ContentLayout"}}, {"name":"Content","data":{"stringValue":field_value.data.Content}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_Content", "createdby":current_model_data.createdby }
					}else{
						formData 	=	{"attribute":[{"name":"id", "data":{"longValue":field_value.data.id}}, {"name":"template","data":{"stringValue":"Hub_ContentLayout"}}, {"name":"Content","data":{"stringValue":field_value.data.Content}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "id":'Hub_PageBlock_C:'+field_value.data.id, "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_Content", "createdby":current_model_data.createdby }
					}
					
					
				}
				
				// call the Rest API for add the Content Block
				var id  	=	0;
				if(field_value.data.id!=undefined){
					id 	=	field_value.data.id;
				}
					restAPI.CallAddPageBlock(formData, '', id).subscribe(response2 => {
						content_blocks.push(response2.id);
						
					});
			 });
			 var total_wait 	=	30000*this.pressArray.length;
			
			setTimeout(function(){
					this_object.data.FeaturedWhitePaper 		    = 	'No';
					if(this_object.model.FeaturedWhitePaper){		
					  this_object.data.FeaturedWhitePaper 		= 	'Yes';	
					}
					//add timestamp in file name
					var unix = Math.round(+new Date()/1000);
					var file_name 	=	this_object.selectedFile.name;
					let file_nameArray = file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					var file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;	
					
					//add timestamp in PDF file name
					var unix_pdf = Math.round(+new Date()/1000);			
					var file_name_pdf 	=	this_object.pdfFile.name;
					let file_name_pdfArray = file_name_pdf.split(".");
					file_name_pdfArray.reverse();
					let file_ext_pdf 	=	file_name_pdfArray[0];
					file_name_pdfArray.splice(0, 1);
					file_name_pdfArray.reverse();
					var file_name_pdf	=	file_name_pdfArray.join("-");
					var new_file_name_pdf 	=	file_name_pdf+"-"+unix_pdf+"."+file_ext_pdf;
					
						
					
					
					// create an array of Tags.
					let selected_tags 	=	this_object.model.page_tags;
					let tags_array 		=	'';
					if (selected_tags.indexOf(",") !=-1) {
						tags_array 		=	selected_tags.split(",");
					}else{
						tags_array	=	selected_tags;
					}
					
					let formWhitepaperData 	=	{"attribute":[{"name":"template","data":"Hub_WhitePaperSectionLayout"}, {"name":"PageTitle","data":{"stringValue":this_object.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this_object.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this_object.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this_object.model.PageName}}, {"name":"PageID","data":{"stringValue": this_object.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedWhitePaper","data":{"stringValue": this_object.data.FeaturedWhitePaper}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":new_file_name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this_object.readtextfile,"href":""}}}, {"name":"ThumbnailAlt","data":{"stringValue":this_object.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this_object.model.ThumbnailTooltip}}, {"name":"CreatedDate","data":{"dateValue":this_object.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this_object.model.Title}}, {"name":"SubTitle","data":{"stringValue":this_object.model.SubTitle}}, {"name":"PDF","data":{"blobValue":{"filename":new_file_name_pdf,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this_object.readtextpdffile,"href":""}}}, {"name":"PDFTitle","data":{"stringValue":this_object.model.PDFTitle}}, {"name":"Author","data":{"stringValue":this_object.model.Author}}, {"name":"Contributors","data":{"stringValue":this_object.model.Contributors}}, {"name":"ShortDescription","data":{"stringValue":this_object.model.ShortDescription}}, {"name":"Abstract","data":{"stringValue":this_object.model.Abstract}}, {"name":"TableOfContents","data":{"stringList":content_blocks}}, {"name":"Footnote","data":{"stringValue":this_object.model.Footnote}}, {"name":"EmailSubject","data":{"stringValue":this_object.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this_object.model.EmailBody}}, {"name":"name", "data":{"stringValue":this_object.model.name}}, {"name":"createdby", "data":{"stringValue":this_object.data.createdby}}], "name":this_object.model.name, "createdby":this_object.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_WhitePaperSection", "createddate": this_object.model.CreatedDate }
					
					
					this_object.rest.AddHubWhitePaper(formWhitepaperData, this_object.ticket).subscribe(response2 => {
							this_object.loading = false;
							localStorage.setItem("success_msg", "Your Whitepaper has been created successfully.");
							let idString =	response2.id;
							let idArray = idString.split(":");
							let id 	=	idArray[1];
							this_object.loading = false;
							this_object.router.navigate(['/edit_whitepaper/'+id]);

						}, error => {
							this_object.loading = false;
								//localStorage.setItem("error_msg", "You are not authorize to access this.");
								//this.router.navigate(['/create-edit-content']);
							});
				
				
				
			}, total_wait);
			
			
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
  }
  
  onFileSelected(event){
         this.selectedFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
				
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  
	  onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextpdffile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
	  
	  
	  
	  textAdd(block_type){
		 var press: Press  = new Press(uniqueId++,'',block_type,[0, '', '', '', '', '']);
		 this.pressArray.push(press);
	  }

	  deletePress(index:any){
		this.pressArray.splice(index,1);

	  }
	  
	  clickUpload(id){
		 $('#'+id).trigger('click');
	  }
	  
	   onImageFileSelected(event,id){
			var index = null;
			this.currentFile = event.target.files[0];
			var file_data: Files  = new Files(id, <File>event.target.files[0]);
			
			var file_data_encode:any	=	new Array();
			 let fileReader = new FileReader();
				fileReader.onload = (e) => {			
					let string:any;
					string		=	fileReader.result;
					var solution	=	string.split("base64,");
					var unix = Math.round(+new Date()/1000);
					var old_file_name 	=	this.currentFile.name;
					let file_nameArray = old_file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					var file_name 	=	'';
					file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;				
					file_data_encode 	=	[id, solution[1], new_file_name];
					this.fileImagetextcode.push(file_data_encode);
				}
				//this.fileImagetextcode	=	fileReader.readAsText(this.selectedFile);
				this.filetextsinglecode	=	fileReader.readAsDataURL(this.currentFile);
				 this.selectedImageFile.forEach(function(value,key) {
					if (value.id == id){
						index = key;
					}
				});
				if(index != null){
				   this.selectedImageFile.splice(index,1);
				   //this.fileImagetextcode.splice(index,1);
				}
				
			   this.selectedImageFile.push(file_data);
			 $('#image_'+id).html(event.target.files[0].name);
		}
		
		
	  selectOption(selet_option){
		  var textValue = $('#'+selet_option).text();
		  //this.model.video_type = textValue;
							
			$('.youtube-video').hide();
			$('.video-url').hide();
			$('.video-set').hide();
			switch(selet_option){
				case 'YouTube ID':
					$(".youtube-video").show();
					break;
				case 'Internal Video':
					$(".video-set").show();
					break;
				case 'External Video URL':
					$(".video-url").show();
					break;
				
			}
	  }
  
	onVideoMp4(event, id){
         
		 var index = null;
			this.currentMp4File = event.target.files[0];
			var file_data: Files  = new Files(id, <File>event.target.files[0]);
			
			var file_data_encode:any	=	new Array();
			 let fileReader = new FileReader();
				fileReader.onload = (e) => {			
					let string:any;
					string		=	fileReader.result;
					var solution	=	string.split("base64,");
					var unix = Math.round(+new Date()/1000);
					var old_file_name 	=	this.currentMp4File.name;
					let file_nameArray = old_file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					var file_name 	=	'';
					file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;				
					file_data_encode 	=	[id, solution[1], new_file_name];
					this.fileMp4textcode.push(file_data_encode);
				}
				//this.fileImagetextcode	=	fileReader.readAsText(this.selectedFile);
				this.filetextsinglecode	=	fileReader.readAsDataURL(this.currentMp4File);
				 this.selectedMp4File.forEach(function(value,key) {
					if (value.id == id){
						index = key;
					}
				});
				if(index != null){
				   this.selectedMp4File.splice(index,1);
				   //this.fileImagetextcode.splice(index,1);
				}
				
			   this.selectedMp4File.push(file_data);
			 $('#mp4_'+id).html(event.target.files[0].name);
	  }
	  
	  onVideoOgg(event, id){
        var index = null;
			this.currentOggFile = event.target.files[0];
			var file_data: Files  = new Files(id, <File>event.target.files[0]);
			
			var file_data_encode:any	=	new Array();
			 let fileReader = new FileReader();
				fileReader.onload = (e) => {			
					let string:any;
					string		=	fileReader.result;
					var solution	=	string.split("base64,");
					var unix = Math.round(+new Date()/1000);
					var old_file_name 	=	this.currentOggFile.name;
					let file_nameArray = old_file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					var file_name 	=	'';
					file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;				
					file_data_encode 	=	[id, solution[1], new_file_name];
					this.fileOggtextcode.push(file_data_encode);
				}
				//this.fileImagetextcode	=	fileReader.readAsText(this.selectedFile);
				this.filetextsinglecode	=	fileReader.readAsDataURL(this.currentOggFile);
				 this.selectedOggFile.forEach(function(value,key) {
					if (value.id == id){
						index = key;
					}
				});
				if(index != null){
				   this.selectedOggFile.splice(index,1);
				   //this.fileImagetextcode.splice(index,1);
				}
				
			   this.selectedOggFile.push(file_data);
			 $('#ogg_'+id).html(event.target.files[0].name);
	  }
	  
	  onVideoWebm(event, id){
        var index = null;
			this.currentWebmFile = event.target.files[0];
			var file_data: Files  = new Files(id, <File>event.target.files[0]);
			
			var file_data_encode:any	=	new Array();
			 let fileReader = new FileReader();
				fileReader.onload = (e) => {			
					let string:any;
					string		=	fileReader.result;
					var solution	=	string.split("base64,");
					var unix = Math.round(+new Date()/1000);
					var old_file_name 	=	this.currentWebmFile.name;
					let file_nameArray = old_file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					var file_name 	=	'';
					file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;				
					file_data_encode 	=	[id, solution[1], new_file_name];
					this.fileWebmtextcode.push(file_data_encode);
				}
				//this.fileImagetextcode	=	fileReader.readAsText(this.selectedFile);
				this.filetextsinglecode	=	fileReader.readAsDataURL(this.currentWebmFile);
				 this.selectedWebmFile.forEach(function(value,key) {
					if (value.id == id){
						index = key;
					}
				});
				if(index != null){
				   this.selectedWebmFile.splice(index,1);
				   //this.fileImagetextcode.splice(index,1);
				}
				
			   this.selectedWebmFile.push(file_data);
			 $('#webm_'+id).html(event.target.files[0].name);
	  }

}
