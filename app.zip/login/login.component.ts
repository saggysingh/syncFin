import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
		data:any;
		errors:any;
		model: any = {};
		global: string = "";
		
	  constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
		this.data 					= {};
		this.errors 				= {};
		
	  }
	ngOnInit() {
		
	}
	onSubmit() {
		this.data.username 			= 	this.model.username;	
		this.data.password 			= 	this.model.password;	
		this.getLogin();
	  }  
  
  getLogin() {
	this.rest.CallLogin(this.data).subscribe(response => {
		console.log(response);
		if(response.error==1){
			this.global 	=	response.msg;
			
		}else{
			console.log(response.msg);
				if (typeof(Storage) !== "undefined"){
                     localStorage.setItem("UserId", response.msg.id);
                     localStorage.setItem("UserName", response.msg.Name);
                } else {
                  // Sorry! No Web Storage support..
                }
			this.router.navigate(['/dashboard']);
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  

}
