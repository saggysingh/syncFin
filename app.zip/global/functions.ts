export class Functions {

 static getExtractData(ObjData): any{
         var retrunData = new Array();
         var obj =   ObjData.assetinfo;
		 
         obj.forEach(function(value, index){
			var obj2 = value.fieldinfo;
			var fields_array:any = [];
			fields_array['id']	= value.id;	
			fields_array['href']	= value.href;	
			obj2.forEach(function(fields, key){
				fields_array[fields.fieldname]	= fields.data;	
		    });
			retrunData.push(fields_array); 
	   
	    });
   return retrunData;
  
  } 

  


}