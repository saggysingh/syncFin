export class Press {

  constructor(
    public id: number,
	public name: string,
	public type: number
   ) {  }

}