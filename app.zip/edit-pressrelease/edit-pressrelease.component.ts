import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { News } from '../model/news_model';
declare var $;

@Component({
  selector: 'app-edit-pressrelease',
  templateUrl: './edit-pressrelease.component.html',
  styleUrls: ['./edit-pressrelease.component.css']
})
export class EditPressreleaseComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	selectedFile:any =  null;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	   
	    this.model = new News('', '', '', '', '', '', 'Press', '', '', '', '', '', '', '', '', ''); 
	}

	ngOnInit() {
	  this.GetTag();
	}
	  
  	onSubmit() {
	
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		if(error_flag ==1){
			  return false;
		}
	
	

	    this.data.api_type 			    = 	'Login';	
	    this.data.createdby             = localStorage.getItem("UserName");
		this.data.PageTitle 			= 	this.model.page_title;
	    this.data.PageMetaDescription 	= 	this.model.page_description;
        this.data.PageKeywords 			= 	this.model.page_keywords;
	    this.data.PageName 			    = 	this.model.page_name;			
		this.data.PageID 		        = 	this.model.page_id;
        this.data.CustomTags 			= 	this.model.page_tags;			
        this.data.NewsType 			    = 	'Press';
		this.data.FeaturedNews 		    = 	'no';
        if(this.model.featured===true){		
		  this.data.FeaturedNews 		= 	'yes';	
		}
		this.data.ThumbnailImage 		= 	btoa(this.selectedFile);	
		this.data.ThumbnailTooltip 		= 	this.model.thumb_title;	
		this.data.ThumbnailAlt 			= 	this.model.thumb_alt;	
		this.data.CreatedDate 			= 	this.model.creation_date;	
		this.data.Title 			    = 	this.model.post_title;	
		this.data.ShortDescription 		= 	this.model.short_description;	
		this.data.NewsContent 			= 	this.model.content;	
		this.data.EmailSubject 			= 	this.model.email_subject;	
		this.data.EmailBody 			= 	this.model.email_body;	
		
        //console.warn(this.data); return false;
		
		this.EditTag();
	  } 

	GetTag() {
		this.rest.CallGetPressrelease(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				this.model	= response.data;
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}  	  
  
	EditTag() {
		this.rest.CallEditPressrelease(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				console.log(response.msg);
				this.router.navigate(['/dashboard']);
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}
	
	DeleteTag(){
		if(confirm("Are you sure to delete Press release")) {
			this.rest.CallDeletePressrelease(this.data).subscribe(response => {
				if(response.error==1){
					this.errors 	=	response.error;
					console.log(this.errors);
				}else{
					console.log(response.msg);
					this.router.navigate(['/dashboard']);
				}

			}, error => {
					alert("Server Busy, Please try again later.");
				});
		}
	}
  
 
  	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//SAVE button functionality
				   //APPROVE button functionality
					approveButton.click(function(event) {
						event.preventDefault();
						previewButton.removeClass('inactive');
						deleteButton.addClass('inactive');
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}
	
	 onFileSelected(event){
          //console.log(event);
	     this.selectedFile = event.target.files[0];
	     $('#image-1').html(this.selectedFile.name);
	  }


}
