import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { News } from '../model/news_model';
import { Functions } from '../global/functions';
declare var $;
@Component({
  selector: 'app-create_pressrelease',
  templateUrl: './create_pressrelease.component.html',
  styleUrls: ['./create_pressrelease.component.css']
})
export class CreatePressreleaseComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	ticket:any	=	'';
	selectedFile:any =  null;
	public loading = false;
	readtextfile:any='';
	filetextcode:any='';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	   
	   
	  this.model = new News('', '', '', '', '', '', 'Press', '', '', '', '', '', '', '', '', ''); 
	  var username	=	localStorage.hasOwnProperty("username");
			if(!username){
				this.router.navigate(['']);
			}
	} 

	ngOnInit() {}
	  
  	onSubmit() {
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		if(error_flag ==1){
			  return false;
		} 
	    this.CreatePressrelease();
	  }  
  
  CreatePressrelease() {
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedNews 		    = 	'No';
			if(this.model.FeaturedNews){		
			  this.data.FeaturedNews 		= 	'Yes';	
			}
			
			
			
			var formData 	=	{"attribute":[{"name":"template","data":{"stringValue":this.model.template}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":this.model.page_tags}},{"name":"NewsType","data":{"stringValue":"Press Release"}},{"name":"FeaturedNews","data":{"stringValue": this.data.FeaturedNews}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":this.selectedFile.name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextfile,"href":""}}}, {"name":"ThumbnailAlt","data":{"stringValue":this.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this.model.ThumbnailTooltip}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"NewsContent","data":{"stringValue":this.model.NewsContent}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}},{"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_NewsPostSection" , "createddate": this.model.CreatedDate}
			this.rest.CallAddPressrelease(formData, this.ticket).subscribe(response2 => {
					localStorage.setItem("success_msg", "Your Press Release has been created successfully.");
					this.loading = false;
					this.router.navigate(['/create-edit-content']);

				}, error => {
					this.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
  }
  
  	  onFileSelected(event){
         
	     this.selectedFile = event.target.files[0];
		
		  let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				this.readtextfile	=	fileReader.result;
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  


}
