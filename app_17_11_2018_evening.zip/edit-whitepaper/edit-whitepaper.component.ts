import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';
import { CustomValidator } from '../custom/validation';
declare var $;

@Component({
  selector: 'app-edit-whitepaper',
  templateUrl: './edit-whitepaper.component.html',
  styleUrls: ['./edit-whitepaper.component.css']
})
export class EditWhitepaperComponent implements OnInit {

model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;	
	selectedFile:any =  null;
	pdfFile:any =  null;
	id: any;
	sub: any;
	ticket: any	=	'';
	public loading = false;
	readtextfile:any ='';
	filetextcode:any ='';
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	}

	ngOnInit() {
	  this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetWhitepapaer();
		});
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
		localStorage.removeItem("success_msg");
		localStorage.removeItem("error_msg");
	}
	  
  	onSubmit() {
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     //this.errors.thumbnail_image = 'Thumbnail image is required'; 
		     // error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		 this.errors.pdf_file = '';
		   if(CustomValidator.emptyValidation(this.pdfFile)===false){
		    // this.errors.pdf_file = 'PDF file is required'; 
		    //  error_flag = 1;
		   }else{
		       if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			     this.errors.pdf_file = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }  
		   
		   
		if(error_flag ==1){
			  return false;
		}
		
		this.EditWhitePaper();
	  } 

	GetWhitepapaer() {
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
				this.rest.CallGetWhitePaper(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					this.model.name 				=	response2.name;
					this.model.template 			=	fields.template.stringValue;
					this.model.PageTitle 			=	fields.PageTitle.stringValue;
					this.model.PageMetaDescription 				=	'';
					if(fields.PageMetaDescription!=null){
						this.model.PageMetaDescription 		=	fields.PageMetaDescription.stringValue;
					}
					this.model.PageKeywords 				=	'';
					if(fields.PageKeywords!=null){
						this.model.PageKeywords 		=	fields.PageKeywords.stringValue;
					}
					this.model.PageName 				=	'';
					if(fields.PageName!=null){
						this.model.PageName 			=	fields.PageName.stringValue;
					}
					this.model.PageID 				=	'';
					if(fields.PageID!=null){
						this.model.PageID 			=	fields.PageID.stringValue;
					}
					if(fields.CustomTags!=null){
						let selected_tags	=	fields.CustomTags;
							selected_tags	=	selected_tags.stringList;
						this.model.page_tags 		=	selected_tags.join(",");
						this.model.selected_tags 				=	selected_tags;
						
					}else{
						this.model.page_tags 				=	'';
					}
					if(fields.FeaturedWhitePaper!=null){
						this.model.FeaturedWhitePaper 	=	0;
						var str = fields.FeaturedWhitePaper.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.FeaturedWhitePaper	=	1;
						}
						
					}else{
						this.model.FeaturedWhitePaper 				=	0;
					}
					if(fields.ThumbnailImage!=null){
						this.model.thumb_image 			=	fields.ThumbnailImage.blobValue.href;
						this.data.ThumbnailImage 			=	fields.ThumbnailImage.blobValue;
						
					}else{
						this.model.thumb_image 			=	'';
					}
					if(fields.ThumbnailAlt!=null){
						this.model.ThumbnailAlt 			=	fields.ThumbnailAlt.stringValue;
						
					}else{
						this.model.ThumbnailAlt 			=	'';
					}
					
					if(fields.ThumbnailTooltip!=null){
						this.model.ThumbnailTooltip 			=	fields.ThumbnailTooltip.stringValue;
						
					}else{
						this.model.ThumbnailTooltip 			=	'';
					}
					if(fields.CreatedDate!=null){
						this.model.CreatedDate 			=	fields.CreatedDate.dateValue;
						
					}else{
						this.model.CreatedDate 			=	'';
					}
					if(fields.Title!=null){
						this.model.Title 			=	fields.Title.stringValue;
						
					}else{
						this.model.Title 			=	'';
					}
					if(fields.SubTitle!=null){
						this.model.SubTitle 			=	fields.Title.stringValue;
						
					}else{
						this.model.SubTitle 			=	'';
					}
					
					if(fields.PDF!=null){
						this.model.pdf_file 			=	fields.PDF.blobValue.href;
						this.data.PDF 					=	fields.PDF.blobValue;
						
					}else{
						this.model.pdf_file 			=	'';
					}
					if(fields.PDFTitle!=null){
						this.model.PDFTitle 			=	fields.PDFTitle.stringValue;
						
					}else{
						this.model.PDFTitle 			=	'';
					}					
					if(fields.Author!=null){
						this.model.Author 			=	fields.Author.stringValue;
						
					}else{
						this.model.Author 			=	'';
					}					
					if(fields.Contributors!=null){
						this.model.Contributors 			=	fields.Contributors.stringValue;
						
					}else{
						this.model.Contributors 			=	'';
					}					
					if(fields.ShortDescription!=null){
						this.model.ShortDescription 			=	fields.ShortDescription.stringValue;
						
					}else{
						this.model.ShortDescription 			=	'';
					}					
					if(fields.Abstract!=null){
						this.model.Abstract 			=	fields.Abstract.stringValue;
						
					}else{
						this.model.Abstract 			=	'';
					}					
					if(fields.TableOfContents!=null){
						this.model.TableOfContents 			=	fields.TableOfContents.stringList;
						
					}else{
						this.model.TableOfContents 			=	'';
					}					
					if(fields.Footnote!=null){
						this.model.Footnote 			=	fields.Footnote.stringValue;
						
					}else{
						this.model.Footnote 			=	'';
					}
					if(fields.EmailSubject!=null){
						this.model.EmailSubject 			=	fields.EmailSubject.stringValue;
						
					}else{
						this.model.EmailSubject 			=	'';
					}
					if(fields.EmailBody!=null){
						this.model.EmailBody 			=	fields.EmailBody.stringValue;
						
					}else{
						this.model.EmailBody 			=	'';
					}
					
					
				}, error => {
				//this.router.navigate(['']);
			});
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
	}  	  
  
	EditWhitePaper() {
		this.loading = true;
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedWhitePaper 		    = 	'No';
			if(this.model.FeaturedWhitePaper){		
			  this.data.FeaturedWhitePaper 		= 	'Yes';	
			}
			this.data.id 	=	Number(this.data.id);
			
			// Condition for thumbnail image
			var file_name 	=	'';
			var foldername 	=	'';
			var filedata 	=	'';
			var href 	=	'';
			if(CustomValidator.emptyValidation(this.selectedFile)===false){
				file_name 	=	this.data.ThumbnailImage.filename;
				foldername 	=	this.data.ThumbnailImage.foldername;
				filedata 	=	this.data.ThumbnailImage.filedata;
				href 	=	this.data.ThumbnailImage.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				
				var unix = Math.round(+new Date()/1000);
				var old_file_name 	=	this.selectedFile.name;
				let file_nameArray = old_file_name.split(".");
				file_nameArray.reverse();
				let file_ext 	=	file_nameArray[0];
				file_nameArray.splice(0, 1);
				file_nameArray.reverse();
				file_name	=	file_nameArray.join("-");
				var new_file_name 	=	file_name+"-"+unix+"."+file_ext;
				file_name 	=	new_file_name;
				foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
				filedata 	=	this.readtextfile;
				href 		=	'';
			}
			
			// Condition for PDF file
			var file_name_pdf 	=	'';
			var foldername_pdf 	=	'';
			var filedata_pdf 	=	'';
			var href_pdf 	=	'';
			if(CustomValidator.emptyValidation(this.pdfFile)===false){
				file_name_pdf 	=	this.data.PDF.filename;
				foldername_pdf 	=	this.data.PDF.foldername;
				filedata_pdf 	=	this.data.PDF.filedata;
				href_pdf 	=	this.data.PDF.href;
			}else{
				
				var unix_pdf = Math.round(+new Date()/1000);
				var old_file_name_pdf 	=	this.pdfFile.name;
				let file_name_pdfArray = old_file_name_pdf.split(".");
				file_name_pdfArray.reverse();
				let file_ext_pdf 	=	file_name_pdfArray[0];
				file_name_pdfArray.splice(0, 1);
				file_name_pdfArray.reverse();
				file_name_pdf	=	file_name_pdfArray.join("-");
				var new_file_name_pdf 	=	file_name_pdf+"-"+unix_pdf+"."+file_ext_pdf;
				file_name_pdf 	=	new_file_name_pdf;
				foldername_pdf 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
				filedata_pdf 	=	this.readtextpdffile;
				href_pdf 		=	'';
			}
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			
			let formData 	=	{"attribute":[{"name":"id", "data":{"longValue":this.data.id}}, {"name":"template","data":"Hub_WhitePaperSectionLayout"}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedWhitePaper","data":{"stringValue": this.data.FeaturedWhitePaper}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"ThumbnailAlt","data":{"stringValue":this.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this.model.ThumbnailTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"PDF","data":{"blobValue":{"filename":file_name_pdf,"foldername":foldername_pdf,"filedata": filedata_pdf,"href":href_pdf}}}, {"name":"PDFTitle","data":{"stringValue":this.model.PDFTitle}}, {"name":"Author","data":{"stringValue":this.model.Author}}, {"name":"Contributors","data":{"stringValue":this.model.Contributors}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Abstract","data":{"stringValue":this.model.Abstract}}, {"name":"TableOfContents","data":{"stringList":this.model.TableOfContents}}, {"name":"Footnote","data":{"stringValue":this.model.Footnote}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "id":'Hub_WhitePaper_C:'+this.data.id, "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_WhitePaperSection", "createddate": this.model.CreatedDate }
			
			
				this.rest.EditHubWhitePaper(formData, this.ticket, this.data).subscribe(response2 => {
							this.loading = false;
							this.success 	=	"Your Whitepaper has been updated successfully.";

							}, error => {
									this.loading = false;
									//localStorage.setItem("error_msg", "You are not authorize to access this.");
									//this.router.navigate(['/create-edit-content']);
								});
					}, error => {
							this.loading = false;
							this.router.navigate(['']);
					});
				}, error => {
						this.loading = false;
						this.router.navigate(['']);
				});
	}
  	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});
					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}
	
	onFileSelected(event){
         this.selectedFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  
	  onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextpdffile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
	  
	  
	  DeleteWhitepaper(){
		if(confirm("Are you sure to delete Whitepaper")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.DeleteWhitepaper(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						localStorage.setItem("success_msg", "Your whitepaper has been deleted successfully.");
						this.router.navigate(['/create-edit-content']);

					}, error => {
						this.loading = false;
							localStorage.setItem("error_msg", "You are not authorize to access this.");
							this.router.navigate(['/create-edit-content']);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
		}
	}
	
	ApproveAsset(){
		 if(confirm("Are you sure to Approve Whitepaper?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallApproveAsset(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						this.success 	=	"Your Whitepaper has been approved successfully.";
						//localStorage.setItem("success_msg", "Your press release has been approve successfully.");
						this.router.navigate(['/edit_whitepaper/'+this.data.id]);

					}, error => {
						this.loading = false;
							this.success 	=	"Your Whitepaper has been approved successfully.";
							this.router.navigate(['/edit_whitepaper/'+this.data.id]);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	  }


}
