import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
//import { FileValueAccessorDirective } from '../custom/validation';
import { Functions } from '../global/functions';
declare var $;
declare var CKEDITOR;


@Component({
  selector: 'app-edit_press_kit',
  templateUrl: './edit_press_kit.component.html',
  styleUrls: ['./edit_press_kit.component.css']
})
export class EditPressKitComponent implements OnInit {

	
	model: any = {};
	data:any = {};
	errors:any = {};
	config:any;
	id: any;
	sub: any;
	ticket: any	=	'';
	error:any 	=	'';
	success:any 	=	'';
	pdfFile:any =  null;
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	public loading = false;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { 
		this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	
	}

	ngOnInit() {
		
		this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetPressKit();
		});
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
		localStorage.removeItem("success_msg");
		localStorage.removeItem("error_msg");
		
		
	}
	  
	onSubmit() {
			
		this.EditPressKit();
	  }  

	GetPressKit() {
		
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
				this.rest.CallGetPressKit(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					this.model.name 				=	response2.name;
					this.model.template 			=	fields.template.stringValue;
					this.model.Hub_PageTitle 			=	fields.Hub_PageTitle.stringValue;
					this.model.Hub_MetaDescription 				=	'';
					if(fields.Hub_MetaDescription!=null){
						this.model.Hub_MetaDescription 		=	fields.Hub_MetaDescription.stringValue;
					}
					this.model.Hub_Keywords 				=	'';
					if(fields.Hub_Keywords!=null){
						this.model.Hub_Keywords 		=	fields.Hub_Keywords.stringValue;
					}
					this.model.Hub_BodyID 				=	'';
					if(fields.Hub_BodyID!=null){
						this.model.Hub_BodyID 		=	fields.Hub_BodyID.stringValue;
					}
					this.model.Hub_PageH1Tag 				=	'';
					if(fields.Hub_PageH1Tag!=null){
						this.model.Hub_PageH1Tag 		=	fields.Hub_PageH1Tag.stringValue;
					}
					this.model.Hub_PageName 				=	'';
					if(fields.Hub_PageName!=null){
						this.model.Hub_PageName 			=	fields.Hub_PageName.stringValue;
					}
					this.model.Hub_PageID 				=	'';
					if(fields.Hub_PageID!=null){
						this.model.Hub_PageID 			=	fields.Hub_PageID.stringValue;
					}
					if(fields.CustomTags!=null){
						let selected_tags	=	fields.CustomTags;
							selected_tags	=	selected_tags.stringList;
						this.model.page_tags 		=	selected_tags.join(",");
						this.model.selected_tags 				=	selected_tags;
						
					}else{
						this.model.page_tags 				=	'';
					}
					if(fields.Hub_ScrollOverlay!=null){
						this.model.Hub_ScrollOverlay 	=	0;
						var str = fields.Hub_ScrollOverlay.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.Hub_ScrollOverlay	=	1;
						}
						
					}else{
						this.model.Hub_ScrollOverlay 				=	0;
					}
					
					if(fields.Hub_PDF!=null){
						this.model.pdf_file 			=	fields.Hub_PDF.blobValue.href;
						this.data.Hub_PDF 					=	fields.Hub_PDF.blobValue;
						
					}else{
						this.model.pdf_file 			=	'';
					}
					if(fields.Hub_PDFTitle!=null){
						this.model.Hub_PDFTitle 			=	fields.Hub_PDFTitle.stringValue;
						
					}else{
						this.model.Hub_PDFTitle 			=	'';
					}
					if(fields.Hub_ContentBlock!=null){
						let content_block	=	fields.Hub_ContentBlock;
						content_block	=	content_block.stringList;	
						content_block.forEach((item, index) => {
							var block_array 	=	item.split(":");
							var block_type 		=	block_array[0];
							var block_id 		=	block_array[1];
							let content_blocks 	=	[];
							this.rest.CallGetPageBlock(block_id, this.ticket).subscribe(response3 => {
									let block_fields  = Functions.getSingleData(response3);
									content_blocks[index]	=	block_fields;
							});
							this.model.Hub_ContentBlock 	=	content_blocks;
						});
					}else{
						this.model.Hub_ContentBlock 				=	'';
					}
					
					if(fields.Hub_EmailSubject!=null){
						this.model.Hub_EmailSubject 			=	fields.Hub_EmailSubject.stringValue;
						
					}else{
						this.model.Hub_EmailSubject 			=	'';
					}
					if(fields.Hub_EmailBody!=null){
						this.model.Hub_EmailBody 			=	fields.Hub_EmailBody.stringValue;
						
					}else{
						this.model.Hub_EmailBody 			=	'';
					}
					if(fields.Hub_CreatedDate!=null){
						this.model.Hub_CreatedDate 			=	fields.Hub_CreatedDate.dateValue;
						
					}else{
						this.model.Hub_CreatedDate 			=	'';
					}
					
				}, error => {
				//this.router.navigate(['']);
			});
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
		

	}  

	EditPressKit() {
		this.rest.CallEditPressKit(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				console.log(response.msg);
				this.router.navigate(['/dashboard']);
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}
	
	DeleteTag(){
		if(confirm("Are you sure to delete Tag")) {
			this.rest.CallDeleteTag(this.data, this.data.id).subscribe(response => {
				if(response.error==1){
					this.errors 	=	response.error;
					console.log(this.errors);
				}else{
					console.log(response.msg);
					this.router.navigate(['/dashboard']);
				}

			}, error => {
					alert("Server Busy, Please try again later.");
				});
		}
	}
	onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string:any;
				string		=	fileReader.result;
				var solution	=	string.split("base64,");
				this.readtextpdffile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.pdfFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
	  
	  
	   ApproveAsset(){
		 if(confirm("Are you sure to Approve Press Kit?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallApproveAsset(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						this.success 	=	"Your Press Kit has been approved successfully.";
						this.router.navigate(['/edit_downloadable/'+this.data.id]);

					}, error => {
						this.loading = false;
							this.success 	=	"Your Press Kit has been approved successfully.";
							this.router.navigate(['/edit_downloadable/'+this.data.id]);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	  }
	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//SAVE button functionality
				   //APPROVE button functionality
					approveButton.click(function(event) {
						event.preventDefault();
						previewButton.removeClass('inactive');
						deleteButton.addClass('inactive');
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}
  
     
  
}
