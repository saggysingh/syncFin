import { Component, OnInit } from '@angular/core';
import { Functions } from '../global/functions';
@Component({
  selector: 'app-side-navigation',
  templateUrl: './side-navigation.component.html',
  styleUrls: ['./side-navigation.component.css']
})
export class SideNavigationComponent implements OnInit {

	APP_URL: string="";
  constructor() {
	this.APP_URL	=	Functions.getAppURL();


  }

  ngOnInit() {
  }

}
