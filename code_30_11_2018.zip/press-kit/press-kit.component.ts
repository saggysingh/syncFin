import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomValidator } from '../custom/validation';
import { Functions } from '../global/functions';
import { Press } from './press';
import { Files } from './files';

declare var $;
declare var CKEDITOR;

let uniqueId = 1;

@Component({
  selector: 'app-press-kit',
  templateUrl: './press-kit.component.html',
  styleUrls: ['./press-kit.component.css']
})
export class PressKitComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	config:any;
	id: any;
	sub: any;
	ticket: any	=	'';
	error:any 	=	'';
	success:any 	=	'';
	pdfFile:any =  null;
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	filetextsinglecode:any ='';
	public loading = false;
	filetextcode:Array<String>	=	new Array<String>();
	currentFile:any ='';
	
	pressArray:Array<Press>=new Array<Press>();
	selectedFile:Array<Files>=new Array<Files>();
	
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router){ 

		this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   
	   var username	=	localStorage.hasOwnProperty("username");
		if(!username){
			this.router.navigate(['']);
		}
	}

	ngOnInit() {
		  
	}
  	ngAfterViewInit() {
		 	
	}

   onSubmit() {
			var arrFile = new Array();
			
			var error_flag = 0;
		 this.pressArray.forEach(function(field_value, field_index){
		     if(field_value.type==2){
			    arrFile.push(field_value.id);
			 }else{
			 // Type ckEditor
			     $('#ckeditor_error_'+field_value.id).html('');
				 if(CustomValidator.emptyValidation(field_value.data.Content)===false){
				   $('#ckeditor_error_'+field_value.id).html('This field is required.');
				     error_flag = 1;
				 }
			 
			 }
		
		 });
		 /*  Image Validation */
		 if (this.selectedFile.length === 0) {
			   let all_files 	=	this.pressArray; 
			   
			   arrFile.forEach(function(v, k){
				   all_files.forEach(function(field_value, field_index){
						if(field_value.type==2){
							if(field_value.data.ImageHref==undefined && field_value.id==v){
								$('#image_error_'+v).html('This field is required.');
								error_flag = 1;
							}
						}
					
					})
				   
		 	    
			   });
 
         }else{
				this.selectedFile.forEach(function(value, key) {
					  $('#image_error_'+value.id).html('');
					 if(CustomValidator.imageExtensionValidation(value.file)===false){
					 
						$('#image_error_'+value.id).html('Wrong format file.');
						error_flag = 1;
						
					  }
				
				});
		}
		   
		  if(error_flag==1){
		     return false;
		  }
		  //console.log(error_flag);
			this.CreatePressKit();
	  }  
	CreatePressKit() {
		// create the Sub Content Block
		let content_blocks	=	[];
		let upload_file_code	=	this.filetextcode;
		var formData:any 	=	"";
		var current_model_data 	=	this.data;
		var current_model 	=	this.model;
		var restAPI 	=	this.rest;
		var this_object 	=	this;
		this_object.loading = true;
		this.pressArray.forEach(function(field_value, field_index){
			var file_number:number 	=	Number(field_value.id);
			if(field_value.type==2){  
				// Image Block
				var file_name 	=	'';
				var foldername 	=	'';
				var filedata 	=	'';
				var href 		=	'';			
				
				var new_image 	=	0;
				upload_file_code.forEach(function(image_value, image_index){
					var current_file_number:number	=	Number(image_value[0]);
					
						if(file_number==current_file_number){
							file_name 	=	image_value[2];
							foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
							filedata 	=	image_value[1];
							href 		=	'';
							new_image 	=	1;
						}
					});
				if(new_image==0){
					file_name 	=	field_value.data.ImageFile.blobValue.filename;
					foldername 	=	field_value.data.ImageFile.blobValue.foldername;
					filedata 	=	field_value.data.ImageFile.blobValue.filedata;
					href 		=	field_value.data.ImageFile.blobValue.href;
					
				}
				var zoom_image 	=	"";
				if(field_value.data.ZoomImage){
					zoom_image 	=	"Yes";
				}else{
					zoom_image 	=	"No";
				}
				if(field_value.data.id==undefined){
					formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_ContentImageLayout"}}, {"name":"ImageFile","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Alt","data":{"stringValue":field_value.data.Alt}},{"name":"Tooltip","data":{"stringValue":field_value.data.Tooltip}}, {"name":"ZoomImage","data":{"stringValue":zoom_image}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_ContentImage", "createdby":current_model_data.createdby }
				}else{
					formData 	=	{"attribute":[{"name":"id", "data":{"longValue":field_value.data.id}}, {"name":"template","data":{"stringValue":"Hub_ContentImageLayout"}}, {"name":"ImageFile","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Alt","data":{"stringValue":field_value.data.Alt}},{"name":"Tooltip","data":{"stringValue":field_value.data.Tooltip}}, {"name":"ZoomImage","data":{"stringValue":zoom_image}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "id":'Hub_PageBlock_C:'+field_value.data.id, "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_ContentImage", "createdby":current_model_data.createdby }
				}
				
				
				
			}else{
				// Content Block
				
				if(field_value.data.id==undefined){
					formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_ContentLayout"}}, {"name":"Content","data":{"stringValue":field_value.data.Content}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_Content", "createdby":current_model_data.createdby }
				}else{
					formData 	=	{"attribute":[{"name":"id", "data":{"longValue":field_value.data.id}}, {"name":"template","data":{"stringValue":"Hub_ContentLayout"}}, {"name":"Content","data":{"stringValue":field_value.data.Content}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "id":'Hub_PageBlock_C:'+field_value.data.id, "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_Content", "createdby":current_model_data.createdby }
				}
				
				
			}
			
			// call the Rest API for add the Content Block
			var id  	=	0;
			if(field_value.data.id!=undefined){
				id 	=	field_value.data.id;
			}
				restAPI.CallAddPageBlock(formData, '', id).subscribe(response2 => {
					content_blocks.push(response2.id);
					
				});
		 });
		 var total_wait 	=	30000*this.pressArray.length;
		 setTimeout(function(){  
			
		 // create a Post request for Press kit Form:
			current_model_data.Hub_ScrollOverlay 		    = 	'No';
			if(current_model.Hub_ScrollOverlay){		
			  current_model_data.Hub_ScrollOverlay 		= 	'Yes';	
			}
			current_model_data.id 	=	Number(current_model_data.id);
		 // Condition for thumbnail image
			var file_name 	=	'';
			var foldername 	=	'';
			var filedata 	=	'';
			var href 	=	'';
			if(CustomValidator.emptyValidation(this_object.pdfFile)===false && current_model_data.Hub_PDF!=null){
				file_name 	=	current_model_data.Hub_PDF.filename;
				foldername 	=	current_model_data.Hub_PDF.foldername;
				filedata 	=	current_model_data.Hub_PDF.filedata;
				href 	=	current_model_data.Hub_PDF.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				if(this_object.pdfFile!=null){
					var unix = Math.round(+new Date()/1000);
					var old_file_name 	=	this_object.pdfFile.name;
					let file_nameArray = old_file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;
					file_name 	=	new_file_name;
					foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
					filedata 	=	this_object.readtextpdffile;
					href 		=	'';
				}
				
			}
			let selected_tags 	=	current_model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			
			let formData_pressKit 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_PressKitPageLayout"}}, {"name":"Hub_PageTitle","data":{"stringValue":current_model.Hub_PageTitle}}, {"name":"Hub_MetaDescription","data":{"stringValue":current_model.Hub_MetaDescription}}, {"name":"Hub_Keywords", "data":{"stringValue":current_model.Hub_Keywords}}, {"name":"Hub_BodyID","data":{"stringValue": current_model.Hub_BodyID}}, {"name":"Hub_PageH1Tag","data":{"stringValue": current_model.Hub_PageH1Tag}}, {"name":"Hub_PageName","data":{"stringValue": current_model.Hub_PageName}}, {"name":"Hub_PageID","data":{"stringValue": current_model.Hub_PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"Hub_ScrollOverlay","data":{"stringValue": current_model_data.Hub_ScrollOverlay}}, {"name":"Hub_PDF","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Hub_PDFTitle","data":{"stringValue":current_model.Hub_PDFTitle}},{"name":"Hub_ContentBlock","data":{"stringList":content_blocks}}, {"name":"Hub_EmailSubject","data":{"stringValue":current_model.Hub_EmailSubject}}, {"name":"Hub_EmailBody","data":{"stringValue":current_model.Hub_EmailBody}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}, {"name":"Hub_CreatedDate","data":{"dateValue":current_model.Hub_CreatedDate}}], "id":'Page:'+current_model_data.id, "name":current_model.name, "createdby":current_model_data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_PressKitPage", "createddate": current_model.Hub_CreatedDate }
		 
			this_object.rest.CallAddPressKit(formData_pressKit, this_object.ticket, current_model_data).subscribe(response2 => {
					this_object.loading = false;
					localStorage.setItem("success_msg", "Your Press Kit has been created successfully.");
					this_object.success 	=	"Your Press Kit has been created successfully.";
					let idString 	=	response2.id;
					let idArray 	= idString.split(":");
					let id 			=	idArray[1];
					this_object.loading	= false;
					this_object.router.navigate(['/edit-press-kit/'+id]);

			}, error => {
						this_object.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this_object.router.navigate(['/create-edit-content']);
					});
		}, total_wait);
	}
  

	
 textAdd(block_type){
     var press: Press  = new Press(uniqueId++,'',block_type,[0, '', '', '', '', '']);
     this.pressArray.push(press);
  }

  deletePress(index:any){
    this.pressArray.splice(index,1);

  }
  
  clickUpload(id){
     $('#'+id).trigger('click');
  }
  
   onFileSelected(event,id){
		var index = null;
		this.currentFile = event.target.files[0];
	    var file_data: Files  = new Files(id, <File>event.target.files[0]);
		
		var file_data_encode:any	=	new Array();
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string:any;
				string		=	fileReader.result;
				var solution	=	string.split("base64,");
				file_data_encode 	=	[id, solution[1], this.currentFile.name];
				this.filetextcode.push(file_data_encode);
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextsinglecode	=	fileReader.readAsDataURL(this.currentFile);
			 this.selectedFile.forEach(function(value,key) {
		       	if (value.id == id){
				    index = key;
				}
			});
			if(index != null){
			   this.selectedFile.splice(index,1);
			   //this.filetextcode.splice(index,1);
			}
			
		   this.selectedFile.push(file_data);
	     $('#image_'+id).html(event.target.files[0].name);
	}
	
	
	onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string:any;
				string		=	fileReader.result;
				var solution	=	string.split("base64,");
				this.readtextpdffile 	=	solution[1];
				//console.log(this.readtextpdffile);
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.pdfFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
  
}
