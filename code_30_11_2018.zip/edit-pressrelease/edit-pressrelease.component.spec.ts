import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPressreleaseComponent } from './edit-pressrelease.component';

describe('EditPressreleaseComponent', () => {
  let component: EditPressreleaseComponent;
  let fixture: ComponentFixture<EditPressreleaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPressreleaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPressreleaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
