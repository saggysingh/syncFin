export class Downloadable{
	constructor(
				public page_title: string,
				public page_description: string,
				public page_keywords: string,
				public page_name: string,
				public page_id: string,
				public page_tags: string,
				public featured: string,
				public thumb_title: string,
				public thumb_alt: string,
				public creation_date: any,
				public post_title: any,
				public sub_title: string,
				public short_description: any,
				public content: any,
				public downloadable_title: string,
				public downloadable_link: any
				
				){

	}
}