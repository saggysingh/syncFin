import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { Event } from '../model/event_model';
import { Functions } from '../global/functions';
declare var $;

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})
export class CreateEventComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	selectedFile:any =  null;
	ticket:any	=	'';
	public loading = false;
	readtextfile:any='';
	filetextcode:any='';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   
	    this.model = new Event('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''); 
	}

	ngOnInit() {
	}
	  
  	onSubmit() {
	
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		if(error_flag ==1){
			  return false;
		}		
		this.CreateEvent();
	  }  
  
  CreateEvent() {
	this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedEvent 		    = 	'No';
			if(this.model.FeaturedEvent){		
			  this.data.FeaturedEvent 		= 	'Yes';	
			}
			this.data.DisplayMediaFormLink 		    = 	'No';
			if(this.model.DisplayMediaFormLink){		
			  this.data.DisplayMediaFormLink 		= 	'Yes';	
			}
			//add timestamp in file name
			var unix = Math.round(+new Date()/1000);
			var file_name 	=	this.selectedFile.name;
			let file_nameArray = file_name.split(".");
			file_nameArray.reverse();
			let file_ext 	=	file_nameArray[0];
			file_nameArray.splice(0, 1);
			file_nameArray.reverse();
			var file_name	=	file_nameArray.join("-");
			var new_file_name 	=	file_name+"-"+unix+"."+file_ext;	
			
			
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			let formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_EventSectionLayout"}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedEvent","data":{"stringValue": this.data.FeaturedEvent}}, {"name":"EventImage","data":{"blobValue":{"filename":new_file_name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextfile,"href":""}}}, {"name":"EventImageAlt","data":{"stringValue":this.model.EventImageAlt}},{"name":"EventImageText","data":{"stringValue":this.model.EventImageText}},{"name":"EventImageTooltip","data":{"stringValue":this.model.EventImageTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"FromDate","data":{"dateValue":this.model.FromDate}}, {"name":"ToDate","data":{"dateValue":this.model.ToDate}}, {"name":"Location","data":{"stringValue":this.model.Location}}, {"name":"Registration","data":{"stringValue":this.model.Registration}},{"name":"DisplayMediaFormLink","data":{"stringValue": this.data.DisplayMediaFormLink}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Description","data":{"stringValue":this.model.Description}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}],  "name":this.model.name, "createdby":this.data.createdby, "description":"", "subtype":"Hub_EventSection",  publist:Functions.getPublist(), "createddate": this.model.CreatedDate }
			
			this.rest.AddHubEvent(formData, this.ticket).subscribe(response2 => {
					
					localStorage.setItem("success_msg", "Your Event has been created successfully.");
					this.success 	=	"Your Event has been created successfully.";
					let idString =	response2.id;
					let idArray = idString.split(":");
					let id 	=	idArray[1];
					this.loading = false;
					this.router.navigate(['/edit_event/'+id]);
					
				}, error => {
					this.loading = false;
						//localStorage.setItem("error_msg", "You are not authorize to access this.");
						//this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
  }
  
  	  onFileSelected(event){
          //console.log(event);
	     this.selectedFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {	
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }


}
