'use strict';
require(['app', 'jquery', 'domReady'], function(app, $, domReady) {
    domReady(function () {
        if ( $('.add-tag-popup').length ) {
            $('.add-tag-popup').each(function() {
                var these = $(this),
                    tagItems = these.find('.add-tag-content li'),
                    confirmSelection = these.find('.confirm-section'),
                    tagsInput = $('.tags-container ul'),
                    errorMessage = these.find('.error-message'),
                    closeTagsPopUp = these.find('.close-popup');

                //Activate tags
                tagItems.click(function() {
                    $(this).toggleClass('active');
                });

                //Close tags popup
                closeTagsPopUp.click(function(event) {
                    event.preventDefault();
                    these.removeClass('showing-tags');
                    var currentActiveItems = these.find('.active');
                    currentActiveItems.removeClass('active');
                    errorMessage.hide();
                    $('html,body').animate({
                        scrollTop: $('.input-field.tags').offset().top
                    }, 'slow');
                });

                //Populate tags in input field
                confirmSelection.click(function(event) {
                    event.preventDefault();
                    var activeItems = these.find('.active');
                    if (activeItems.length <= 0) {
                        errorMessage.fadeIn();
                    } else {
                        var addedTags = $('.tags-container li');
                        if (addedTags.length) {
                            var addedTagsArray = [];

                            addedTags.each(function() {
                                addedTagsArray.push($(this).text());
                            });

                            activeItems.each(function() {
                                var tagValue = $(this).text();
                                if ( jQuery.inArray(tagValue, addedTagsArray) != -1 ) {
                                    return true;
                                } else {
                                   $(this).clone().appendTo(tagsInput); 
                                }
                            });
                        } else {
                            activeItems.clone().appendTo(tagsInput);
                        }
                        these.removeClass('showing-tags');
                        activeItems.removeClass('active');
                        $('html,body').animate({
                            scrollTop: $('.input-field.tags').offset().top
                        }, 'slow');   
                    }    
                });
                
            });
        }
    });
});