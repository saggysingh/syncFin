import { Directive, HostListener ,ElementRef } from "@angular/core";
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from "@angular/forms";
import {FormControl } from '@angular/forms';


@Directive({
    selector: "input[type=file]",
    providers: [
        {provide: NG_VALUE_ACCESSOR, useExisting: FileValueAccessorDirective, multi: true}
    ]
})
export class FileValueAccessorDirective implements ControlValueAccessor {
    constructor(private el: ElementRef) { }
    @HostListener('change', ['$event.target.files']) onChange = (_) => {
	 
	  this.validate(this.el.nativeElement);   
	};
    @HostListener('blur') onTouched = () => {};

    writeValue(value) {}
    registerOnChange(fn: any) { this.onChange = fn; }
    registerOnTouched(fn: any) { this.onTouched = fn; }
	
	static validate(c): {[key: string]: any} {
      if (c.size > 0) {
         console.log("Maximum size")
         return { "sizeinvalid" : true};
      } else {
         console.log('No size');
         return null;
      }       
   }

   validate(c): {[key: string]: any} {
      return FileValueAccessorDirective.validate(c);
   }
	
}