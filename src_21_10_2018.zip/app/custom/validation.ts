export class CustomValidator {

// Validates Empty
static emptyValidation(value): any{
  	if (value === "" || value === null || typeof value === "undefined") {
         return false;
        }else{
		return true;
		}
}

static imageExtensionValidation(file):any {
        var fileTypes = ['jpg', 'jpeg', 'png'];  //acceptable file types
        var extension = file.name.split('.').pop().toLowerCase();
		//alert(extension);
        var isSuccess = fileTypes.indexOf(extension) > -1;
        //alert(isSuccess);
        if(isSuccess===true){ 
             return true;
        }
        else{ 
            return false;
        }
   
  }
  
static videoExtensionValidation(file,vtype):any {
        var fileTypes = [vtype];  //acceptable file types
        var extension = file.name.split('.').pop().toLowerCase();
		//alert(extension);
        var isSuccess = fileTypes.indexOf(extension) > -1;
        //alert(isSuccess);
        if(isSuccess===true){ 
             return true;
        }
        else{ 
            return false;
        }
   
  }  
  
  

static imageWandhValidation(file):any {
var text='true' ;
        var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function (e) {
                //Initiate the JavaScript Image object.
                var image = new Image();
 
                 image.src = e.target.result;
                       
                //Validate the File Height and Width.
                image.onload = function () {
                    var height = image.height;
                    var width = image.width;
					
					//alert(height+'X'+width);
					if (width < 1200 || height < 850){
					   text='false' ;
                    }
                  
                };
            }
			
			return text;
  } 
  


}