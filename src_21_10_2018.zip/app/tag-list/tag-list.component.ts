import { Component, OnInit , Input } from '@angular/core';
import { RestService } from '../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
declare var $;
@Component({
  selector: 'app-tag-list',
  templateUrl: './tag-list.component.html',
  styleUrls: ['./tag-list.component.css']
})
export class TagListComponent implements OnInit {
    
	@Input() model: any = {};
   	data:any = {};
	errors:any = {};
	lists:any;
    page_tags_arr:any =[];
  	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	  this.lists 					= {};
	}

  ngOnInit() {
   	this.getTagList();
  }
  
  OpenTag(){
    $('.tag_list_modal').addClass('open');
  }
  
  CloseTag(){
    $('.tag_list_modal').removeClass('open');
  }
  
  AddTag(tagval,this_ele){
	   if ($('#'+this_ele).hasClass('add-tag-a')) {
			var index = this.page_tags_arr.indexOf(tagval);
			if (index !== -1) {
			   this.page_tags_arr.splice(index, 1);
			}
			$('#'+this_ele).removeClass('add-tag-a');
	   }else{
			  this.page_tags_arr.push(tagval);
			  $('#'+this_ele).addClass('add-tag-a');
	   }
  }
  
ConfirmSelection(){
 this.model.page_tags = this.page_tags_arr.toString();
 $('.tag_list_modal').removeClass('open');
}
  
  
  getTagList() {
      var listr;
	 this.rest.CallFeaturedList(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
		  this.lists 	=	response.data;
		}
	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }

}
