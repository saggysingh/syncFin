import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { Functions } from '../global/functions';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
	data:any;
	announcement:any;
	press:any;
	event:any;
	downloadable:any;
	video:any;
	white_paper:any;
	errors:any;
	p: number = 1;
  constructor(public rest:RestService) { 
	this.data 					= {};
	this.announcement 					= {};
	this.errors 					= {};
  }

  ngOnInit() {
		this.getFeaturedList();
		setInterval(() => {
			this.getFeaturedList();
		  }, 1000); // Activate after 5 minutes.
  }
  
  getFeaturedList() {
      this.data.created_by = localStorage.getItem("UserName");
      this.data.is_featured = 1;
  
   	 this.rest.ContentAnnouncement(this.data).subscribe(response => {
	 	//console.warn(response.total);
		this.announcement  = Functions.getExtractData(response);
	 }, error => {
			alert("Server Busy, Please try again later.");
	  });
	this.rest.ContentPress(this.data).subscribe(response => {
	 	this.press  = Functions.getExtractData(response);
	}, error => {
			alert("Server Busy, Please try again later.");
	});

	this.rest.ContentEvent(this.data).subscribe(response => {
	 		this.event  = Functions.getExtractData(response);
	}, error => {
			alert("Server Busy, Please try again later.");
	});	

	this.rest.ContentDownloadable(this.data).subscribe(response => {
	 	this.downloadable  = Functions.getExtractData(response);
	}, error => {
			alert("Server Busy, Please try again later.");
	});	


	this.rest.ContentVideo(this.data).subscribe(response => {
		this.video  = Functions.getExtractData(response);
	}, error => {
			alert("Server Busy, Please try again later.");
	});	


	this.rest.ContentWhitPaper(this.data).subscribe(response => {
	 	this.white_paper  = Functions.getExtractData(response);
	}, error => {
			alert("Server Busy, Please try again later.");
	});		
		
		
  }


}
