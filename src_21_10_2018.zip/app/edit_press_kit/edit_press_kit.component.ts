import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
//import { FileValueAccessorDirective } from '../custom/validation';

declare var $;
declare var CKEDITOR;


@Component({
  selector: 'app-edit_press_kit',
  templateUrl: './edit_press_kit.component.html',
  styleUrls: ['./edit_press_kit.component.css']
})
export class EditPressKitComponent implements OnInit {

	
	model: any = {};
	data:any = {};
	errors:any = {};
	config:any;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { 
		this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	
	}

	ngOnInit() {
		this.GetPressKit();
	}
	  
	onSubmit() {
		alert("Amit");
		this.data.api_type 			= 	'Login';	
		this.data.file_name 		= 	this.model.file_name;	
		this.data.tag_name 			= 	this.model.tag_name;	
		this.EditPressKit();
	  }  

	GetPressKit() {
		this.rest.CallGetPressKit(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				this.model	= response.data;
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}  

	EditPressKit() {
		this.rest.CallEditPressKit(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				console.log(response.msg);
				this.router.navigate(['/dashboard']);
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}
	
	DeleteTag(){
		if(confirm("Are you sure to delete Tag")) {
			this.rest.CallDeleteTag(this.data).subscribe(response => {
				if(response.error==1){
					this.errors 	=	response.error;
					console.log(this.errors);
				}else{
					console.log(response.msg);
					this.router.navigate(['/dashboard']);
				}

			}, error => {
					alert("Server Busy, Please try again later.");
				});
		}
	}

	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//SAVE button functionality
				   //APPROVE button functionality
					approveButton.click(function(event) {
						event.preventDefault();
						previewButton.removeClass('inactive');
						deleteButton.addClass('inactive');
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}
  
     
  
}
