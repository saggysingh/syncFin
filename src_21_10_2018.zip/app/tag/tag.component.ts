import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
declare var $;
@Component({
  selector: 'app-tag',
  templateUrl: './tag.component.html',
  styleUrls: ['./tag.component.css']
})
export class TagComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { }

	ngOnInit() {
	}
	  
  	onSubmit() {
		this.data.api_type 			= 	'Login';	
		this.data.file_name 		= 	this.model.file_name;	
		this.data.tag_name 			= 	this.model.tag_name;	
		this.CreateTag();
	  }  
  
  CreateTag() {
	this.rest.CallAddTag(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
			console.log(response.msg);
			this.router.navigate(['/dashboard']);
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  

}
