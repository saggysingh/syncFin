import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RestService {
	baseUrl:any;
	baseUrltest:any;
	httpOptions:any;
	serverType:any;
	
	
  constructor(private http: HttpClient) {
    this.serverType = 'dev';//live
    if(this.serverType=='dev'){
	  this.baseUrltest = 'http://localhost/api/';
	  this.baseUrl = 'assets/json/';
	}
	
	if(this.serverType=='live'){
	  this.baseUrl = 'https://vdlsyficmapda01.cpu.syfbank.com:7002/cs/';
	}
	
	this.httpOptions = {
	  headers: new HttpHeaders({
		'Content-Type':  'application/json'
	  })
	};
	}
  
	private extractData(res: Response) {
	  let body = res;
	  return body || { };
	}

	
	
	/* CallApi (data){
		return this.http.post(this.baseUrl+ 'products.php', {data}, {headers: this.httpOptions})
        .map(res => res.json());
    } */
	
	
	CallApi(data): Observable<any> {
	  return this.http.post(this.baseUrl + 'products.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallLogin(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'login.php', {data}).pipe(
		map(this.extractData)); 
	}
	/* Featured list section  */
	CallFeaturedList(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'list.php', {data}).pipe(
		map(this.extractData)); 
	}
	ContentAnnouncement(data): Observable<any> {
	   if(data.is_featured==1){
		  var data_url = 'REST/sites/ContentHub/types/Hub_NewsPost_C/search?field:createdby:equals='+data.created_by+'&field:FeaturedNews:equals=yes&field:NewsType:contains=Announcement';
	      var dev_data_url ='announcement_featured_list.json';
	  }else{
	      var data_url = 'REST/sites/ContentHub/types/Hub_NewsPost_C/search?field:createdby:equals='+data.created_by+'&field:NewsType:contains=Announcement';
	      var dev_data_url ='announcement_content.json';
	   }
 
	   var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	    full_url =  this.baseUrl +dev_data_url;
	   }
	
	  return this.http.get(full_url).pipe(
		map(this.extractData));

    }
	ContentPress(data): Observable<any> {
	
       if(data.is_featured==1){
		  var data_url = 'REST/sites/ContentHub/types/Hub_NewsPost_C/search?field:createdby:equals='+data.created_by+'&field:FeaturedNews:equals=yes&field:NewsType:contains=Press';
	      var dev_data_url ='press_release_featured_list.json';
	  }else{
          var data_url = 'REST/sites/ContentHub/types/Hub_NewsPost_C/search?field:createdby:equals='+data.created_by+'&field:NewsType:contains=Press';
	       var dev_data_url ='press_release_content.json';
	  }
	   var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	     full_url =  this.baseUrl +dev_data_url;
	   }
	     return this.http.get(full_url).pipe(
		map(this.extractData));
	 

    }
	
	ContentEvent(data): Observable<any> {
	   if(data.is_featured==1){
		  var data_url = 'REST/sites/ContentHub/types/Hub_Event_C/search?field:createdby:equals='+data.created_by+'&field:FeaturedEvent:equals=yes';
	      var dev_data_url ='event_featured_list.json';
	   
	   }else{
	     var data_url = 'REST/sites/ContentHub/types/Hub_Event_C/search?field:createdby:equals='+data.created_by;
	     var dev_data_url ='event_content.json';
	   }
	
	   var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	     full_url =  this.baseUrl +dev_data_url;
	   }
	
		return this.http.get(full_url).pipe(
		map(this.extractData));

    }
	ContentDownloadable(data): Observable<any> {

	   if(data.is_featured==1){
		 var data_url = 	'REST/sites/ContentHub/types/Hub_Downloadable_C/search?field:createdby:equals='+data.created_by+'&field:FeaturedDownload:equals=yes';
	     var dev_data_url ='downloadable_featured_list.json';
	   }else{
	     var data_url = 'REST/sites/ContentHub/types/Hub_Downloadable_C/search?field:createdby:equals='+data.created_by;
	     var dev_data_url ='downloadable_content.json';
	  } 

	   var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	     full_url =  this.baseUrl +dev_data_url;
	   }
	
		return this.http.get(full_url).pipe(
		map(this.extractData));

    }
	ContentVideo(data): Observable<any> {
	 if(data.is_featured==1){
	 	var data_url = 'REST/sites/ContentHub/types/Hub_Video_C/search?field:createdby:equals='+data.created_by+'&field:FeaturedVideo:equals=yes';
	    var dev_data_url ='video_featured_list.json';
	   }else{
	     var data_url = 'REST/sites/ContentHub/types/Hub_Video_C/search?field:createdby:equals='+data.created_by;
	     var dev_data_url ='video_content.json';
	   } 
	
	    var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	     full_url =  this.baseUrl +dev_data_url;
	   }
	
		return this.http.get(full_url).pipe(
		map(this.extractData));

    }
	ContentWhitPaper(data): Observable<any> {
	  if(data.is_featured==1){
	  	var data_url ='REST/sites/ContentHub/types/Hub_WhitePaper_C/search?field:createdby:equals='+data.created_by+'&field:FeaturedWhitePaper:equals=yes';
	    var dev_data_url ='white_paper_featured_list.json';
	   }else{
	     var data_url = 'REST/sites/ContentHub/types/Hub_WhitePaper_C/search?field:createdby:equals='+data.created_by;
	     var dev_data_url ='white_paper_content.json';
	   } 
	
	    var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	     full_url =  this.baseUrl + dev_data_url;
	   }
	
	 return this.http.get(full_url).pipe(
		map(this.extractData));

    }
	
	ContentTag(data): Observable<any> {

	    var data_url = 'REST/sites/ContentHub/types/Custom_Tag/search';
	    var dev_data_url ='tag_content.json';
	
	
	    var full_url = this.baseUrl +data_url;
	   if(this.serverType=='dev'){
	     full_url =  this.baseUrl +dev_data_url;
	   }
	
		return this.http.get(full_url).pipe(
		map(this.extractData));

    }
	/* Featured list section  */
	
	
	
	CallAddTag(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallEditTag(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallGetTag(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_tag.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallDeleteTag(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_tag.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallAddPressrelease(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallGetPressrelease(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_pressrelease.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallEditPressrelease(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallDeletePressrelease(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_tag.php', {data}).pipe(
		map(this.extractData)); 
	}
	//Announcement
	
	CallAddAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallGetAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_pressrelease.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallEditAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	CallDeleteAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_tag.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallGetPressKit(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_press_kit.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	
	CallEditPressKit(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallAddVideo(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'upload.php',data); 
	}

	
	
	
	private handleError<T> (operation = 'operation', result?: T) {
	  return (error: any): Observable<T> => {

		// TODO: send the error to remote logging infrastructure
		console.error(error); // log to console instead

		// TODO: better job of transforming error for user consumption
		console.log(`${operation} failed: ${error.message}`);

		// Let the app keep running by returning an empty result.
		return of(result as T);
	  };
	}
	
  
}
