import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
declare var $;

@Component({
  selector: 'app-edit-downloadable',
  templateUrl: './edit-downloadable.component.html',
  styleUrls: ['./edit-downloadable.component.css']
})
export class EditDownloadableComponent implements OnInit {

model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	}

	ngOnInit() {
	  this.GetTag();
	}
	  
  	onSubmit() {
		this.data.api_type 			= 	'Login';	
		this.data.file_name 		= 	this.model.file_name;	
		this.data.featured 			= 	this.model.featured;	
		this.data.page_title 			= 	this.model.page_title;	
		this.data.page_name 			= 	this.model.page_name;	
		this.data.page_description 			= 	this.model.page_description;	
		this.data.page_keywords 			= 	this.model.page_keywords;	
		this.data.page_tags 			= 	this.model.page_tags;	
		this.data.thumb_title 			= 	this.model.thumb_title;	
		this.data.thumb_alt 			= 	this.model.thumb_alt;	
		this.data.post_title 			= 	this.model.post_title;	
		this.data.short_description 			= 	this.model.short_description;	
		this.data.content 			= 	this.model.content;	
		this.data.email_subject 			= 	this.model.email_subject;	
		this.data.email_body 			= 	this.model.email_body;	
		this.EditTag();
	  } 

	GetTag() {
		this.rest.CallGetAnnouncement(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				this.model	= response.data;
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}  	  
  
	EditTag() {
		this.rest.CallEditAnnouncement(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				console.log(response.msg);
				this.router.navigate(['/dashboard']);
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}
	
	DeleteTag(){
		if(confirm("Are you sure to delete Downloadable")) {
			this.rest.CallDeleteAnnouncement(this.data).subscribe(response => {
				if(response.error==1){
					this.errors 	=	response.error;
					console.log(this.errors);
				}else{
					console.log(response.msg);
					this.router.navigate(['/dashboard']);
				}

			}, error => {
					alert("Server Busy, Please try again later.");
				});
		}
	}
  
  TagList(){
       //this.getTagList();
     $( "#TagModal" ).toggle();
	 
  }
  AddTag(tagval){
   this.model.page_tags =tagval;
    $( "#TagModal" ).toggle();
  }
  
  getTagList() {
      var listr;
	 this.rest.CallFeaturedList(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
		  this.lists 	=	response.data;
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  
  	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//SAVE button functionality
				   //APPROVE button functionality
					approveButton.click(function(event) {
						event.preventDefault();
						previewButton.removeClass('inactive');
						deleteButton.addClass('inactive');
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}


}
