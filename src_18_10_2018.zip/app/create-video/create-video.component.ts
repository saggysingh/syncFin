import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
declare var $;

@Component({
  selector: 'app-create-video',
  templateUrl: './create-video.component.html',
  styleUrls: ['./create-video.component.css']
})
export class CreateVideoComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	page_tags_arr:any =[];
	
	selectedFile:File =  null;
	video_poster:File =  null;
	video_mp4:File =  null;
	video_ogg:File =  null;
	video_webm:File =  null;
	
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	 this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	}

	ngOnInit() {
	
	}
	
	  onFileSelected(event){
          //console.log(event);
	     this.selectedFile = <File>event.target.files[0];
	     $('#image-1').html(this.selectedFile.name);
	  }
	  onVideoPoster(event){
         this.video_poster = <File>event.target.files[0];
	     $('#video_poster').html(this.video_poster.name);
	  }
	  
	  onVideoMp4(event){
         this.video_mp4 = <File>event.target.files[0];
	     $('#video_mp4').html(this.video_mp4.name);
	  }
	  
	  onVideoOgg(event){
         this.video_ogg = <File>event.target.files[0];
	     $('#video_ogg').html(this.video_ogg.name);
	  }
	  
	  onVideoWebm(event){
         this.video_webm = <File>event.target.files[0];
	     $('#video_webm').html(this.video_webm.name);
	  }
	  
	 
	
	  
  	onSubmit() {
	
	    const fd = new FormData();
 
		this.data.api_type 			= 	'Login';
          fd.append('api_type','Login');		
		this.data.file_name 		= 	this.model.file_name;
          fd.append('file_name',this.model.file_name);		
		this.data.featured 			= 	this.model.featured;
          fd.append('featured',this.model.featured);			
		this.data.page_title 			= 	this.model.page_title;	
		  fd.append('page_title',this.model.page_title);	
		this.data.page_name 			= 	this.model.page_name;
          fd.append('page_name',this.model.page_name);			
		this.data.page_description 			= 	this.model.page_description;
           fd.append('page_description',this.model.page_description);			
		this.data.page_keywords 			= 	this.model.page_keywords;
          fd.append('page_keywords',this.model.page_keywords);			
		this.data.page_tags 			= 	this.model.page_tags;	
		   fd.append('page_tags',this.model.page_tags);	
		this.data.thumb_title 			= 	this.model.thumb_title;	
		  fd.append('thumb_title',this.model.thumb_title);	
		this.data.thumb_alt 			= 	this.model.thumb_alt;
          fd.append('thumb_alt',this.model.thumb_alt);			
		this.data.post_title 			= 	this.model.post_title;	
		  fd.append('post_title',this.model.post_title);	
		this.data.video_type 			= 	this.model.video_type;
          fd.append('video_type',this.model.video_type);			
		this.data.youtube_id 			= 	this.model.youtube_id;	
		   fd.append('youtube_id',this.model.youtube_id);	
		this.data.video_url 			= 	this.model.video_url;
          fd.append('video_url',this.model.video_url);			
		this.data.short_description 			= 	this.model.short_description;
           fd.append('short_description',this.model.short_description);			
		this.data.content 			= 	this.model.content;	
		  fd.append('content',this.model.content);	
		this.data.email_subject 			= 	this.model.email_subject;	
		  fd.append('email_subject',this.model.email_subject);	
		this.data.email_body 			= 	this.model.email_body;	
		   fd.append('email_body',this.model.email_body);	
	
	
	    var error_flag = 0;
		this.errors.youtube_id = '';
		this.errors.thumbnail_image = '';
		this.errors.video_url = '';
		this.errors.video_poster = '';
		this.errors.video_mp4 = '';
		this.errors.video_ogg = '';
		this.errors.video_webm = '';
		if(this.data.video_type=='YouTube'){
		   if(CustomValidator.emptyValidation(this.data.youtube_id)===false){
		       this.errors.youtube_id = 'Youtube-Id is required'; 
		     error_flag = 1;
		   }
		}
		  if(CustomValidator.emptyValidation(this.selectedFile)===false){
		   //if(this.selectedFile==null){
		       this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		    /*   var result = CustomValidator.imageWandhValidation(this.selectedFile);
			  alert(result);
		       if(CustomValidator.imageWandhValidation(this.selectedFile)=='false'){
			      this.errors.thumbnail_image = 'Wrong image size.'; 
		          error_flag = 1;
			   } */
		   
		   } 
		   
		   if(CustomValidator.emptyValidation(this.video_poster)===false){
		       this.errors.video_poster = 'Video Poster is required'; 
		       error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.video_poster)===false){
			     this.errors.video_poster = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		

		if(this.data.video_type=='External'){
		   if(CustomValidator.emptyValidation(this.data.video_url)===false){
		       this.errors.video_url = 'Video Url is required'; 
		       error_flag = 1;
		   }
		}
		
		if(this.data.video_type=='Upload'){
			if(CustomValidator.emptyValidation(this.video_mp4)===false){
		       this.errors.video_mp4 = 'Video MP4 is required'; 
		       error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_mp4,'mp4')===false){
			     this.errors.video_mp4 = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		   
		   	if(CustomValidator.emptyValidation(this.video_ogg)===false){
		       this.errors.video_ogg = 'Video OGG is required'; 
		       error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_ogg,'ogv')===false){
			     this.errors.video_ogg = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		   
		   	if(CustomValidator.emptyValidation(this.video_webm)===false){
		       this.errors.video_webm = 'Video WEBM is required'; 
		       error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_webm,'webm')===false){
			     this.errors.video_webm = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		
		      fd.append('video_mp4',this.video_mp4,this.video_mp4.name);
	          fd.append('video_ogg',this.video_ogg,this.video_ogg.name);
	          fd.append('video_webm',this.video_webm,this.video_webm.name);
		}
		
		
		
		

      	if(error_flag ==1){
		      return false;
		}	
		
	    fd.append('thumbnail_image',this.selectedFile,this.selectedFile.name);
	    fd.append('video_poster',this.video_poster,this.video_poster.name);
	
    	this.CreateTag(fd);
	  }  
  
  CreateTag(fd) {
	this.rest.CallAddVideo(fd).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
			console.log(response.msg);
			this.router.navigate(['/dashboard']);
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  
  TagList(){
      $( "#TagModal" ).toggle();
  }

 	/* Video Type Section  */
  videoOption(){
                   if ($('#video-option').hasClass('activeDropdown')) {
                        $('#video-option').removeClass('activeDropdown');
                        $('#video-options').hide();
                    } else {
                        $('#video-options').hide();
                        $('#video-option').removeClass('activeDropdown');
                        $('#video-options').show();
						   var optionFirst =  $('#video-options').find('ul li:first a');
                           optionFirst.focus();
						//alert('hi');
                        $('#video-option').addClass('activeDropdown');
                    }
  
  
   	
  }
  
  selectOption(selet_option){
      var textValue = $('#'+selet_option).text();
	  this.model.video_type =textValue;
						
		$('.youtube-video').hide();
		$('.video-url').hide();
		$('.video-set').hide();
		$('.'+selet_option).show();
  }
/* Video Type Section  */

}
