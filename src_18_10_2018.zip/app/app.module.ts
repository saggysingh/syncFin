import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms'; // <-- NgModel lives here
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CKEditorModule } from 'ngx-ckeditor';
import {NgxPaginationModule} from 'ngx-pagination';
 import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
 import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SideNavigationComponent } from './side-navigation/side-navigation.component';
import { TagComponent } from './tag/tag.component';
import { EditTagComponent } from './edit_tag/edit_tag.component';
import { ManageContentComponent } from './manage-content/manage-content.component';
import { PressKitComponent } from './press-kit/press-kit.component';
import { EditPressKitComponent } from './edit_press_kit/edit_press_kit.component';
import { CreatePressreleaseComponent } from './create_pressrelease/create_pressrelease.component';
import { EditPressreleaseComponent } from './edit-pressrelease/edit-pressrelease.component';
import { CreateAnnouncementComponent } from './create-announcement/create-announcement.component';
import { EditAnnouncementComponent } from './edit-announcement/edit-announcement.component';
import { CreateWhitepaperComponent } from './create-whitepaper/create-whitepaper.component';
import { EditWhitepaperComponent } from './edit-whitepaper/edit-whitepaper.component';
import { CreateVideoComponent } from './create-video/create-video.component';
import { EditVideoComponent } from './edit-video/edit-video.component';
import { CreateDownloadableComponent } from './create-downloadable/create-downloadable.component';
import { EditDownloadableComponent } from './edit-downloadable/edit-downloadable.component';
import { TagListComponent } from './tag-list/tag-list.component';

const appRoutes: Routes = [
 { path: '', component: LoginComponent},
 { path: 'dashboard', component: DashboardComponent},
 { path: 'create-tag', component: TagComponent},
 { path: 'create-edit-content', component: ManageContentComponent},
 { path: 'create-press-kit', component: PressKitComponent},
 { path: 'edit-press-kit/:id', component: EditPressKitComponent},
 { path: 'edit_tag/:id', component: EditTagComponent},
 { path: 'create_press_release', component: CreatePressreleaseComponent},
 { path: 'edit_pressrelease/:id', component: EditPressreleaseComponent},
 { path: 'create_announcement', component: CreateAnnouncementComponent},
 { path: 'edit_announcement/:id', component: EditAnnouncementComponent},
 { path: 'create_whitepaper', component: CreateWhitepaperComponent}, 
 { path: 'edit_whitepaper/:id', component: EditWhitepaperComponent},
 { path: 'create_video', component: CreateVideoComponent},
 { path: 'edit_video/:id', component: EditVideoComponent},
 { path: 'create_downloadable', component: CreateDownloadableComponent},
 { path: 'edit_downloadable/:id', component: EditDownloadableComponent},
 //{ path: 'edit_announcement/:id', component: EditAnnouncementComponent},

];



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    SideNavigationComponent,
    TagComponent,
    EditTagComponent,
    ManageContentComponent,
    PressKitComponent,
	EditPressKitComponent,
    CreatePressreleaseComponent,
    EditPressreleaseComponent,
    CreateAnnouncementComponent,
    EditAnnouncementComponent,
    CreateWhitepaperComponent,
    EditWhitepaperComponent,
    CreateVideoComponent,
    EditVideoComponent,
	CreateDownloadableComponent,
	EditDownloadableComponent,
	TagListComponent,
  ],
  imports: [
    BrowserModule,
	FormsModule,
	ReactiveFormsModule,
	CKEditorModule,
	HttpClientModule,
	NgxPaginationModule,
	OwlDateTimeModule, 
    OwlNativeDateTimeModule,
	BrowserAnimationsModule,
	RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
