import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomValidator } from '../custom/validation';
import { Press } from './press';
import { Files } from './files';

declare var $;
declare var CKEDITOR;

let uniqueId = 1;

@Component({
  selector: 'app-press-kit',
  templateUrl: './press-kit.component.html',
  styleUrls: ['./press-kit.component.css']
})
export class PressKitComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	config:any;
	
	
	
	
	pressArray:Array<Press>=new Array<Press>();
	selectedFile:Array<Files>=new Array<Files>();
	
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router){ 

		this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	}

	ngOnInit() {
		  
	}
  	ngAfterViewInit() {
		 	
	}

   onSubmit() {
     var error_flag = 0;
	 console.warn(this.selectedFile);
		this.selectedFile.forEach(function(value, key) {
			console.warn(value.file);
			
			$('#image_error_'+value.id).html('');
			 if(CustomValidator.imageExtensionValidation(value.file)===false){
			 	//$('#image_error_'+value.id).html('This field is required.');
			 	$('#image_error_'+value.id).html('Wrong format file.');
		  	    error_flag = 1;
				
              }
		
		});
		//alert(error_flag)
		  if(error_flag==1){
		     return false;
		  }
	
		this.data.api_type 			= 	'Login';	
		this.data.file_name 		= 	this.model.file_name;	
		this.data.tag_name 			= 	this.model.tag_name;	
		this.CreatePressKit();
	} 
	CreatePressKit() {
		this.rest.CallAddTag(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				console.log(response.msg);
				this.router.navigate(['/dashboard']);
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	}
  

	
  textAdd(block_type){
     var press: Press  = new Press(uniqueId++,'',block_type);
     this.pressArray.push(press);
  }

  deletePress(index:any){
    this.pressArray.splice(index,1);

  }
  
  clickUpload(id){
     $('#'+id).trigger('click');
  }
  
   onFileSelected(event,id){
	  
	   var file_data: Files  = new Files(id,<File>event.target.files[0]);
	    $('#image_'+id).html(event.target.files[0].name);
	  
	  
	    this.selectedFile.forEach(function(value,key) {
               	if (value.id == id){
				
				  this.selectedFile.splice(key,1);
				  alert(key);
				}
		});
	   this.selectedFile.push(file_data);
	  
	}
	  
	  



  
     
  
}
