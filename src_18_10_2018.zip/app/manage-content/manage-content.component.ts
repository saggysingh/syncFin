import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
declare var $;

@Component({
  selector: 'app-manage-content',
  templateUrl: './manage-content.component.html',
  styleUrls: ['./manage-content.component.css']
})
export class ManageContentComponent implements OnInit {
	data:any;
	errors:any;
	lists:any;
  constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { 
	this.data 					= {};
	this.errors 				= {};
	this.lists 				= {};
  
  }

  ngOnInit() {
	  this.getFeaturedList();
  }
	 getFeaturedList() {
		 this.rest.CallFeaturedList(this.data).subscribe(response => {
			if(response.error==1){
				this.errors 	=	response.error;
				console.log(this.errors);
			}else{
				this.lists 	=	response.data;
			}

		}, error => {
				alert("Server Busy, Please try again later.");
			});
	  }

   	ngAfterViewInit() {
      $(document).ready(function(){
	  
	  	if ( $('.edit-content-section').length ) {
            $('.edit-content-section').each(function() {
                var these = $(this),
                    showHideContent = these.find('.show-hide-childs'),
                    addActiveClass = $('.show').parent('li').find('>.show-hide-childs'),
                    searchPage = these.find('.search-page'),
                    contentFolders = these.find('.edit-content-folders'),
                    searchResultsContainer = these.find('.edit-content-search-results'),
                    searchResultsItems = searchResultsContainer.find('.results-items'),
                    closeSearhResults = these.find('.close-search');
                addActiveClass.addClass('active');
                var activeItems = these.find('.show-hide-childs.active');

                //Detect default active elements to show childs
                if(showHideContent.hasClass('active')) {
                    var asociateContent = activeItems.parent('li').find('> .child-content');
                    asociateContent.show();
                }

                //Manage show and hide child elements
                showHideContent.click(function(event) {
                    event.preventDefault();
                    var asociateContent = $(this).parent('li').find('> .child-content');
                    if($(this).hasClass('active')) {
                        $(this).removeClass('active');
                        asociateContent.slideUp();
                    } else {
                        $(this).addClass('active');
                        asociateContent.slideDown();
                    }
                });

                //Find Pages
                searchPage.click(function(event) {
                    event.preventDefault();
                    var searchPageInput = these.find('.search-value').val().toLowerCase(),
                        postItems = contentFolders.find('.post-page');
                    searchResultsItems.empty();
                    if (searchPageInput.length) {
                        postItems.each(function() {
                            var postPageName = $(this).find('.content-hub-posts_title').text().toLowerCase();
                            if(postPageName.indexOf(searchPageInput) != -1){
                                $(this).clone().appendTo(searchResultsItems); 
                            }
                        });
                        var resultItems = searchResultsItems.find('.post-page');
                        if ( resultItems.length ) {
                            searchResultsContainer.slideDown();
                        } else {
                            searchResultsContainer.slideDown();
                            searchResultsItems.append('<p class="error-message">There are no matches in your search</p>');
                        }
                    } else {
                        searchResultsContainer.slideUp();
                    }   
                });

                closeSearhResults.click(function(event) {
                    event.preventDefault();
                    searchResultsContainer.slideUp();
                    searchResultsItems.empty();
                });


            });
        }
	  
	  });
    }
  
}
