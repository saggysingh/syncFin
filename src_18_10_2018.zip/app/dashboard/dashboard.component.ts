import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
	data:any;
	lists:any;
	errors:any;
	p: number = 1;
  constructor(public rest:RestService) { 
	this.data 					= {};
	this.lists 					= {};
	this.errors 					= {};
  }

  ngOnInit() {
		this.getFeaturedList();
		setInterval(() => {
			this.getFeaturedList();
		  }, 1000); // Activate after 5 minutes.
  }
  
  getFeaturedList() {
	 this.rest.CallFeaturedList(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
			this.lists 	=	response.data;
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }

}
