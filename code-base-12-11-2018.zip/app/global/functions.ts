

export class Functions {

 static getExtractData(ObjData, type='Announcement'): any{
         var retrunData = new Array();
         var obj =   ObjData.assetinfo;
		 
         obj.forEach(function(value, index){
			var obj2 = value.fieldinfo;
			var fields_array:any 	= [];
			fields_array['id']		= value.id;	
			fields_array['href']	= value.href;
			let idString =	value.id;
			let idArray = idString.split(":");
			var edit_link 	=	'';
			switch(type){
				case 'Announcement':
					edit_link =	'edit_announcement';
					break;
				case 'Press Release':
					edit_link =	'edit_pressrelease';
					break;
				case 'Event':
					edit_link =	'edit_event';
					break;
				case 'Downloadable':
					edit_link =	'edit_downloadable';
					break;
				case 'Video':
					edit_link =	'edit_video';
					break;
				case 'WhitePaper':
					edit_link =	'edit_whitepaper';
					break;
				case 'Tag':
					edit_link =	'edit_tag';
					break;
				case 'Press Kit':
					edit_link =	'edit-press-kit';
					break;
					
			}
			fields_array['type']	= type;	
			fields_array['edit_link']	= '/'+edit_link+'/'+idArray[1];	
			fields_array['id_value']	= idArray[1];	
			obj2.forEach(function(fields, key){
				fields_array[fields.fieldname]	= fields.data;	
		    });
			retrunData.push(fields_array); 
	   
	    });
   return retrunData;
  
  } 
  
  
  static getSingleData(ObjData, type='Announcement'): any{
         var obj =   ObjData.attribute;
		 var fields_array:any 	= [];
         obj.forEach(function(value, index){
			fields_array[value.name]	= value.data;
	    });
		
		
   return fields_array;
  
  } 
  
  static getAppURL(): any{
	  //var APP_URL 	=	'http://localhost:4200/'; // For LOCAL
	  var APP_URL 	=	'https://vdlsyficmapda01.cpu.syfbank.com:7002/contenthub/'; // For LIVE
	  //var APP_URL 		=	'http://localhost/content-auth/'; // For LOCAL DEV
	  return APP_URL;
  }
  
  static getPublist(): any{
	  return "ContentHub";
  }
  static getFileSize(): any{
	  return 100000;
  }
  
  static getThumbImageHeight(): any{
	  return 850;
  }
  static getThumbImageWidth(): any{
	 return 1200;
  }
  static getThumbImageError(): any{
	 return "Must be 1200px width by 850px height";
  }
  
  
  static getApproveStatus(): any{
	  return "PL";
  }
  
  static getSaveStatus(): any{
	  return "ED";
  }
  

  


}