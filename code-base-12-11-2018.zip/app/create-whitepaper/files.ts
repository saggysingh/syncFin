export class Files {

  constructor(
    public id: number,
	public file: File,

   ) {  }

}