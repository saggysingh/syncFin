import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { Downloadable } from '../model/downloadable_model';
import { Functions } from '../global/functions';
declare var $;

@Component({
  selector: 'app-create-downloadable',
  templateUrl: './create-downloadable.component.html',
  styleUrls: ['./create-downloadable.component.css']
})
export class CreateDownloadableComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	selectedFile:any =  null;
	pdfFile:any =  null;	
	ticket: any	=	'';
	public loading = false;
	readtextfile:any ='';
	filetextcode:any ='';
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   
	   
	  this.model = new Downloadable('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''); 
	   var username	=	localStorage.hasOwnProperty("username");
			if(!username){
				this.router.navigate(['']);
			}
	}

	ngOnInit() {
	}
	  
  	onSubmit() {
	
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		 this.errors.pdf_file = '';
		   if(CustomValidator.emptyValidation(this.pdfFile)===false){
		     this.errors.pdf_file = 'PDF is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			     this.errors.pdf_file = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }  
		   
		   
		   
		   
		if(error_flag ==1){
			  return false;
		}
		
		this.CreateDownload();
	  }  
  
  CreateDownload() {
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedDownload 		    = 	'No';
			if(this.model.FeaturedDownload){		
			  this.data.FeaturedDownload 		= 	'Yes';	
			}
			//add timestamp in file name
			var unix = Math.round(+new Date()/1000);
			var file_name 	=	this.selectedFile.name;
			let file_nameArray = file_name.split(".");
			file_nameArray.reverse();
			let file_ext 	=	file_nameArray[0];
			file_nameArray.splice(0, 1);
			file_nameArray.reverse();
			file_name	=	file_nameArray.join("-");
			var new_file_name 	=	file_name+"-"+unix+"."+file_ext;	
			
			/* Create file name for PDF file */
			var unix_pdf = Math.round(+new Date()/1000);
			var file_name_pdf 	=	this.pdfFile.name;
			let file_name_pdfArray = file_name_pdf.split(".");
			file_name_pdfArray.reverse();
			let file_ext_pdf 	=	file_name_pdfArray[0];
			file_name_pdfArray.splice(0, 1);
			file_name_pdfArray.reverse();
			var file_name_pdf	=	file_name_pdfArray.join("-");
			var new_file_name_pdf 	=	file_name_pdf+"-"+unix_pdf+"."+file_ext_pdf;	
			
			
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			let formData 	=	{"attribute":[{"name":"template","data":"Hub_DownloadableSectionLayout"}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": "view"}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedDownload","data":{"stringValue": this.data.FeaturedDownload}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":new_file_name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextfile,"href":""}}}, {"name":"ThumbnailImageAlt","data":{"stringValue":this.model.ThumbnailImageAlt}},{"name":"ThumbnailImageTooltip","data":{"stringValue":this.model.ThumbnailImageTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Content","data":{"stringValue":this.model.Content}}, {"name":"DownloadableTitle","data":{"stringValue":this.model.DownloadableTitle}}, {"name":"PDF","data":{"blobValue":{"filename":new_file_name_pdf,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextpdffile,"href":""}}}, {"name":"DownloadableLinkText","data":{"stringValue":this.model.DownloadableLinkText}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_DownloadableSection", "createddate": this.model.CreatedDate }
			
			this.rest.AddHubDownloadable(formData, this.ticket).subscribe(response2 => {
					localStorage.setItem("success_msg", "Your Download has been created successfully.");
					let idString =	response2.id;
					let idArray = idString.split(":");
					let id 	=	idArray[1];
					this.loading = false;
					this.router.navigate(['/edit_downloadable/'+id]);

				}, error => {
					this.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
  }
  
  	  onFileSelected(event){
         this.selectedFile = event.target.files[0];
		 this.errors.thumbnail_image 	=	"";
		 if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			 this.errors.thumbnail_image = 'Wrong format file.'; 
			 return false;
		 }
		 var this_object 	=	this;
		 var file, img;
		 var _URL = window.URL;
		 if ((file = this.selectedFile)) {
			img = new Image();
			img.onload = function() {
				var height 	=	Functions.getThumbImageHeight();
				var width 	=	Functions.getThumbImageWidth();
				if(!(this.width>=width && this.height>=height)){
					this_object.errors.thumbnail_image = Functions.getThumbImageError(); 
					return false;
				}
			};
			img.src = _URL.createObjectURL(file);
		 }
	     let fileReader = new FileReader();
		fileReader.onload = (e) => {	
			let string_file:any;
			string_file		=	fileReader.result;
			var solution	=	string_file.split("base64,");
			this.readtextfile 	=	solution[1];
			
		}
		this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
		 
		 $('#image-1').html(this.selectedFile.name);
	  }
	  
	  onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 this.errors.pdf_file = "";
		 if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			 this.errors.pdf_file = 'Wrong format file.'; 
			 return false;
		 }
		 let fileReader = new FileReader();
		fileReader.onload = (e) => {	
			let string_file:any;
			string_file		=	fileReader.result;
			var solution	=	string_file.split("base64,");
			this.readtextpdffile 	=	solution[1];
			
		}
		this.filetextpdfcode	=	fileReader.readAsDataURL(this.pdfFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }


}
