import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
		data:any;
		errors:any;
		model: any = {};
		global: string = "";
		APP_URL: string="";
		
	  constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
		this.data 					= {};
		this.errors 				= {};
		localStorage.clear();
		this.APP_URL	=	Functions.getAppURL();
		
	  }
	ngOnInit() {
		
	}
	onSubmit() {
		this.data.username 			= 	this.model.username;	
		this.data.password 			= 	this.model.password;	
		this.getLogin();
	  }  
  
  generateGrantedTickets() {
	//this.rest.generateGrantedTickets(this.data);
  }
  
  getLogin() {
	this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1);
			localStorage.setItem("username", this.model.username);
			localStorage.setItem("password", this.model.password);
			localStorage.setItem("ticket", response1.body);
			this.router.navigate(['/dashboard']);
			
		}, error => {
				this.global 	=	'Please enter valid username and password.';
		});
	}, error => {
			this.global 	=	'Please enter valid username and password.';
	});
  }
  

}
