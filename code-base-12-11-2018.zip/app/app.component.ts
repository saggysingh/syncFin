import { Component } from '@angular/core';
import { Renderer2 } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'content-authority';
  
  
  
   constructor(private renderer: Renderer2, private router: Router) {
    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
          let currentUrlSlug = event.url.slice(1)
		  this.renderer.removeClass(document.body, 'gray-background');
          switch(currentUrlSlug){
			  case 'dashboard':
			  case 'create-edit-content':
			 	this.renderer.addClass(document.body, 'gray-background');
				break;				
		  }
          
        }
      });
 
  }
}
