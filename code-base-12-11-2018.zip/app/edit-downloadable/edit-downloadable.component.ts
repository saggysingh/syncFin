import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { Downloadable } from '../model/downloadable_model';
import { Functions } from '../global/functions';
declare var $;

@Component({
  selector: 'app-edit-downloadable',
  templateUrl: './edit-downloadable.component.html',
  styleUrls: ['./edit-downloadable.component.css']
})
export class EditDownloadableComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	selectedFile:any =  null;
	pdfFile:any =  null;
	id: any;
	sub: any;
	ticket: any	=	'';
	public loading = false;
	readtextfile:any ='';
	filetextcode:any ='';
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   
	   
	  this.model = new Downloadable('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''); 
	  var username	=	localStorage.hasOwnProperty("username");
	if(!username){
		this.router.navigate(['']);
	}
	}

	ngOnInit() {
		this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetDownloadable();
		});
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
		localStorage.removeItem("success_msg");
		localStorage.removeItem("error_msg");
	}
	  
  	onSubmit() {
	
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     //this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      //error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		 this.errors.pdf_file = '';
		   if(CustomValidator.emptyValidation(this.pdfFile)===false){
		    // this.errors.pdf_file = 'PDF file is required'; 
		     // error_flag = 1;
		   }else{
		       if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			     this.errors.pdf_file = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }  
		   
		   
		if(error_flag ==1){
			  return false;
		}
		
		this.EditDownloadable();
	  } 

	GetDownloadable() {
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
				this.rest.GetHubDownloadable(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					this.model.name 				=	response2.name;
					this.model.template 			=	fields.template.stringValue;
					this.model.PageTitle 			=	fields.PageTitle.stringValue;
					this.model.PageMetaDescription 				=	'';
					if(fields.PageMetaDescription!=null){
						this.model.PageMetaDescription 		=	fields.PageMetaDescription.stringValue;
					}
					this.model.PageKeywords 				=	'';
					if(fields.PageKeywords!=null){
						this.model.PageKeywords 		=	fields.PageKeywords.stringValue;
					}
					this.model.PageName 				=	'';
					if(fields.PageName!=null){
						this.model.PageName 			=	fields.PageName.stringValue;
					}
					this.model.PageID 				=	'';
					if(fields.PageID!=null){
						this.model.PageID 			=	fields.PageID.stringValue;
					}
					if(fields.CustomTags!=null){
						let selected_tags	=	fields.CustomTags;
							selected_tags	=	selected_tags.stringList;
						this.model.page_tags 		=	selected_tags.join(",");
						this.model.selected_tags 				=	selected_tags;
						
					}else{
						this.model.page_tags 				=	'';
					}
					this.model.FeaturedDownload 	=	0;
					if(fields.FeaturedDownload!=null){
						var str = fields.FeaturedDownload.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.FeaturedDownload	=	1;
						}
					}else{
						this.model.FeaturedDownload 				=	'no';
					}
					if(fields.ThumbnailImage!=null){
						this.model.thumb_image 			=	fields.ThumbnailImage.blobValue.href;
						this.data.ThumbnailImage 			=	fields.ThumbnailImage.blobValue;
						
					}else{
						this.model.thumb_image 			=	'';
					}
					if(fields.ThumbnailImageAlt!=null){
						this.model.ThumbnailImageAlt 			=	fields.ThumbnailImageAlt.stringValue;
						
					}else{
						this.model.ThumbnailImageAlt 			=	'';
					}
					
					if(fields.ThumbnailImageTooltip!=null){
						this.model.ThumbnailImageTooltip 			=	fields.ThumbnailImageTooltip.stringValue;
						
					}else{
						this.model.ThumbnailImageTooltip 			=	'';
					}
					if(fields.CreatedDate!=null){
						this.model.CreatedDate 			=	fields.CreatedDate.dateValue;
						
					}else{
						this.model.CreatedDate 			=	'';
					}
					if(fields.Title!=null){
						this.model.Title 			=	fields.Title.stringValue;
						
					}else{
						this.model.Title 			=	'';
					}
					if(fields.SubTitle!=null){
						this.model.SubTitle 			=	fields.SubTitle.stringValue;
						
					}else{
						this.model.SubTitle 			=	'';
					}
					if(fields.Content!=null){
						this.model.Content 			=	fields.Content.stringValue;
						
					}else{
						this.model.Content 			=	'';
					}
					if(fields.ShortDescription!=null){
						this.model.ShortDescription 			=	fields.ShortDescription.stringValue;
						
					}else{
						this.model.ShortDescription 			=	'';
					}
					
					if(fields.DownloadableTitle!=null){
						this.model.DownloadableTitle 			=	fields.DownloadableTitle.stringValue;
						
					}else{
						this.model.DownloadableTitle 			=	'';
					}
					if(fields.PDF!=null){
						this.model.pdf_file 			=	fields.PDF.blobValue.href;
						this.data.PDF 					=	fields.PDF.blobValue;
						
					}else{
						this.model.pdf_file 			=	'';
					}					
					if(fields.DownloadableLinkText!=null){
						this.model.DownloadableLinkText 			=	fields.DownloadableLinkText.stringValue;
						
					}else{
						this.model.DownloadableLinkText 			=	'';
					}
					
					
				}, error => {
				//this.router.navigate(['']);
			});
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
	}  	  
  
	EditDownloadable() {
		
		this.loading = true;
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedDownload 		    = 	'No';
			if(this.model.FeaturedDownload){		
			  this.data.FeaturedDownload 		= 	'Yes';	
			}
			this.data.id 	=	Number(this.data.id);
			
			// Condition for thumbnail image
			var file_name 	=	'';
			var foldername 	=	'';
			var filedata 	=	'';
			var href 	=	'';
			if(CustomValidator.emptyValidation(this.selectedFile)===false){
				file_name 	=	this.data.ThumbnailImage.filename;
				foldername 	=	this.data.ThumbnailImage.foldername;
				filedata 	=	this.data.ThumbnailImage.filedata;
				href 	=	this.data.ThumbnailImage.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				
				var unix = Math.round(+new Date()/1000);
				var old_file_name 	=	this.selectedFile.name;
				let file_nameArray = old_file_name.split(".");
				file_nameArray.reverse();
				let file_ext 	=	file_nameArray[0];
				file_nameArray.splice(0, 1);
				file_nameArray.reverse();
				old_file_name	=	file_nameArray.join("-");
				var new_file_name 	=	old_file_name+"-"+unix+"."+file_ext;
				file_name 	=	new_file_name;
				foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
				filedata 	=	this.readtextfile;
				href 		=	'';
			}
			
			// Condition for PDF File
			var file_name_pdf 	=	'';
			var foldername_pdf 	=	'';
			var filedata_pdf 	=	'';
			var href_pdf 	=	'';
			if(CustomValidator.emptyValidation(this.pdfFile)===false){
				file_name_pdf 	=	this.data.PDF.filename;
				foldername_pdf 	=	this.data.PDF.foldername;
				filedata_pdf 	=	this.data.PDF.filedata;
				href_pdf 		=	this.data.PDF.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				
				var unix_pdf = Math.round(+new Date()/1000);
				var old_file_name_pdf 	=	this.pdfFile.name;
				let file_nameArray = old_file_name_pdf.split(".");
				file_nameArray.reverse();
				let file_ext_pdf 	=	file_nameArray[0];
				file_nameArray.splice(0, 1);
				file_nameArray.reverse();
				old_file_name_pdf	=	file_nameArray.join("-");
				var new_file_name_pdf 	=	old_file_name_pdf+"-"+unix_pdf+"."+file_ext_pdf;
				file_name_pdf 	=	new_file_name_pdf;
				foldername_pdf 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
				filedata_pdf 	=	this.readtextfile;
				href_pdf 		=	'';
			}
			
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			
			let formData 	=	{"attribute":[{"name":"id", "data":{"longValue":this.data.id}}, {"name":"template","data":{"stringValue":"Hub_DownloadableSectionLayout"}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": "view"}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedDownload","data":{"stringValue": this.data.FeaturedDownload}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"ThumbnailImageAlt","data":{"stringValue":this.model.ThumbnailImageAlt}},{"name":"ThumbnailImageTooltip","data":{"stringValue":this.model.ThumbnailImageTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Content","data":{"stringValue":this.model.Content}}, {"name":"DownloadableTitle","data":{"stringValue":this.model.DownloadableTitle}}, {"name":"PDF","data":{"blobValue":{"filename":file_name_pdf,"foldername":foldername_pdf,"filedata": filedata_pdf,"href":href_pdf}}}, {"name":"DownloadableLinkText","data":{"stringValue":this.model.DownloadableLinkText}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "id":'Hub_Downloadable_C:'+this.data.id, "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_DownloadableSection", "createddate": this.model.CreatedDate }
			
			
				this.rest.EditHubDownloadable(formData, this.ticket, this.data).subscribe(response2 => {
							this.loading = false;
							//localStorage.setItem("success_msg", "Your Download has been updated successfully.");
							this.success 	=	"Your Download has been updated successfully.";
							//this.router.navigate(['/create-edit-content']);

							}, error => {
									this.loading = false;
									localStorage.setItem("error_msg", "You are not authorize to access this.");
									this.router.navigate(['/create-edit-content']);
								});
					}, error => {
							this.loading = false;
							this.router.navigate(['']);
					});
				}, error => {
						this.loading = false;
						this.router.navigate(['']);
				});
	}
	
	DeleteDownload(){
		if(confirm("Are you sure to delete Downloadable")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.DeleteHubDownloadable(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						localStorage.setItem("success_msg", "Your download has been deleted successfully.");
						this.router.navigate(['/create-edit-content']);

					}, error => {
						this.loading = false;
							localStorage.setItem("error_msg", "You are not authorize to access this.");
							this.router.navigate(['/create-edit-content']);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
		}
	}
   
  	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}
	
	  onFileSelected(event){
         this.selectedFile = event.target.files[0];
		 this.errors.thumbnail_image 	=	"";
		 if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			 this.errors.thumbnail_image = 'Wrong format file.'; 
			 return false;
		 }
		 var this_object 	=	this;
		 var file, img;
		 var _URL = window.URL;
		 if ((file = this.selectedFile)) {
			img = new Image();
			img.onload = function() {
				var height 	=	Functions.getThumbImageHeight();
				var width 	=	Functions.getThumbImageWidth();
				if(!(this.width>=width && this.height>=height)){
					this_object.errors.thumbnail_image = Functions.getThumbImageError(); 
					return false;
				}
			};
			img.src = _URL.createObjectURL(file);
		 }
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  
	  onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 this.errors.pdf_file = "";
		 if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			 this.errors.pdf_file = 'Wrong format file.'; 
			 return false;
		 }
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string:any;
				string		=	fileReader.result;
				var solution	=	string.split("base64,");
				this.readtextpdffile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
	  
	  ApproveAsset(){
		 if(confirm("Are you sure to Approve Downloadable?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallApproveAsset(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						this.success 	=	"Your Downloadable has been approved successfully.";
						this.router.navigate(['/edit_downloadable/'+this.data.id]);

					}, error => {
						this.loading = false;
							this.success 	=	"Your Downloadable has been approved successfully.";
							this.router.navigate(['/edit_downloadable/'+this.data.id]);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	  }
	  
	  PreviewAsset(){
		  var previewURL 	=	this.rest.CallGetDownlodablePreviewURL(this.data);
		  window.open(previewURL);
			return false;
	  }


}
