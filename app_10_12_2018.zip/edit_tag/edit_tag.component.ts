import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';
declare var $;
@Component({
  selector: 'app-edit-tag',
  templateUrl: './edit_tag.component.html',
  styleUrls: ['./edit_tag.component.css']
})
export class EditTagComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	id: any;
	sub: any;
	tag: any={};
	ticket: any	=	'';
	error:any 	=	'';
	success:any 	=	'';
	public loading = false;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
		var username	=	localStorage.hasOwnProperty("username");
			if(!username){
				this.router.navigate(['']);
			}

	}

	ngOnInit() {
		this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetTag();
		});
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
	  localStorage.removeItem("success_msg");
	  localStorage.removeItem("error_msg");
		
	}
	  
	onSubmit() {
		this.data.Name 		        = 	this.model.file_name;	
		this.data.TagName 			= 	this.model.tag_name;	
		var form_error 	=	0;
		var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
		 this.errors.tag_name 	=	'';
		 this.errors.file_name 	=	'';
		if(format.test(this.data.Name)){
		  form_error 	=	1;
		  this.errors.file_name 	=	'Special characters not allowed.';
		}
		if(format.test(this.data.TagName)){
		  form_error 	=	1;
		  this.errors.tag_name 	=	'Special characters not allowed.';
		}
		if(form_error){
			return false;
		}
		
		
		this.EditTag();
	  }  

	GetTag() {
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
			
				this.rest.CallGetTag(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					this.model.file_name 		=	response2.name;
					this.model.tag_name 		=	fields.tagname.stringValue; 
				}, error => {
						//this.router.navigate(['']);
					});
		}, error => {
				this.router.navigate(['']);
		});
	}, error => {
			this.router.navigate(['']);
	});
		
		
		
		
	}  

	EditTag() {
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.data.name 		        = 	this.model.file_name;	
		this.data.TagName 			= 	this.model.tag_name;
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			console.log(this.data);
		this.ticket 	=	response1.body;
		this.data.id 	=	Number(this.data.id);
		var formData 	=	{"attribute":[{"name":"id", "data":{"longValue":this.data.id}}, {"name":"name", "data":{"stringValue":this.data.name}}, {"name":"tagname", "data":{"stringValue":this.data.TagName}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "id":'Custom_Tag:'+this.data.id, "name":this.data.Name, "tagname":this.data.TagName, "description":"",  "publist":"ContentHub"}
		//formData = JSON.stringify(formData);
		this.rest.CallEditTag(formData, this.ticket, this.data.id).subscribe(response2 => {
				this.loading = false;
				//localStorage.setItem("success_msg", "Your tag has been updated successfully.");
				this.success 	=	"Your tag has been updated successfully.";
				//this.router.navigate(['/create-edit-content']);

			}, error => {
					this.loading = false;
					localStorage.setItem("error_msg", "You are not authorize to access this.");
					this.router.navigate(['/create-edit-content']);
				});
		}, error => {
			this.loading = false;
			this.router.navigate(['']);
		});
		}, error => {
			this.loading = false;
			this.router.navigate(['']);
		});
		
	}
	
	DeleteTag(){
		if(confirm("Are you sure to delete Tag")) {
			this.loading = true;
			this.data.username 			= 	localStorage.getItem("username");	
			this.data.createdby 		= 	localStorage.getItem("username");	
			this.data.password 			= 	localStorage.getItem("password");
			
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallDeleteTag(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						localStorage.setItem("success_msg", "Your tag has been deleted successfully.");
						this.router.navigate(['/create-edit-content']);

					}, error => {
						this.loading = false;
							localStorage.setItem("error_msg", "You are not authorize to access this.");
							this.router.navigate(['/create-edit-content']);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	}

	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//SAVE button functionality
				   //APPROVE button functionality
					approveButton.click(function(event) {
						event.preventDefault();
						previewButton.removeClass('inactive');
						deleteButton.addClass('inactive');
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}

   
  

}
