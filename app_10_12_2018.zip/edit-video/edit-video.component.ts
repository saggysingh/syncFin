import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';
import { CustomValidator } from '../custom/validation';
declare var $;

@Component({
  selector: 'app-edit-video',
  templateUrl: './edit-video.component.html',
  styleUrls: ['./edit-video.component.css']
})
export class EditVideoComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	page_tags_arr:any =[];
	id: any;
	sub: any;
	public loading = false;
	ticket:any	=	'';
	selectedFile:File 	=  null;
	readtextfile:any 	=	'';
	filetextcode:any 	=	'';
	video_poster:File 	=  null;
	readtextposeterfile:any 	=	'';
	filetextpostercode:any 	=	'';
	video_mp4:File 		=  null;
	readtextmp4file:any 	=	'';
	filetextmp4code:any 	=	'';
	video_ogg:File 		=  null;
	readtextoggfile:any 	=	'';
	filetextoggcode:any 	=	'';
	video_webm:File 	=  null;
	readtextwebmfile:any 	=	'';
	filetextwebmcode:any 	=	'';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   var username	=	localStorage.hasOwnProperty("username");
		if(!username){
			this.router.navigate(['']);
		}
	}

	ngOnInit() {
	  this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetVideo();
		});
		this.selectOption(this.model.VideoType);
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
		localStorage.removeItem("success_msg");
		localStorage.removeItem("error_msg");
	}
	
	
	onFileSelected(event){
          //console.log(event);
	     this.selectedFile = <File>event.target.files[0];
		 this.errors.thumbnail_image 	=	"";
		 if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			 this.errors.thumbnail_image = 'Wrong format file.'; 
			 return false;
		 }
		 var this_object 	=	this;
		 var file, img;
		 var _URL = window.URL;
		 if ((file = this.selectedFile)) {
			img = new Image();
			img.onload = function() {
				var height 	=	Functions.getThumbImageHeight();
				var width 	=	Functions.getThumbImageWidth();
				if(!(this.width>=width && this.height>=height)){
					this_object.errors.thumbnail_image = Functions.getThumbImageError(); 
					return false;
				}
			};
			img.src = _URL.createObjectURL(file);
		 }
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
		}
		this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  onVideoPoster(event){
         this.video_poster = <File>event.target.files[0];
		 this.errors.video_poster = '';
		 if(CustomValidator.imageExtensionValidation(this.video_poster)===false){
			 this.errors.video_poster = 'Wrong format file.'; 
			 return false;
		   }
		  var this_object 	=	this;
		 var file, img;
		 var _URL = window.URL;
		 if ((file = this.video_poster)) {
			img = new Image();
			img.onload = function() {
				var height 	=	4700;
				var width 	=	2100;
				if(!(this.width>=width && this.height>=height)){
					this_object.errors.video_poster = "Must be 4700px width by 2100px height"; 
					return false;
				}
			};
			img.src = _URL.createObjectURL(file);
		 }
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextposeterfile 	=	solution[1];
		}
		this.filetextpostercode	=	fileReader.readAsDataURL(this.video_poster);
	     $('#video_poster').html(this.video_poster.name);
	  }
	  
	  onVideoMp4(event){
         this.video_mp4 = <File>event.target.files[0];
		 this.errors.video_mp4 	=	'';
		 if(CustomValidator.videoExtensionValidation(this.video_mp4,'mp4')===false){
			 this.errors.video_mp4 = 'Wrong format file.'; 
			  return false;
		 }
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
			let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextmp4file 	=	solution[1];
		}
		this.filetextmp4code	=	fileReader.readAsDataURL(this.video_mp4);
	     $('#video_mp4').html(this.video_mp4.name);
	  }
	  
	  onVideoOgg(event){
         this.video_ogg = <File>event.target.files[0];
		 this.errors.video_ogg = ''; 
		 if(CustomValidator.videoExtensionValidation(this.video_ogg,'ogg')===false){
			 this.errors.video_ogg = 'Wrong format file.'; 
			  return false;
		 }
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextoggfile 	=	solution[1];
		}
		this.filetextoggcode	=	fileReader.readAsDataURL(this.video_ogg);
	     $('#video_ogg').html(this.video_ogg.name);
	  }
	  
	  onVideoWebm(event){
         this.video_webm = <File>event.target.files[0];
		 this.errors.video_webm = ''; 
		 if(CustomValidator.videoExtensionValidation(this.video_webm,'webm')===false){
			 this.errors.video_webm = 'Wrong format file.'; 
			 return false;
		 }
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextwebmfile 	=	solution[1];
		}
		this.filetextwebmcode	=	fileReader.readAsDataURL(this.video_webm);
	     $('#video_webm').html(this.video_webm.name);
	  }
	
	  
  	onSubmit() {
		
	    var error_flag = 0;
		this.errors.youtube_id = '';
		this.errors.thumbnail_image = '';
		this.errors.video_url = '';
		this.errors.video_poster = '';
		this.errors.video_mp4 = '';
		this.errors.video_ogg = '';
		this.errors.video_webm = '';
		if(this.model.VideoType=='YouTube ID'){
		   if(CustomValidator.emptyValidation(this.model.YouTubeID)===false){
		       this.errors.youtube_id = 'Youtube-Id is required'; 
		     error_flag = 1;
		   }
		}
		  if(CustomValidator.emptyValidation(this.selectedFile)===false){
		  
		     //  this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      //error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   } 
		   
		   if(CustomValidator.emptyValidation(this.video_poster)===false){
		       //this.errors.video_poster = 'Video Poster is required'; 
		      // error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.video_poster)===false){
			     this.errors.video_poster = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		

		if(this.model.VideoType=='External Video URL'){
		   if(CustomValidator.emptyValidation(this.model.ExternalVideoURL)===false){
		       this.errors.video_url = 'Video Url is required'; 
		       error_flag = 1;
		   }
		}
		
		if(this.model.VideoType=='Internal Video'){
			if(CustomValidator.emptyValidation(this.video_mp4)===false){
		       //this.errors.video_mp4 = 'Video MP4 is required'; 
		       //error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_mp4,'mp4')===false){
			     this.errors.video_mp4 = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		   
		   	if(CustomValidator.emptyValidation(this.video_ogg)===false){
		      // this.errors.video_ogg = 'Video OGG is required'; 
		       //error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_ogg,'ogv')===false){
			     this.errors.video_ogg = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		   	if(CustomValidator.emptyValidation(this.video_webm)===false){
		       //this.errors.video_webm = 'Video WEBM is required'; 
		       //error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_webm,'webm')===false){
			     this.errors.video_webm = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		}
      	if(error_flag ==1){
		      return false;
		}
	
    	this.EditVideo();
	  } 

	GetVideo() {
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
				this.rest.CallGetVideo(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					this.model.name 				=	response2.name;
					this.model.PageTitle 			=	fields.PageTitle.stringValue;
					this.model.PageMetaDescription 				=	'';
					if(fields.PageMetaDescription!=null){
						this.model.PageMetaDescription 		=	fields.PageMetaDescription.stringValue;
					}
					this.model.PageKeywords 				=	'';
					if(fields.PageKeywords!=null){
						this.model.PageKeywords 		=	fields.PageKeywords.stringValue;
					}
					this.model.PageName 				=	'';
					if(fields.PageName!=null){
						this.model.PageName 			=	fields.PageName.stringValue;
					}
					this.model.PageID 				=	'';
					if(fields.PageID!=null){
						this.model.PageID 			=	fields.PageID.stringValue;
					}
					if(fields.CustomTags!=null){
						let selected_tags	=	fields.CustomTags;
							selected_tags	=	selected_tags.stringList;
						this.model.page_tags 		=	selected_tags.join(",");
						this.model.selected_tags 				=	selected_tags;
						
					}else{
						this.model.page_tags 				=	'';
					}
					if(fields.FeaturedVideo!=null){
						this.model.FeaturedVideo 	=	0;
						var str = fields.FeaturedVideo.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.FeaturedVideo	=	1;
						}
						
					}else{
						this.model.FeaturedVideo 				=	'no';
					}
					if(fields.ThumbnailImage!=null){
						this.model.thumb_image 			=	fields.ThumbnailImage.blobValue.href;
						this.data.ThumbnailImage 			=	fields.ThumbnailImage.blobValue;
						
					}else{
						this.model.thumb_image 			=	'';
					}
					if(fields.ThumbnailAlt!=null){
						this.model.ThumbnailAlt 			=	fields.ThumbnailAlt.stringValue;
						
					}else{
						this.model.ThumbnailAlt 			=	'';
					}
					
					if(fields.ThumbnailTooltip!=null){
						this.model.ThumbnailTooltip 			=	fields.ThumbnailTooltip.stringValue;
						
					}else{
						this.model.ThumbnailTooltip 			=	'';
					}
					if(fields.CreatedDate!=null){
						this.model.CreatedDate 			=	fields.CreatedDate.dateValue;
						
					}else{
						this.model.CreatedDate 			=	'';
					}
					if(fields.Title!=null){
						this.model.Title 			=	fields.Title.stringValue;
						
					}else{
						this.model.Title 			=	'';
					}
					if(fields.ShortContent!=null){
						this.model.ShortContent 			=	fields.ShortContent.stringValue;
						
					}else{
						this.model.ShortContent 			=	'';
					}
					if(fields.Content!=null){
						this.model.Content 			=	fields.Content.stringValue;
						
					}else{
						this.model.Content 			=	'';
					}
					if(fields.VideoType!=null){
						this.model.VideoType 			=	fields.VideoType.stringValue;
						
					}else{
						this.model.VideoType 			=	'';
					}
					if(fields.YouTubeID!=null){
						this.model.YouTubeID 			=	fields.YouTubeID.stringValue;
						
					}else{
						this.model.YouTubeID 			=	'';
					}
					if(fields.ExternalVideoURL!=null){
						this.model.ExternalVideoURL 			=	fields.ExternalVideoURL.stringValue;
						
					}else{
						this.model.ExternalVideoURL 			=	'';
					}
					if(fields.MP4!=null){
						this.model.mp4_video 			=	fields.MP4.blobValue.href;
						this.data.MP4 					=	fields.MP4.blobValue;
						
					}else{
						this.model.mp4_video 			=	'';
					}
					if(fields.OGG!=null){
						this.model.ogg_video 			=	fields.OGG.blobValue.href;
						this.data.OGG 					=	fields.OGG.blobValue;
						
					}else{
						this.model.ogg_video 			=	'';
					}
					if(fields.WEBM!=null){
						this.model.webm_video 			=	fields.WEBM.blobValue.href;
						this.data.WEBM 					=	fields.WEBM.blobValue;
						
					}else{
						this.model.webm_video 			=	'';
					}
					if(fields.VideoImage!=null){
						this.model.vimage 			=	fields.VideoImage.blobValue.href;
						this.data.VideoImage 					=	fields.VideoImage.blobValue;
						
					}else{
						this.model.vimage 			=	'';
					}
					if(fields.EmailSubject!=null){
						this.model.EmailSubject 			=	fields.EmailSubject.stringValue;
						
					}else{
						this.model.EmailSubject 			=	'';
					}
					if(fields.VideoImageAlt!=null){
						this.model.VideoImageAlt 			=	fields.VideoImageAlt.stringValue;
						
					}else{
						this.model.VideoImageAlt 			=	'';
					}
					if(fields.VideoImageTooltip!=null){
						this.model.VideoImageTooltip 			=	fields.VideoImageTooltip.stringValue;
						
					}else{
						this.model.VideoImageTooltip 			=	'';
					}
					if(fields.DataReason!=null){
						this.model.DataReason 			=	fields.VideoImageTooltip.stringValue;
						
					}else{
						this.model.DataReason 			=	'';
					}
					if(fields.EmailBody!=null){
						this.model.EmailBody 			=	fields.EmailBody.stringValue;
						
					}else{
						this.model.EmailBody 			=	'';
					}
					if(fields.EmailSubject!=null){
						this.model.EmailSubject 			=	fields.EmailSubject.stringValue;
						
					}else{
						this.model.EmailSubject 			=	'';
					}
					
				}, error => {
				//this.router.navigate(['']);
			});
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
	}  	  
  
	EditVideo() {
		this.loading = true;
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedVideo 		    = 	'No';
			if(this.model.FeaturedVideo){		
			  this.data.FeaturedVideo 		= 	'Yes';	
			}
			this.data.id 	=	Number(this.data.id);
			
			// Condition for thumbnail image
			var file_name 	=	'';
			var foldername 	=	'';
			var filedata 	=	'';
			var href 	=	'';
			if(CustomValidator.emptyValidation(this.selectedFile)===false){
				
				file_name 	=	this.data.ThumbnailImage.filename;
				foldername 	=	this.data.ThumbnailImage.foldername;
				filedata 	=	this.data.ThumbnailImage.filedata;
				href 		=	this.data.ThumbnailImage.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				
				var unix = Math.round(+new Date()/1000);
				var old_file_name 	=	this.selectedFile.name;
				let file_nameArray = old_file_name.split(".");
				file_nameArray.reverse();
				let file_ext 	=	file_nameArray[0];
				file_nameArray.splice(0, 1);
				file_nameArray.reverse();
				var file_name	=	file_nameArray.join("-");
				var new_file_name 	=	file_name+"-"+unix+"."+file_ext;
				file_name 	=	new_file_name;
				foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
				filedata 	=	this.readtextfile;
				href 		=	'';
			}
			
			
			
			// Read Data for Mp4 File
			var mp4_file_name 	=	'';
			var mp4_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var mp4_filedata 	=	'';
			var mp4_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_mp4)===false){
				mp4_file_name 	=	this.data.MP4.filename;
				mp4_foldername 	=	this.data.MP4.foldername;
				mp4_filedata 	=	this.data.MP4.filedata;
				mp4_href 	=	this.data.MP4.href;
			}else{
				//add timestamp in file name
				var unix_mp4 = Math.round(+new Date()/1000);
				var file_name_mp4 	=	this.video_mp4.name;
				let file_name_mp4Array = file_name_mp4.split(".");
				file_name_mp4Array.reverse();
				let file_ext_mp4 	=	file_name_mp4Array[0];
				file_name_mp4Array.splice(0, 1);
				file_name_mp4Array.reverse();
				var file_name_mp4	=	file_name_mp4Array.join("-");
				var new_file_name_mp4 	=	file_name_mp4+"-"+unix_mp4+"."+file_ext_mp4;
				mp4_file_name 	=	new_file_name_mp4;
				mp4_filedata	=	this.readtextmp4file;
			}
			
			// Read Data for OGG File
			var ogg_file_name 	=	'';
			var ogg_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var ogg_filedata 	=	'';
			var ogg_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_ogg)===false){
				ogg_file_name 	=	this.data.OGG.filename;
				ogg_foldername 	=	this.data.OGG.foldername;
				ogg_filedata 	=	this.data.OGG.filedata;
				ogg_href 	=	this.data.OGG.href;
			}else{
				//add timestamp in file name
				var unix_ogg = Math.round(+new Date()/1000);
				var file_name_ogg 	=	this.video_ogg.name;
				let file_name_oggArray = file_name_ogg.split(".");
				file_name_oggArray.reverse();
				let file_ext_ogg 	=	file_name_oggArray[0];
				file_name_oggArray.splice(0, 1);
				file_name_oggArray.reverse();
				var file_name_ogg	=	file_name_oggArray.join("-");
				var new_file_name_ogg 	=	file_name_ogg+"-"+unix_ogg+"."+file_ext_ogg;
				ogg_file_name 	=	new_file_name_ogg;
				ogg_filedata	=	this.readtextoggfile;
			}
			// Read Data for WEBM File
			var webm_file_name 	=	'';
			var webm_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var webm_filedata 	=	'';
			var webm_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_webm)===false){
				webm_file_name 	=	this.data.WEBM.filename;
				webm_foldername 	=	this.data.WEBM.foldername;
				webm_filedata 	=	this.data.WEBM.filedata;
				webm_href 		=	this.data.WEBM.href;
			}else{
				//add timestamp in file name
				var unix_webm = Math.round(+new Date()/1000);
				var file_name_webm 	=	this.video_webm.name;
				let file_name_webmArray = file_name_webm.split(".");
				file_name_webmArray.reverse();
				let file_ext_webm 	=	file_name_webmArray[0];
				file_name_webmArray.splice(0, 1);
				file_name_webmArray.reverse();
				var file_name_webm	=	file_name_webmArray.join("-");
				var new_file_name_webm 	=	file_name_webm+"-"+unix_webm+"."+file_ext_webm;
				webm_file_name 	=	new_file_name_webm;
				webm_filedata	=	this.readtextwebmfile;
			}
			// Read Data for Video poster Image
			var vimage_file_name 	=	'';
			var vimage_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var vimage_filedata 	=	'';
			var vimage_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_poster)===false){
				vimage_file_name 	=	this.data.VideoImage.filename;
				vimage_foldername 	=	this.data.VideoImage.foldername;
				vimage_filedata 	=	this.data.VideoImage.filedata;
				vimage_href 		=	this.data.VideoImage.href;
			}else{
				//add timestamp in file name
				var unix_vimage = Math.round(+new Date()/1000);
				var file_name_vimage 	=	this.video_poster.name;
				let file_name_vimageArray = file_name_vimage.split(".");
				file_name_vimageArray.reverse();
				let file_ext_vimage 	=	file_name_vimageArray[0];
				file_name_vimageArray.splice(0, 1);
				file_name_vimageArray.reverse();
				var file_name_vimage	=	file_name_vimageArray.join("-");
				var new_file_name_vimage 	=	file_name_vimage+"-"+unix_vimage+"."+file_ext_vimage;
				vimage_file_name 	=	new_file_name_vimage;
				vimage_filedata	=	this.readtextposeterfile;
			}
			
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			var formData 	=	{"attribute":[{"name":"id", "data":{"longValue":this.data.id}}, {"name":"template","data":{"stringValue":"Hub_VideoSectionLayout"}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": "view"}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"NewsType","data":{"stringValue":"Press Release"}},{"name":"FeaturedVideo","data":{"stringValue": this.data.FeaturedVideo}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"ThumbnailAlt","data":{"stringValue":this.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this.model.ThumbnailTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"ShortContent","data":{"stringValue":this.model.ShortContent}}, {"name":"Content","data":{"stringValue":this.model.Content}}, {"name":"VideoType","data":{"stringValue":this.model.VideoType}}, {"name":"YouTubeID","data":{"stringValue":this.model.YouTubeID}}, {"name":"ExternalVideoURL","data":{"stringValue":this.model.ExternalVideoURL}}, {"name":"MP4","data":{"blobValue":{"filename":mp4_file_name,"foldername":mp4_foldername,"filedata": mp4_filedata,"href":mp4_href}}}, {"name":"OGG","data":{"blobValue":{"filename":ogg_file_name,"foldername":ogg_foldername,"filedata": ogg_filedata,"href":ogg_href}}}, {"name":"WEBM","data":{"blobValue":{"filename":webm_file_name,"foldername":webm_foldername,"filedata": webm_filedata,"href":webm_href}}}, {"name":"VideoImage","data":{"blobValue":{"filename":vimage_file_name,"foldername":vimage_foldername,"filedata": vimage_filedata,"href":vimage_href}}}, {"name":"VideoImageAlt","data":{"stringValue":this.model.VideoImageAlt}}, {"name":"VideoImageTooltip","data":{"stringValue":this.model.VideoImageTooltip}}, {"name":"DataReason","data":{"stringValue":this.model.DataReason}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "id":'Hub_Video_C:'+this.data.id, "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_VideoSection" , "createddate": this.model.CreatedDate}
			
			
				this.rest.CallEditVideo(formData, this.ticket, this.data).subscribe(response2 => {
					this.loading = false;
					//localStorage.setItem("success_msg", "Your Press Release has been updated successfully.");
					this.success 	=	"Your Video has been updated successfully.";
					//this.router.navigate(['/create-edit-content']);

				}, error => {
						this.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
	}
	
	DeleteVideo(){
		if(confirm("Are you sure to delete Video?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallDeleteVideo(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						localStorage.setItem("success_msg", "Your video has been deleted successfully.");
						this.router.navigate(['/create-edit-content']);

					}, error => {
						this.loading = false;
							localStorage.setItem("error_msg", "You are not authorize to access this.");
							this.router.navigate(['/create-edit-content']);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	}
  selectOption(selet_option){
	  var textValue = $('#'+selet_option).text();
	  //this.model.video_type = textValue;
						
		$('.youtube-video').hide();
		$('.video-url').hide();
		$('.video-set').hide();
		switch(selet_option){
			case 'YouTube ID':
				$(".youtube-video").show();
				break;
			case 'Internal Video':
				$(".video-set").show();
				break;
			case 'External Video URL':
				$(".video-url").show();
				break;
			
		}
  }
  
  	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}
		
		});
	}
	
	
	ApproveAsset(){
		 if(confirm("Are you sure to Approve Video?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallApproveAsset(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						this.success 	=	"Your Video has been approved successfully.";
						//localStorage.setItem("success_msg", "Your press release has been approve successfully.");
						this.router.navigate(['/edit_video/'+this.data.id]);

					}, error => {
						this.loading = false;
							this.success 	=	"Your Video has been approved successfully.";
							this.router.navigate(['/edit_video/'+this.data.id]);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	  }
	  
	  PreviewAsset(){
		  var previewURL 	=	this.rest.CallGetVideoPreviewURL(this.data);
		  window.open(previewURL);
			return false;
	  }


}
