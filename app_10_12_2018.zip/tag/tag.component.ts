import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';

declare var $;
@Component({
  selector: 'app-tag',
  templateUrl: './tag.component.html',
  styleUrls: ['./tag.component.css']
})
export class TagComponent implements OnInit {

	model: any = {};
	data:any = {};
	errors:any = {};
	formData:any = {};
	ticket:any = '';
	APP_URL: string="";
	public loading = false;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
		this.APP_URL	=	Functions.getAppURL();
		var username	=	localStorage.hasOwnProperty("username");
			if(!username){
				this.router.navigate(['']);
			}
	}

	ngOnInit() {
		
		
		
	}
	  
  	onSubmit() {
		var form_error 	=	0;
		this.data.Name 		        = 	this.model.file_name;	
		this.data.TagName 			= 	this.model.tag_name;
		var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
		 this.errors.tag_name 	=	'';
		 this.errors.file_name 	=	'';
		if(format.test(this.data.Name)){
		  form_error 	=	1;
		  this.errors.file_name 	=	'Special characters not allowed.';
		}
		if(format.test(this.data.TagName)){
		  form_error 	=	1;
		  this.errors.tag_name 	=	'Special characters not allowed.';
		}
		if(form_error){
			return false;
		}
		this.CreateTag();
	  }  
  
  CreateTag() {
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
			
			var formData 	=	{"attribute":[{"name":"name", "data":{"stringValue":this.data.Name}}, {"name":"tagname", "data":{"stringValue":this.data.TagName}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "name":this.data.Name, "description":"",  publist:"ContentHub"}
				
			this.rest.CallAddTag(formData, this.ticket).subscribe(response2 => {
					this.loading = false;
					let idString =	response2.id;
					let idArray = idString.split(":");
					let id 	=	idArray[1];
					localStorage.setItem("success_msg", "Your tag has been created successfully.");
					this.router.navigate(['/edit_tag/'+id]);

				}, error => {
					this.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this.router.navigate(['/create-edit-content']);
					});
		}, error => {
			this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
		this.loading = false;
			this.router.navigate(['']);
	});
  }
  

}
