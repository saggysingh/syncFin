import { Component, OnInit , Input } from '@angular/core';
import { RestService } from '../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Functions } from '../global/functions';


declare var $;
@Component({
  selector: 'app-tag-list',
  templateUrl: './tag-list.component.html',
  styleUrls: ['./tag-list.component.css']
})
export class TagListComponent implements OnInit {
    
	@Input() model: any = {};
	@Input() selected_tags: any;
   	data:any = {};
	errors:any = {};
	lists:any;
    @Input() page_tags_arr:any =[];
    page_tags_list:any =[];
  	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	  this.lists 					= {};
	}

  ngOnInit() {
	  
   	this.getTagList();
  }
  ngOnChanges() {
        let selected_tag 	=	this.selected_tags;
		let selected_tag_array 		=	'';
		if (selected_tag.indexOf(",") !=-1) {
			selected_tag_array 		=	selected_tag.split(",");
		}else{
			selected_tag_array	=	selected_tag;
		}
		this.page_tags_list 	=	selected_tag_array;
	}
  OpenTag(){
    $('.tag_list_modal').addClass('open');
  }
  
  CloseTag(){
    $('.tag_list_modal').removeClass('open');
  }
  
  AddTag(tagval,this_ele){
	   if ($('#'+this_ele).hasClass('add-tag-a')) {
			var index = this.page_tags_list.indexOf(tagval);
			if (index !== -1) {
			   this.page_tags_list.splice(index, 1);
			}
			$('#'+this_ele).removeClass('add-tag-a');
	   }else{
			 this.page_tags_list =  this.page_tags_list || [];
			  this.page_tags_list.push(tagval);
			  $('#'+this_ele).addClass('add-tag-a');
	   }
  }
  
ConfirmSelection(){
 this.model.page_tags = this.page_tags_list.toString();
 $('.tag_list_modal').removeClass('open');
}
  
  
  getTagList() {
       //this.data.created_by = localStorage.getItem("UserName");
       this.data.created_by = localStorage.getItem("username");
	   this.data.username 			= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
       this.data.is_featured = 0;
		/* Call for Content Tag List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentTag(this.data).subscribe(response => {
						this.lists   = Functions.getExtractData(response, 'Tag');
						
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						//this.router.navigate(['']);
				});
			}, error => {
					//this.router.navigate(['']);
			});	
  }

}
