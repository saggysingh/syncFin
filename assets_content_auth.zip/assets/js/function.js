$(document).ready(function(){
	
	if ( $('.edit-content-section').length ) {
           
        }
		
		if ( $('.create-content-menu').length ) {
            $('.create-content-menu').each(function() {
                var these = $(this),
                    saveButton = these.find('.save'),
                    editButton = these.find('.edit'),
                    approveButton = these.find('.approve'),
                    deleteButton = these.find('.delete'),
                    previewButton = these.find('.preview'),
                    pageLocked = these.find('.page-locked'),
                    requiredField = $('.required'),
                    pageType = $('body').attr('page-type'),
                    pageTypeContainer = these.find('.page-type');

                //Disable all inputs by default once page loads
                $('.create-content').addClass('disabled');
                    
                //Add yellow title to menu bar    
                pageTypeContainer.text(pageType);

                //EDIT button functionality
                editButton.click(function(event) {
                    event.preventDefault();
                    $(this).addClass('active');
                    $('.create-content').removeClass('disabled');
                    saveButton.removeClass('inactive');
                    deleteButton.removeClass('inactive');
                    pageLocked.removeClass('inactive'); 
                });

                //SAVE button functionality
                saveButton.click(function(event) {
                    event.preventDefault();
                    $('.required').each(function() {
                        var inputField = $(this).find('input.page-info'),
                            textareaField = $(this).find('textarea.page-info'),
                            divField = $(this).find('div.page-info'),
                            fieldError = $(this).find('.field-error');

                        if ( inputField.length ) {
                            if ( inputField.val().length === 0 ) {
                                fieldError.fadeIn();
                                $(this).addClass('fix-error');
                            } else {
                                fieldError.hide();
                                $(this).removeClass('fix-error');
                            }
                        } else if ( textareaField.length ) {
                            if ( textareaField.val().length === 0 ) {
                                fieldError.fadeIn();
                                $(this).addClass('fix-error');
                            } else {
                                fieldError.hide();
                                $(this).removeClass('fix-error');
                            }
                        } else {
                            if ( divField.is(':empty') ) {
                                fieldError.fadeIn();
                                $(this).addClass('fix-error');
                            } else {
                                fieldError.hide();
                                $(this).removeClass('fix-error');
                            }
                        }
                    });
                    var fixError = $('.fix-error');
                    if (fixError.length) {
                        $('html,body').animate({
                            scrollTop: fixError.offset().top
                        }, 'slow');
                        approveButton.addClass('inactive');
                    } else {
                        approveButton.removeClass('inactive');
                        editButton.removeClass('active');
                    }
    
                });

                //APPROVE button functionality
                approveButton.click(function(event) {
                    event.preventDefault();
                    previewButton.removeClass('inactive');
                    deleteButton.addClass('inactive');
                });

                //PREVIEW button functionality
                previewButton.click(function(event) {
                    event.preventDefault();
                    console.log('preview')
                });

            });
        }
		
		if ( $('.subsection-block').length ) {
            $('.subsection-block').each(function() {
                var these = $(this),
                    addSubsection = $('.add-subsection'),
                    subsectionBase = $('.subsetion-block-base .subsection-base'),
                    newSbsections = $('.new-subsections'),
                    textBlockGalery = these.find('.block-gallery .text-block'),
                    imageBlockGalery = these.find('.block-gallery .image-block');

                //RENDER NEW TEXT BOXES
                function renderNewTextBox () {
                    var newTextEditors = $('.new-blocks .txtEditorBlock');
                    newTextEditors.each(function() {
                        if (!$(this).hasClass('editor-done')) {
                            $(this).Editor();
                            $(this).addClass('editor-done');
                        }
                    });
                    $('.new-blocks .Editor-editor').addClass('page-info');
                }
                
                //ADD SUBSECTION
                addSubsection.click(function(event) {
                    event.preventDefault();
                    subsectionBase.clone().appendTo(newSbsections);
                    $('.new-subsections .subsection-title').addClass('required');
                    $('html,body').animate({
                        scrollTop: addSubsection.offset().top
                    }, 'slow');
                });

                //ADD TEXT BLOCK
                $('body').delegate( '.add-text-block', "click", function(event) {
                    event.preventDefault();
                    var subsectionParent = $(this).parents('.subsection-block'),
                        newBlocksContainer = subsectionParent.find('.new-blocks');
                    textBlockGalery.clone().appendTo(newBlocksContainer);
                    renderNewTextBox();
                    $('.new-blocks .text-block').addClass('required');
                    $('html,body').animate({
                        scrollTop: newBlocksContainer.find('.text-block:last-child').position().top
                    }, 'slow');
                });

                //ADD IMAGE BLOCK
                $('body').delegate( '.add-image-block', "click", function(event) {
                    event.preventDefault();
                    var subsectionParent = $(this).parents('.subsection-block'),
                        newBlocksContainer = subsectionParent.find('.new-blocks');
                    imageBlockGalery.clone().appendTo(newBlocksContainer);
                    $('.new-blocks .image-block').addClass('required');
                    $('html,body').animate({
                        scrollTop: newBlocksContainer.find('.image-block:last-child').position().top
                    }, 'slow');
                });

                //SUBSECTION CONTROLS (move up, move down, delete)
                $('body').delegate( '.move-up-block', "click", function(event) {
                    event.preventDefault();
                    var blockParent = $(this).closest('.block-parent'),
                        prevblockParent = blockParent.prev();
                    blockParent.insertBefore(prevblockParent);
                    $('html,body').animate({
                        scrollTop: blockParent.offset().top
                    }, 'slow');
                });
                $('body').delegate( '.move-down-block', "click", function(event) {
                    event.preventDefault();
                    var blockParent = $(this).closest('.block-parent'),
                        nextblockParent = blockParent.next();
                    blockParent.insertAfter(nextblockParent);
                    $('html,body').animate({
                        scrollTop: blockParent.offset().top
                    }, 'slow');
                });
                $('body').delegate( '.delete-block', "click", function(event) {
                    event.preventDefault();
                    var blockParent = $(this).closest('.block-parent'),
                        prevblockParent = blockParent.prev();
                    blockParent.remove();
                    $('html,body').animate({
                        scrollTop: prevblockParent.offset().top
                    }, 'slow');
                });
                
            });
        }
		
		
    	//EDITOR
        $('.txtEditor').each(function(i) {
            $(this).Editor();
        });
        $('.Editor-editor').addClass('page-info');

        //BROWSE FILE IMAGE
        $('body').delegate( '.browse-file.image .get_file', "click", function(event) {
            event.preventDefault();
            var parentContainer = $(this).parents('.browse-file'),
                imageWidth = parentContainer.attr('image-width'),
                imageHeight = parentContainer.attr('image-height'),
                browseFile = parentContainer.find('.get_file'),
                realBrowseButton = parentContainer.find('.my_file'),
                filePath = parentContainer.find('.customfileupload'),
                imageSizeError = parentContainer.find('.image-size-error'),
                formatFileError = parentContainer.find('.format-file-error'),
                _URL = window.URL || window.webkitURL;

            realBrowseButton.trigger('click');

            realBrowseButton.change(function (e) {
                filePath.html('');
                var file, img,
                    pathVal = $(this).val();
                if ((file = this.files[0])) {
                    img = new Image();
                    img.onload = function() {
                        formatFileError.hide();
                        console.log(this.width);
                        if (this.width < imageWidth || this.height < imageHeight) {
                            imageSizeError.fadeIn();
                        } else {
                            imageSizeError.hide();
                            filePath.html(pathVal);
                        }
                    };
                    img.onerror = function() {
                        imageSizeError.hide();
                        formatFileError.fadeIn();
                    };
                    img.src = _URL.createObjectURL(file);
                }
            });
        });

        //BROWSE FILE PDF
        if ( $('.browse-file').length ) {
            $('.browse-file').each(function() {
                if (!$(this).hasClass('image')) {
                    var these = $(this),
                        browseFile = these.find('.get_file'),
                        realBrowseButton = these.find('.my_file'),
                        filePath = these.find('.customfileupload'),
                        formatFileError = these.find('.format-file-error'),
                        fileFormatAttribute = these.attr('file-format'),
                        fileFormat = '.'+fileFormatAttribute,
                        _URL = window.URL || window.webkitURL;

                    browseFile.click(function(event) {
                        event.preventDefault();
                        realBrowseButton.trigger('click');
                    });

                    realBrowseButton.change(function (e) {

                        filePath.html('');
                        var pathVal = $(this).val(),
                            fileType = pathVal.substr(pathVal.lastIndexOf('.')).toLowerCase();
                        if (fileType === fileFormat) {
                            formatFileError.hide();
                            filePath.html(pathVal);
                        } else {
                            formatFileError.fadeIn();
                        }
                    });
                }
            });
        }            
    	
        //INPUT DATE TIME PICKER
        $('.input-date').each(function(i) {
            var today = new Date();
            $(this).attr('id', 'datetimepicker' + i);

            if ($(this).hasClass('allow-old-date')) {
                $('#datetimepicker' + i).datetimepicker({
                    format: 'MM/DD/YYYY',
                    useCurrent: false
                });
            } else if ($(this).hasClass('month-date-format')) {
                $('#datetimepicker' + i).datetimepicker({
                    viewMode: 'years',
                    format: 'MM/YYYY',
                    useCurrent: false
                });
            } else {
                $('#datetimepicker' + i).datetimepicker({
                    format: 'MM/DD/YYYY',
                    minDate: today
                });
            }
        });

        if ( $('.input-date').length ) {
            $('.input-date').each(function(index){
                var these = $(this),
                    openOptions = these.find('.input-group-addon');

                openOptions.each(function() {
                    $(this).on('click', function(e){
                        e.preventDefault();
                        e.stopPropagation();
                        these.toggleClass('active');
                    });

                    $(document).click(function(){
                        if (these.hasClass('active')) {
                            these.toggleClass('active');
                        }
                    });
                });

                $('#datetimepicker' + index).on('dp.change', function(e) {
                    if (these.hasClass('active')) {
                        these.toggleClass('active');
                    }
                });
            });
        }

        //ADD TAG INPUT
        if ( $('.input-field.tags').length ) {
            $('.input-field.tags').each(function(){
                var these = $(this),
                    addTagsButton = these.find('.add-tags'),
                    removeTag = these.find('.remove-tag');

                addTagsButton.click(function(event) {
                    event.preventDefault();
                    $('.add-tag-popup').addClass('showing-tags');
                    $('html,body').animate({
                        scrollTop: $('.add-tag-popup').offset().top
                    }, 'slow');
                });

                these.delegate( '.remove-tag', 'click', function(event) {
                    event.preventDefault();
                    $( this ).parent().remove();
                });
            });
        }

        //SELECT INPUT
        if ( $('.select-input').length ) {
            $('.select-input').each(function(){
                var these = $(this),
                    selectOptions = these.siblings('.select-options'),
                    selectInput = these.find('input'),
                    optionActive = selectOptions.find('ul li a'),
                    optionFirst = selectOptions.find('ul li:first a'),
                    removeItems = selectOptions.find('.select-input');
                removeItems.remove();
                these.on('click', function(event){
                    event.stopPropagation();
                    event.preventDefault();
                    if (these.hasClass('activeDropdown')) {
                        these.removeClass('activeDropdown');
                        selectOptions.hide();
                    } else {
                        $('.select-options').hide();
                        $('.select-input').removeClass('activeDropdown');
                        selectOptions.show();
                        optionFirst.focus();
                        these.addClass('activeDropdown');
                    }
                });
                optionActive.each(function() {
                    $(this).on('click', function(event){
                        event.preventDefault();
                        var textValue = $(this).text();
                        selectInput.val(textValue);
                        these.focus();
                    });
                });

                $('html').click(function() {
                    if (these.hasClass('activeDropdown')) {
                        these.removeClass('activeDropdown');
                        selectOptions.hide();
                    }
                });
            });
        }
})