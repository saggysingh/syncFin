export class CustomValidator {

// Validates Empty
static emptyValidation(value): any{
  	if (value === "" || value === null || typeof value === "undefined") {
         return false;
        }else{
		return true;
		}
}

static imageExtensionValidation(file):any {
        var fileTypes = ['jpg', 'jpeg', 'png'];  //acceptable file types
        var extension = file.name.split('.').pop().toLowerCase();
		//alert(extension);
        var isSuccess = fileTypes.indexOf(extension) > -1;
        //alert(isSuccess);
        if(isSuccess===true){ 
             return true;
        }
        else{ 
            return false;
        }
   
  }
  
static videoExtensionValidation(file,vtype):any {
        var fileTypes = [vtype];  //acceptable file types
        var extension = file.name.split('.').pop().toLowerCase();
		//alert(extension);
        var isSuccess = fileTypes.indexOf(extension) > -1;
        //alert(isSuccess);
        if(isSuccess===true){ 
             return true;
        }
        else{ 
            return false;
        }
   
  }
static pdfExtensionValidation(file,vtype):any {
        var fileTypes = [vtype];  //acceptable file types
        var extension = file.name.split('.').pop().toLowerCase();
		//alert(extension);
        var isSuccess = fileTypes.indexOf(extension) > -1;
        //alert(isSuccess);
        if(isSuccess===true){ 
             return true;
        }
        else{ 
            return false;
        }
   
  }    

}