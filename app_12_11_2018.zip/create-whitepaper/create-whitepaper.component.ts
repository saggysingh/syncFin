import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';
import { CustomValidator } from '../custom/validation';
declare var $;

@Component({
  selector: 'app-create-whitepaper',
  templateUrl: './create-whitepaper.component.html',
  styleUrls: ['./create-whitepaper.component.css']
})
export class CreateWhitepaperComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;	
	selectedFile:any =  null;
	pdfFile:any =  null;	
	ticket: any	=	'';
	public loading = false;
	readtextfile:any ='';
	filetextcode:any ='';
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	    var username	=	localStorage.hasOwnProperty("username");
			if(!username){
				this.router.navigate(['']);
			}
			
	}

	ngOnInit() {
	}
	  
  	onSubmit() {
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		 this.errors.pdf_file = '';
		   if(CustomValidator.emptyValidation(this.pdfFile)===false){
		     this.errors.pdf_file = 'PDF is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			     this.errors.pdf_file = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }  
		   
		if(error_flag ==1){
			  return false;
		}
		
		this.CreateWhitePaper();
	  }  
  
  CreateWhitePaper() {
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedWhitePaper 		    = 	'No';
			if(this.model.FeaturedWhitePaper){		
			  this.data.FeaturedWhitePaper 		= 	'Yes';	
			}
			//add timestamp in file name
			var unix = Math.round(+new Date()/1000);
			var file_name 	=	this.selectedFile.name;
			let file_nameArray = file_name.split(".");
			file_nameArray.reverse();
			let file_ext 	=	file_nameArray[0];
			file_nameArray.splice(0, 1);
			file_nameArray.reverse();
			var file_name	=	file_nameArray.join("-");
			var new_file_name 	=	file_name+"-"+unix+"."+file_ext;	
			
			//add timestamp in PDF file name
			var unix_pdf = Math.round(+new Date()/1000);			
			var file_name_pdf 	=	this.pdfFile.name;
			let file_name_pdfArray = file_name_pdf.split(".");
			file_name_pdfArray.reverse();
			let file_ext_pdf 	=	file_name_pdfArray[0];
			file_name_pdfArray.splice(0, 1);
			file_name_pdfArray.reverse();
			var file_name_pdf	=	file_name_pdfArray.join("-");
			var new_file_name_pdf 	=	file_name_pdf+"-"+unix_pdf+"."+file_ext_pdf;
			
				
			
			
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 	=	selected_tags.split(",");
			
			
			/* let formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_WhitePaperSectionLayout"}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedWhitePaper","data":{"stringValue": this.data.FeaturedWhitePaper}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":new_file_name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextfile,"href":""}}}, {"name":"ThumbnailAlt","data":{"stringValue":this.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this.model.ThumbnailTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"PDF","data":{"blobValue":{"filename":new_file_name_pdf,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextpdffile,"href":""}}}, {"name":"PDFTitle","data":{"stringValue":this.model.PDFTitle}}, {"name":"Author","data":{"stringValue":this.model.Author}}, {"name":"Contributors","data":{"stringValue":this.model.Contributors}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Abstract","data":{"stringValue":this.model.Abstract}}, {"name":"TableOfContents","data":{"stringList":this.model.TableOfContents}}, {"name":"Footnote","data":{"stringValue":this.model.Footnote}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_WhitePaperSection", "createddate": this.model.CreatedDate } */
			
			let formData 	=	{"attribute":[{"name":"template","data":"Hub_WhitePaperSectionLayout"}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedWhitePaper","data":{"stringValue": this.data.FeaturedWhitePaper}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":new_file_name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextfile,"href":""}}}, {"name":"ThumbnailAlt","data":{"stringValue":this.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this.model.ThumbnailTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"PDF","data":{"blobValue":{"filename":new_file_name_pdf,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextpdffile,"href":""}}}, {"name":"PDFTitle","data":{"stringValue":this.model.PDFTitle}}, {"name":"Author","data":{"stringValue":this.model.Author}}, {"name":"Contributors","data":{"stringValue":this.model.Contributors}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Abstract","data":{"stringValue":this.model.Abstract}}, {"name":"TableOfContents","data":{"stringList":this.model.TableOfContents}}, {"name":"Footnote","data":{"stringValue":this.model.Footnote}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_WhitePaperSection", "createddate": this.model.CreatedDate }
			
			
			this.rest.AddHubWhitePaper(formData, this.ticket).subscribe(response2 => {
					this.loading = false;
					localStorage.setItem("success_msg", "Your Whitepaper has been created successfully.");
					let idString =	response2.id;
					let idArray = idString.split(":");
					let id 	=	idArray[1];
					this.loading = false;
					this.router.navigate(['/edit_whitepaper/'+id]);

				}, error => {
					this.loading = false;
						//localStorage.setItem("error_msg", "You are not authorize to access this.");
						//this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
  }
  
  onFileSelected(event){
         this.selectedFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				this.readtextfile	=	fileReader.result;
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  
	  onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				this.readtextpdffile	=	fileReader.result;
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
  

}
