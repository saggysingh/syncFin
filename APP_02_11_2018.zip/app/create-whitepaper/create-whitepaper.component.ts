import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
declare var $;

@Component({
  selector: 'app-create-whitepaper',
  templateUrl: './create-whitepaper.component.html',
  styleUrls: ['./create-whitepaper.component.css']
})
export class CreateWhitepaperComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	}

	ngOnInit() {
	}
	  
  	onSubmit() {
		this.data.api_type 			= 	'Login';	
		this.data.file_name 		= 	this.model.file_name;	
		this.data.featured 			= 	this.model.featured;	
		this.data.page_title 		= 	this.model.page_title;	
		this.data.page_name 		= 	this.model.page_name;	
		this.data.page_description 	= 	this.model.page_description;	
		this.data.page_keywords 	= 	this.model.page_keywords;	
		this.data.page_tags 		= 	this.model.page_tags;	
		this.data.thumb_title 		= 	this.model.thumb_title;	
		this.data.thumb_alt 		= 	this.model.thumb_alt;	
		this.data.post_title 		= 	this.model.post_title;	
		this.data.short_description	= 	this.model.short_description;	
		this.data.content 			= 	this.model.content;	
		this.data.email_subject 	= 	this.model.email_subject;	
		this.data.email_body 		= 	this.model.email_body;	
		this.CreateTag();
	  }  
  
  CreateTag() {
	this.rest.CallAddAnnouncement(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
			console.log(response.msg);
			this.router.navigate(['/dashboard']);
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  
  TagList(){
       //this.getTagList();
     $( "#TagModal" ).toggle();
	 
  }
  AddTag(tagval){
   this.model.page_tags =tagval;
    $( "#TagModal" ).toggle();
  }
  
  getTagList() {
      var listr;
	 this.rest.CallFeaturedList(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
		  this.lists 	=	response.data;
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  

}
