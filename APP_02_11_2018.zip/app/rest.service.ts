import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RestService {
	baseUrl:any;
	baseUrlContent:any;
	baseUrltest:any;
	httpOptions:any;
	httpOptionsJson:any;
	serverType:any;
	
	
  constructor(private http: HttpClient) {
    this.serverType = 'live';//live
    if(this.serverType=='dev'){
	  this.baseUrltest = 'http://localhost/api/';
	  this.baseUrl = 'assets/json/';
	  this.baseUrlContent = 'assets/json/';
	}
	
	if(this.serverType=='live'){
	  this.baseUrl = 'https://vdlsyficmapda01.cpu.syfbank.com:7002/';
	  //this.baseUrl = 'http://localhost:9080/';
	  this.baseUrlContent = this.baseUrl+'cs/REST/sites/ContentHub/types/';
	  //this.baseUrlContent = this.baseUrl+'cs/REST/sites/avisports/types/';
	}
	
		this.httpOptions = {
		  headers: new HttpHeaders({
			'Content-Type':  'application/x-www-form-urlencoded; charset=utf-8',
			'Content-Length': '35'
		  }), 
		  responseType: 'text',
		  observe: 'response'
		};
		this.httpOptionsJson = {
		  headers: new HttpHeaders({
			 "Content-Type": "application/json; charset=utf-8",
			 "Accept": "application/json",
			 //"X-CSRF-Token": localStorage.getItem("ticket"),
		  })
		};
	}
  
	private extractData(res: Response) {
	 let body = res;
	  return body || { };
	}

	
	
	/* CallApi (data){
		return this.http.post(this.baseUrl+ 'products.php', {data}, {headers: this.httpOptions})
        .map(res => res.json());
    } */
	
	
	CallApi(data): Observable<any> {
	  return this.http.post(this.baseUrl + 'products.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallLogin(data): Observable<any> {
	   var full_url = this.baseUrl + 'cas/v1/tickets';
	   const params = new HttpParams()
		.set('username', data.username)
		.set('password', data.password);
		return this.http.post(full_url, params, this.httpOptions).pipe(); 
		
	}
	
	GetServiceTicket(data): Observable<any> {
		var full_url = data.requestUrl;
		const params1 = new HttpParams()
			.set('service', '*');
			
		return this.http.post(full_url, params1, this.httpOptions).pipe(); 
	}
	
	
	/* Featured list section  */
	CallFeaturedList(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'list.php', {data}).pipe(
		map(this.extractData)); 
	}
	ContentAnnouncement(data): Observable<any> {
		if(data.is_featured==1){
		  var data_url = 'Hub_NewsPost_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:FeaturedNews:equals=yes&field:NewsType:contains=Announcement';
		  var dev_data_url ='announcement_featured_list.json';
		}else{
		  var data_url = 'Hub_NewsPost_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:NewsType:contains=Announcement';
		  var dev_data_url ='announcement_content.json';
		}
 
	   var full_url = this.baseUrlContent +data_url;
	  return this.http.get(full_url,this.httpOptionsJson).pipe();

    }
	ContentPress(data): Observable<any> {
		if(data.is_featured==1){
		  var data_url = 'Hub_NewsPost_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:FeaturedNews:equals=yes&field:NewsType:contains=Press';
	      var dev_data_url ='press_release_featured_list.json';
	  }else{
          var data_url = 'Hub_NewsPost_C/search?multiticket='+data.tickets+'&&field:createdby:equals='+data.created_by+'&field:NewsType:contains=Press';
	       var dev_data_url ='press_release_content.json';
	  }
	   var full_url = this.baseUrlContent +data_url;
	     return this.http.get(full_url,this.httpOptionsJson).pipe();
	 

    }
	
	ContentEvent(data): Observable<any> {
	   if(data.is_featured==1){
		  var data_url = 'Hub_Event_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:FeaturedEvent:equals=yes';
	      var dev_data_url ='event_featured_list.json';
	   
	   }else{
	     var data_url = 'Hub_Event_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by;
	     var dev_data_url ='event_content.json';
	   }
	
	   var full_url = this.baseUrlContent +data_url;
	
		return this.http.get(full_url,this.httpOptionsJson).pipe();

    }
	ContentDownloadable(data): Observable<any> {
		if(data.is_featured==1){
		 var data_url = 	'Hub_Downloadable_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:FeaturedDownload:equals=yes';
	     var dev_data_url ='downloadable_featured_list.json';
	   }else{
	     var data_url = 'Hub_Downloadable_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by;
	     var dev_data_url ='downloadable_content.json';
	  } 

	   var full_url = this.baseUrlContent +data_url;
	   
	
		return this.http.get(full_url,this.httpOptionsJson).pipe();

    }
	ContentVideo(data): Observable<any> {
	 if(data.is_featured==1){
	 	var data_url = 'Hub_Video_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:FeaturedVideo:equals=yes';
	    var dev_data_url ='video_featured_list.json';
	   }else{
	     var data_url = 'Hub_Video_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by;
	     var dev_data_url ='video_content.json';
	   } 
	
	    var full_url = this.baseUrlContent +data_url;
	   
		return this.http.get(full_url,this.httpOptionsJson).pipe();

    }
	ContentWhitPaper(data): Observable<any> {
	 if(data.is_featured==1){
	  	var data_url ='Hub_WhitePaper_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by+'&field:FeaturedWhitePaper:equals=yes';
	    var dev_data_url ='white_paper_featured_list.json';
	   }else{
	     var data_url = 'Hub_WhitePaper_C/search?multiticket='+data.tickets+'&field:createdby:equals='+data.created_by;
	     var dev_data_url ='white_paper_content.json';
	   } 
	
	    var full_url = this.baseUrlContent +data_url;
	   
	 return this.http.get(full_url,this.httpOptionsJson).pipe();

    }
	
	ContentTag(data): Observable<any> {
		var data_url = 'Custom_Tag/search?multiticket='+data.tickets;
	    var dev_data_url ='tag_content.json';
	
	
	    var full_url = this.baseUrlContent +data_url;
		return this.http.get(full_url,this.httpOptionsJson).pipe();

    }
	/* Featured list section  */
	
	
	
	CallAddTag(data, tickets): Observable<any> {
		///var tickets	=	localStorage.getItem("ticket");
		let httpOptionsJson = {
		  headers: new HttpHeaders({
			 "Content-Type": "application/json",
			 "Accept": "application/json",
			  "X-CSRF-Token": tickets,
		  })
		};
		
	   var full_url = this.baseUrlContent + 'Custom_Tag/assets';
	  return this.http.post(full_url, data, httpOptionsJson).pipe(); 
	}
	
	CallEditTag(data, tickets, id): Observable<any> {
		let httpOptionsJson = {
		  headers: new HttpHeaders({
			 "Content-Type": "application/json",
			 "Accept": "application/json",
			  "X-CSRF-Token": tickets,
			//  "id": id,
		  })
		};
		var full_url = this.baseUrlContent + 'Custom_Tag/assets/'+id;
	   
	  return this.http.post(full_url, data, httpOptionsJson).pipe(); 
	}
	
	CallGetTag(data, tickets): Observable<any> {
	
	   var full_url = this.baseUrlContent + 'Custom_Tag/assets/'+data.id+'?multiticket='+tickets;
	  return this.http.get(full_url, this.httpOptionsJson).pipe(); 
	}
	CallDeleteTag(data, tickets): Observable<any> {
		let httpOptionsJson = {
		  headers: new HttpHeaders({
			 "Content-Type": "application/json",
			 "Accept": "application/json",
			  "X-CSRF-Token": tickets,
		  })
		};
	   var full_url = this.baseUrlContent + 'Custom_Tag/assets/'+data.id;
	  return this.http.delete(full_url, httpOptionsJson).pipe(); 
	}
	
	CallAddPressrelease(data, tickets=''): Observable<any> {
		
	   var full_url = this.baseUrlContent + 'Hub_NewsPost_C/assets/';
	  return this.http.post(full_url, data, this.httpOptionsJson).pipe(); 
	}
	
	
	CallGetPressrelease(data, tickets=''): Observable<any> {
		
	  var full_url = this.baseUrlContent + 'Hub_NewsPost_C/assets/'+data.id+'?multiticket='+tickets;
	   
	  return this.http.get(full_url,this.httpOptionsJson).pipe(); 
	}
	CallEditPressrelease(formData, tickets='', data=''): Observable<any> {
	   var full_url = this.baseUrlContent +'Hub_NewsPost_C/assets/'+data.id;
	   
	  return this.http.post(full_url, formData, this.httpOptionsJson).pipe(); 
	}
	
	CallDeletePressrelease(data, this.ticket): Observable<any> {
	  var full_url = this.baseUrlContent + 'Hub_NewsPost_C/assets/'+data.id;
	  return this.http.delete(full_url, this.httpOptionsJson).pipe();  
	}
	//Hub_EventSection
	AddHubEvent(data): Observable<any> {
	   var full_url = this.baseUrl + 'REST/types/Hub_Event_C/subtypes/Hub_EventSection';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest  + 'add.php';
	   }
	
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	CallGetEvent(data, tickets=''): Observable<any> {
		
	  var full_url = this.baseUrlContent + 'Hub_Event_C/assets/'+data.id+'?multiticket='+tickets;
	   
	  return this.http.get(full_url,this.httpOptionsJson).pipe(); 
	}
	EditHubEvent(data): Observable<any> {
	   var full_url = this.baseUrl + '';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest + 'add.php';
	   }
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	DeleteHubEvent(data): Observable<any> {
	   var full_url = this.baseUrl + '';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest + 'edit_tag.php';
	   }
	
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	
	
	//Hub_Downloadable
	AddHubDownloadable(data): Observable<any> {
	   var full_url = this.baseUrl + 'REST/types/Hub_Downloadable_C/subtypes/Hub_DownloadableSection';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest  + 'add.php';
	   }
	
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	GetHubDownloadable(data): Observable<any> {
	  var full_url = this.baseUrl + '';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest + 'edit_pressrelease.php';
	   }
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	EditHubDownloadable(data): Observable<any> {
	   var full_url = this.baseUrl + '';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest + 'add.php';
	   }
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	DeleteHubDownloadable(data): Observable<any> {
	   var full_url = this.baseUrl + '';
	   if(this.serverType=='dev'){
	    full_url = this.baseUrltest + 'edit_tag.php';
	   }
	
	  return this.http.post(full_url, {data},this.httpOptionsJson).pipe(); 
	}
	
	
	CallAddAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(); 
	}
	CallGetAnnouncement(data, tickets=''): Observable<any> {
		
	  var full_url = this.baseUrlContent + 'Hub_NewsPost_C/assets/'+data.id+'?multiticket='+tickets;
	   
	  return this.http.get(full_url,this.httpOptionsJson).pipe(); 
	}
	CallEditAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(); 
	}
	CallDeleteAnnouncement(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_tag.php', {data}).pipe(
		map(this.extractData)); 
	}
	
	CallGetPressKit(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'edit_press_kit.php', {data}).pipe(); 
	}
	
	
	CallEditPressKit(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'add.php', {data}).pipe(); 
	}
	
	CallAddVideo(data): Observable<any> {
	  return this.http.post(this.baseUrltest + 'upload.php',data); 
	}

	
	
	
	private handleError<T> (operation = 'operation', result?: T) {
	  return (error: any): Observable<T> => {

		// TODO: send the error to remote logging infrastructure
		console.error(error); // log to console instead

		// TODO: better job of transforming error for user consumption
		console.log(`${operation} failed: ${error.message}`);

		// Let the app keep running by returning an empty result.
		return of(result as T);
	  };
	}
	
  
}
