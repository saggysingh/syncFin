import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './news-detail.component.html',
})
export class NewsdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
