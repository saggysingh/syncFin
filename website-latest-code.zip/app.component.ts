import { Component } from '@angular/core';
import { Renderer2 } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private renderer: Renderer2, private router: Router) {
    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
       
          let currentUrlSlug = event.url.slice(1)
          if (currentUrlSlug) {
            this.renderer.addClass(document.body, 'internal-page');
			 this.renderer.removeClass(document.body, 'sub-page');
			 if (currentUrlSlug=='find-account' || currentUrlSlug=='contact-us'){
               this.renderer.addClass(document.body, 'sub-page');
			 }
          }else{
		     this.renderer.removeClass(document.body, 'internal-page');
             this.renderer.removeClass(document.body, 'sub-page');
			 this.renderer.setProperty(document.body, 'id', 'synchrony');
			 
		  }
		  
		  switch(currentUrlSlug){
			  case 'find-account':
				this.renderer.setProperty(document.body, 'id', 'find-account');
				this.renderer.setAttribute(document.body, 'page-name', 'find account');
				break;
			  case 'consumers':
				this.renderer.setProperty(document.body, 'id', 'consumers');
				this.renderer.setAttribute(document.body, 'page-name', 'consumers');
				break;
			  case 'businesses':
				this.renderer.setProperty(document.body, 'id', 'businesses'); 
				this.renderer.setAttribute(document.body, 'page-name', 'businesses');
				break;
			  case 'about-us':
				this.renderer.setProperty(document.body, 'id', 'about-us');
				this.renderer.setAttribute(document.body, 'page-name', 'about us');
				break;
			  case 'contact-us':
				this.renderer.setProperty(document.body, 'id', 'contact-us');
				this.renderer.setAttribute(document.body, 'page-name', 'contact us');
				break;
			  case 'fact-sheet':
				this.renderer.addClass(document.body, 'sub-page');
				this.renderer.setProperty(document.body, 'id', 'fact-sheet');
				this.renderer.setAttribute(document.body, 'page-name', 'fact sheet');
				break;
			 case 'fraud-protection':
				this.renderer.addClass(document.body, 'sub-page');
				this.renderer.setProperty(document.body, 'id', 'fraud-protection');
				this.renderer.setAttribute(document.body, 'page-name', 'fraud protection');
				break;
			case 'sitemap':
				this.renderer.addClass(document.body, 'sub-page');
				this.renderer.setProperty(document.body, 'id', 'sitemap');
				this.renderer.setAttribute(document.body, 'page-name', 'site-map');
				break;
			case 'privacy-policy':
				this.renderer.addClass(document.body, 'sub-page');
				this.renderer.setProperty(document.body, 'id', 'privacy-policy');
				this.renderer.setAttribute(document.body, 'page-name', 'privacy policy');
				break;
            case 'usage-agreement':
				this.renderer.addClass(document.body, 'sub-page');
				this.renderer.setProperty(document.body, 'id', 'usage-agreement');
				this.renderer.setAttribute(document.body, 'page-name', 'usage agreement');
				break;
            case 'careers':
				this.renderer.setProperty(document.body, 'id', 'careers');
				this.renderer.setAttribute(document.body, 'page-name', 'careers');
				break;
            case 'investors':
			    this.renderer.addClass(document.body, 'sub-page');
				this.renderer.setProperty(document.body, 'id', 'investors');
				this.renderer.setAttribute(document.body, 'page-name', 'investors');
				break;
            case 'ambitions':
			  	this.renderer.setProperty(document.body, 'id', 'ambitions');
				this.renderer.setAttribute(document.body, 'page-name', 'ambitions');
				break;
            case 'success':
			    this.renderer.addClass(document.body, 'sub-page');
			  	this.renderer.setProperty(document.body, 'id', 'success');
				this.renderer.setAttribute(document.body, 'page-name', 'success');
				break;
            case 'suppliers':
			   	this.renderer.setProperty(document.body, 'id', 'suppliers');
				this.renderer.setAttribute(document.body, 'page-name', 'suppliers');
				break;
           case 'news':
			   	this.renderer.setProperty(document.body, 'id', 'news');
				this.renderer.setAttribute(document.body, 'page-name', 'news');
				break;
          case 'news/detail':
		        this.renderer.addClass(document.body, 'sub-page');
			   	this.renderer.setProperty(document.body, 'id', 'news');
				this.renderer.setAttribute(document.body, 'page-name', 'news');
				break;					
		  }
          
        }
      });
 
  }

}
