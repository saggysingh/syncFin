import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AccountComponent } from './account/account.component';
import { ConsumersComponent } from './consumers/consumers.component';
import { BusinessesComponent } from './businesses/businesses.component';
import { PagesComponent } from './pages/pages.component';
import { ContactComponent } from './contact/contact.component';
import { FactComponent } from './pages/fact.component';
import { FraudComponent } from './pages/fraud.component';
import { SitemapComponent } from './pages/sitemap.component';
import { PolicyComponent } from './pages/policy.component';
import { AgreementComponent } from './pages/agreement.component';
import { AmbitionsComponent } from './pages/ambitions.component';
import { CareersComponent } from './pages/careers.component';
import { SuccessComponent } from './pages/success.component';
import { InvestorsComponent } from './investors/investors.component';
import { SuppliersComponent } from './suppliers/suppliers.component';
import { NewsComponent } from './news/news.component';
import { NewsdetailComponent } from './news/newsdetail.component';

const appRoutes: Routes = [
 { path: '', component: HomeComponent},
 { path: 'find-account', component: AccountComponent},
 { path: 'consumers', component: ConsumersComponent},
 { path: 'businesses', component: BusinessesComponent},
 { path: 'about-us', component: PagesComponent},
 { path: 'fact-sheet', component: FactComponent},
 { path: 'fraud-protection', component: FraudComponent},
 { path: 'sitemap', component: SitemapComponent},
 { path: 'privacy-policy', component: PolicyComponent},
 { path: 'usage-agreement', component: AgreementComponent},
 { path: 'careers', component: CareersComponent},
 { path: 'success', component: SuccessComponent},
 { path: 'ambitions', component: AmbitionsComponent},
 { path: 'contact-us', component: ContactComponent},
 { path: 'investors', component: InvestorsComponent},
 { path: 'suppliers', component: SuppliersComponent},
 { path: 'news', component: NewsComponent},
 { path: 'news/detail', component: NewsdetailComponent},

];



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AccountComponent,
    ConsumersComponent,
    BusinessesComponent,
    PagesComponent,
    FactComponent,
    FraudComponent,
    SitemapComponent,
    PolicyComponent,
    AgreementComponent,
    CareersComponent,
    SuccessComponent,
    AmbitionsComponent,
    ContactComponent,
    InvestorsComponent,
    SuppliersComponent,
    NewsComponent,
	NewsdetailComponent
  ],
  imports: [
    BrowserModule,
	RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
