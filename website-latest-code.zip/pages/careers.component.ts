import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-careers',
  templateUrl: './careers.component.html',
 })
export class CareersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
