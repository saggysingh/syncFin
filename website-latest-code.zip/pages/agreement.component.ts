import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agreement',
  templateUrl: './agreement.component.html',
 })
export class AgreementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
