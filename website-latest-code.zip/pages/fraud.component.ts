import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fraud',
  templateUrl: './fraud.component.html',
 })
export class FraudComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
