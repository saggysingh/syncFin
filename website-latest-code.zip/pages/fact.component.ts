import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fact',
  templateUrl: './fact.component.html',
 })
export class FactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
