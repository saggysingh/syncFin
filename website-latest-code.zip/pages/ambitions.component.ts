import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ambitions',
  templateUrl: './ambitions.component.html',
 })
export class AmbitionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
