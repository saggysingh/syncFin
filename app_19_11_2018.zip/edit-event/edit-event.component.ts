import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { Event } from '../model/event_model';
import { Functions } from '../global/functions';
declare var $;

@Component({
  selector: 'app-edit-event',
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.css']
})
export class EditEventComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	selectedFile:any =  null;
	id: any;
	sub: any;
	ticket: any	=	'';
	public loading = false;
	readtextfile:any ='';
	filetextcode:any ='';
	error:any 	=	'';
	success:any 	=	'';
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   
	     this.model = new Event('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
	}


	ngOnInit() {
		this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetEvent();
		});
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
		localStorage.removeItem("success_msg");
		localStorage.removeItem("error_msg");
	  
	}
	  
  onSubmit() {	
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		    // this.errors.thumbnail_image = 'Thumbnail image is required'; 
		     // error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		if(error_flag ==1){
			  return false;
		}
		
		this.EditEvent();
	  }

	GetEvent() {		
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
				this.rest.CallGetEvent(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					console.log(fields); 
					this.model.name 				=	response2.name;
					this.model.template 			=	fields.template.stringValue;
					this.model.PageTitle 			=	fields.PageTitle.stringValue;
					this.model.PageMetaDescription 				=	'';
					if(fields.PageMetaDescription!=null){
						this.model.PageMetaDescription 		=	fields.PageMetaDescription.stringValue;
					}
					this.model.PageKeywords 				=	'';
					if(fields.PageKeywords!=null){
						this.model.PageKeywords 		=	fields.PageKeywords.stringValue;
					}
					this.model.PageName 				=	'';
					if(fields.PageName!=null){
						this.model.PageName 			=	fields.PageName.stringValue;
					}
					
					this.model.PageID 				=	'';
					if(fields.PageID!=null){
						this.model.PageID 			=	fields.PageID.stringValue;
					}
					if(fields.CustomTags!=null){
						let selected_tags	=	fields.CustomTags;
						selected_tags	=	selected_tags.stringList;
						this.model.page_tags 		=	selected_tags.join(",");
						this.model.selected_tags 				=	selected_tags;
						
					}else{
						this.model.page_tags 				=	'';
					}
					if(fields.FeaturedEvent!=null){
						this.model.FeaturedEvent 	=	0;
						var str = fields.FeaturedEvent.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.FeaturedEvent	=	1;
						}
						
					}else{
						this.model.FeaturedEvent 				=	0;
					}
					
					if(fields.EventImage!=null){
						this.model.thumb_image 			=	fields.EventImage.blobValue.href;
						this.data.EventImage 			=	fields.EventImage.blobValue;
						
					}else{
						this.model.thumb_image 			=	'';
					}
					if(fields.EventImageText!=null){
						this.model.EventImageText 			=	fields.EventImageText.stringValue;
						
					}else{
						this.model.EventImageText 			=	'';
					}
					if(fields.EventImageAlt!=null){
						this.model.EventImageAlt 			=	fields.EventImageAlt.stringValue;
						
					}else{
						this.model.EventImageAlt 			=	'';
					}
					
					if(fields.EventImageTooltip!=null){
						this.model.EventImageTooltip 			=	fields.EventImageTooltip.stringValue;
						
					}else{
						this.model.EventImageTooltip 			=	'';
					}
					if(fields.CreatedDate!=null){
						this.model.CreatedDate 			=	fields.CreatedDate.dateValue;
					}else{
						this.model.CreatedDate 			=	'';
					}
					if(fields.Title!=null){
						this.model.Title 			=	fields.Title.stringValue;
						
					}else{
						this.model.Title 			=	'';
					}
					if(fields.FromDate!=null){
						this.model.FromDate 			=	fields.FromDate.dateValue;
					}else{
						this.model.FromDate 			=	'';
					}
					if(fields.ToDate!=null){
						this.model.ToDate 			=	fields.ToDate.dateValue;
					}else{
						this.model.ToDate 			=	'';
					}
					if(fields.Location!=null){
						this.model.Location 			=	fields.Location.stringValue;
						
					}else{
						this.model.Location 			=	'';
					}
					if(fields.Registration!=null){
						this.model.Registration 			=	fields.Registration.stringValue;
						
					}else{
						this.model.Registration 			=	'';
					}					
					if(fields.DisplayMediaFormLink!=null){
						this.model.DisplayMediaFormLink 	=	0;
						var str = fields.DisplayMediaFormLink.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.DisplayMediaFormLink	=	1;
						}
						
					}else{
						this.model.DisplayMediaFormLink 				=	'no';
					}
					if(fields.Description!=null){
						this.model.Description 			=	fields.Description.stringValue;
						
					}else{
						this.model.Description 			=	'';
					}
					if(fields.ShortDescription!=null){
						this.model.ShortDescription 			=	fields.ShortDescription.stringValue;
						
					}else{
						this.model.ShortDescription 			=	'';
					}
					if(fields.NewsContent!=null){
						this.model.NewsContent 			=	fields.NewsContent.stringValue;
						
					}else{
						this.model.NewsContent 			=	'';
					}
					if(fields.EmailSubject!=null){
						this.model.EmailSubject 			=	fields.EmailSubject.stringValue;
						
					}else{
						this.model.EmailSubject 			=	'';
					}
					if(fields.EmailBody!=null){
						this.model.EmailBody 			=	fields.EmailBody.stringValue;
						
					}else{
						this.model.EmailBody 			=	'';
					}
					
					
				}, error => {
				//this.router.navigate(['']);
			});
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
	}  	  
  
	EditEvent() {
		this.loading = true;
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedEvent 		    = 	'No';
			if(this.model.FeaturedEvent){		
			  this.data.FeaturedEvent 		= 	'Yes';	
			}
			this.data.DisplayMediaFormLink 		    = 	'No';
			if(this.model.DisplayMediaFormLink){		
			  this.data.DisplayMediaFormLink 		= 	'Yes';	
			}
			this.data.id 	=	Number(this.data.id);
			
			// Condition for thumbnail image
			var file_name 	=	'';
			var foldername 	=	'';
			var filedata 	=	'';
			var href 	=	'';
			if(CustomValidator.emptyValidation(this.selectedFile)===false){
				file_name 	=	this.data.EventImage.filename;
				foldername 	=	this.data.EventImage.foldername;
				filedata 	=	this.data.EventImage.filedata;
				href 	=	this.data.EventImage.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				
				var unix = Math.round(+new Date()/1000);
				var old_file_name 	=	this.selectedFile.name;
				let file_nameArray = old_file_name.split(".");
				file_nameArray.reverse();
				let file_ext 	=	file_nameArray[0];
				file_nameArray.splice(0, 1);
				file_nameArray.reverse();
				file_name	=	file_nameArray.join("-");
				var new_file_name 	=	file_name+"-"+unix+"."+file_ext;
				file_name 	=	new_file_name;
				foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
				filedata 	=	this.readtextfile;
				href 		=	'';
			}
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			let formData 	=	{"attribute":[{"name":"id", "data":{"longValue":this.data.id}}, {"name":"template","data":{"stringValue":"Hub_EventSectionLayout"}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"FeaturedEvent","data":{"stringValue": this.data.FeaturedEvent}}, {"name":"EventImage","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"EventImageAlt","data":{"stringValue":this.model.EventImageAlt}},{"name":"EventImageText","data":{"stringValue":this.model.EventImageText}},{"name":"EventImageTooltip","data":{"stringValue":this.model.EventImageTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"FromDate","data":{"dateValue":this.model.FromDate}}, {"name":"ToDate","data":{"dateValue":this.model.ToDate}}, {"name":"Location","data":{"stringValue":this.model.Location}}, {"name":"Registration","data":{"stringValue":this.model.Registration}},{"name":"DisplayMediaFormLink","data":{"stringValue": this.data.DisplayMediaFormLink}}, {"name":"ShortDescription","data":{"stringValue":this.model.ShortDescription}}, {"name":"Description","data":{"stringValue":this.model.Description}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "id":'Hub_Event_C:'+this.data.id,  "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "createddate": this.model.CreatedDate }
			
			
				this.rest.EditHubEvent(formData, this.ticket, this.data).subscribe(response2 => {
					this.loading = false;
					//localStorage.setItem("success_msg", "Your Event has been updated successfully.");
					this.success 	=	"Your Event has been updated successfully.";
					//this.router.navigate(['/create-edit-content']);

				}, error => {
						this.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
		
	}
	
	DeleteEvent(){
		if(confirm("Are you sure to delete Event?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.DeleteHubEvent(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						localStorage.setItem("success_msg", "Your event has been deleted successfully.");
						this.router.navigate(['/create-edit-content']);

					}, error => {
						this.loading = false;
							localStorage.setItem("error_msg", "You are not authorize to access this.");
							this.router.navigate(['/create-edit-content']);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	}
  
 
  	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}

      onFileSelected(event){
          //console.log(event);
	     this.selectedFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
				
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  
	  ApproveAsset(){
		 if(confirm("Are you sure to Approve Event?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallApproveAsset(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						this.success 	=	"Your Event has been approved successfully.";
						//localStorage.setItem("success_msg", "Your press release has been approve successfully.");
						this.router.navigate(['/edit_event/'+this.data.id]);

					}, error => {
						this.loading = false;
							this.success 	=	"Your Event has been approved successfully.";
							this.router.navigate(['/edit_event/'+this.data.id]);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	  }

}
