import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Functions } from '../global/functions';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
	data:any;
	announcement:Array<string> = [];
	press:any;
	event:any;
	downloadable:any;
	video:any;
	white_paper:any;
	errors:any;
	ticket:any='';
	p: number = 1;
  constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { 
	this.data 						= {};
	//this.announcement 				= {};																					
	this.errors 					= {};
	// check for the User is login or not.
	var username	=	localStorage.hasOwnProperty("username");
		if(!username){
			this.router.navigate(['']);
		}
	}	

  ngOnInit() {
		this.getFeaturedList();
		setInterval(() => {		
			//this.getFeaturedList();
		  }, 5000); // Activate after 5 minutes.
  }
  
  getFeaturedList() {
		this.data.created_by = localStorage.getItem("username");
		this.data.is_featured = 1; 
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		/* Call for Announcement List */
		this.rest.CallLogin(this.data).subscribe(response => {
			this.data.requestUrl 	=	response.headers.get('Location');
			this.rest.GetServiceTicket(this.data).subscribe(response1 => {
				this.data.tickets 	=	response1.body;
				this.rest.ContentAnnouncement(this.data).subscribe(response => {
					this.announcement  = Functions.getExtractData(response, 'Announcement');
					
		/* Call for Press Release List */
		this.rest.CallLogin(this.data).subscribe(response => {
			this.data.requestUrl 	=	response.headers.get('Location');
			this.rest.GetServiceTicket(this.data).subscribe(response1 => {
				this.data.tickets 	=	response1.body;
				this.rest.ContentPress(this.data).subscribe(response => {
					let press_release  = Functions.getExtractData(response, 'Press Release');
					//console.log(press_release);
					for(let object of press_release) {
					 this.announcement.push(object)
					}
				 }, error => {
						this.router.navigate(['']);
				  });
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
		
		/* Call for Event List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentEvent(this.data).subscribe(response => {
						let event_list  = Functions.getExtractData(response, 'Event');
						//console.log(press_release);
						for(let object of event_list) {
						 this.announcement.push(object)
						}
					 }, error => {
							this.router.navigate(['']);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
       /* Call for Downloadable List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentDownloadable(this.data).subscribe(response => {
						let event_list  = Functions.getExtractData(response, 'Downloadable');
						//console.log(press_release);
						for(let object of event_list) {
						 this.announcement.push(object)
						}
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
		
       /* Call for Video List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentVideo(this.data).subscribe(response => {
						let event_list  = Functions.getExtractData(response, 'Video');
						//console.log(press_release);
						for(let object of event_list) {
						 this.announcement.push(object)
						}
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
       /* Call for WhitePaper List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentWhitPaper(this.data).subscribe(response => {
						let event_list  = Functions.getExtractData(response, 'WhitePaper');
						//console.log(press_release);
						for(let object of event_list) {
						 this.announcement.push(object)
						}
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
				 }, error => {
						console.warn(error);
				  });
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
		
     
		
		
  }
  
  
  generateNewTicket(){
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
			this.data.requestUrl 	=	response.headers.get('Location');
			this.rest.GetServiceTicket(this.data).subscribe(response1 => {
				this.ticket 	=	response1.body;
			}, error => {
					//this.global 	=	'Please enter valid username and password.';
			});
		}, error => {
				//this.global 	=	'Please enter valid username and password.';
		});
  }


}
