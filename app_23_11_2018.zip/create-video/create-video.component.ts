import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { Functions } from '../global/functions';
declare var $;

@Component({
  selector: 'app-create-video',
  templateUrl: './create-video.component.html',
  styleUrls: ['./create-video.component.css']
})
export class CreateVideoComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	page_tags_arr:any =[];
	public loading = false;
	ticket:any	=	'';
	selectedFile:File 	=  null;
	readtextfile:any 	=	'';
	filetextcode:any 	=	'';
	video_poster:File 	=  null;
	readtextposeterfile:any 	=	'';
	filetextpostercode:any 	=	'';
	video_mp4:File 		=  null;
	readtextmp4file:any 	=	'';
	filetextmp4code:any 	=	'';
	video_ogg:File 		=  null;
	readtextoggfile:any 	=	'';
	filetextoggcode:any 	=	'';
	video_webm:File 	=  null;
	readtextwebmfile:any 	=	'';
	filetextwebmcode:any 	=	'';
	error:any 	=	'';
	success:any 	=	'';
	
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	 this.lists 					= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	}

	ngOnInit() {
	
	}
	
	  onFileSelected(event){
          //console.log(event);
	     this.selectedFile = <File>event.target.files[0];
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextfile 	=	solution[1];
		}
		this.filetextcode	=	fileReader.readAsDataURL(this.selectedFile);
	     $('#image-1').html(this.selectedFile.name);
	  }
	  onVideoPoster(event){
         this.video_poster = <File>event.target.files[0];
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextposeterfile 	=	solution[1];
		}
		this.filetextpostercode	=	fileReader.readAsDataURL(this.video_poster);
	     $('#video_poster').html(this.video_poster.name);
	  }
	  
	  onVideoMp4(event){
         this.video_mp4 = <File>event.target.files[0];
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextmp4file 	=	solution[1];			 
			
		}
		this.filetextmp4code	=	fileReader.readAsDataURL(this.video_mp4);
	     $('#video_mp4').html(this.video_mp4.name);
	  }
	  
	  onVideoOgg(event){
         this.video_ogg = <File>event.target.files[0];
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {			
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextoggfile 	=	solution[1];
		}
		this.filetextoggcode	=	fileReader.readAsDataURL(this.video_ogg);
	     $('#video_ogg').html(this.video_ogg.name);
	  }
	  
	  onVideoWebm(event){
         this.video_webm = <File>event.target.files[0];
		 let fileReader = new FileReader();
		 fileReader.onload = (e) => {	
				let string_file:any;
				string_file		=	fileReader.result;
				var solution	=	string_file.split("base64,");
				this.readtextwebmfile 	=	solution[1];
		}
		this.filetextwebmcode	=	fileReader.readAsDataURL(this.video_webm);
	     $('#video_webm').html(this.video_webm.name);
	  }
	  
	 
	
	  
  	onSubmit() {
	    var error_flag = 0;
		this.errors.youtube_id = '';
		this.errors.thumbnail_image = '';
		this.errors.video_url = '';
		this.errors.video_poster = '';
		this.errors.video_mp4 = '';
		this.errors.video_ogg = '';
		this.errors.video_webm = '';
		if(this.model.VideoType=='YouTube ID'){
		   if(CustomValidator.emptyValidation(this.model.YouTubeID)===false){
		       this.errors.youtube_id = 'Youtube-Id is required'; 
		     error_flag = 1;
		   }
		}
		  if(CustomValidator.emptyValidation(this.selectedFile)===false){
		  
		       this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   } 
		   
		   if(CustomValidator.emptyValidation(this.video_poster)===false){
		       this.errors.video_poster = 'Video Poster is required'; 
		       error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.video_poster)===false){
			     this.errors.video_poster = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		

		if(this.model.VideoType=='External Video URL'){
		   if(CustomValidator.emptyValidation(this.model.ExternalVideoURL)===false){
		       this.errors.video_url = 'Video Url is required'; 
		       error_flag = 1;
		   }
		}
		
		if(this.model.VideoType=='Internal Video'){
			if(CustomValidator.emptyValidation(this.video_mp4)===false){
		       //this.errors.video_mp4 = 'Video MP4 is required'; 
		       //error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_mp4,'mp4')===false){
			     this.errors.video_mp4 = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		   
		   	if(CustomValidator.emptyValidation(this.video_ogg)===false){
		      // this.errors.video_ogg = 'Video OGG is required'; 
		       //error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_ogg,'ogv')===false){
			     this.errors.video_ogg = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		   	if(CustomValidator.emptyValidation(this.video_webm)===false){
		       //this.errors.video_webm = 'Video WEBM is required'; 
		       //error_flag = 1;
		   }else{
		       if(CustomValidator.videoExtensionValidation(this.video_webm,'webm')===false){
			     this.errors.video_webm = 'Wrong format file.'; 
		          error_flag = 1;
			   }
			   
		   }
		}
      	if(error_flag ==1){
		      return false;
		}
	
    	this.CreateVideo();
	  }  
  
  CreateVideo() {
	
		this.loading = true;
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			this.ticket 	=	response1.body;
			this.data.FeaturedVideo 		    = 	'No';
			if(this.model.FeaturedVideo){		
			  this.data.FeaturedVideo 		= 	'Yes';	
			}
			
			//add timestamp in file name of Thumbnail Image
			var unix = Math.round(+new Date()/1000);
			var file_name 	=	this.selectedFile.name;
			let file_nameArray = file_name.split(".");
			file_nameArray.reverse();
			let file_ext 	=	file_nameArray[0];
			file_nameArray.splice(0, 1);
			file_nameArray.reverse();
			var file_name	=	file_nameArray.join("-");
			var new_file_name 	=	file_name+"-"+unix+"."+file_ext;

			// Read Data for Mp4 File
			var mp4_file_name 	=	'';
			var mp4_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var mp4_filedata 	=	'';
			var mp4_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_mp4)===false){
			}else{
				//add timestamp in file name
				var unix_mp4 = Math.round(+new Date()/1000);
				var file_name_mp4 	=	this.video_mp4.name;
				let file_name_mp4Array = file_name_mp4.split(".");
				file_name_mp4Array.reverse();
				let file_ext_mp4 	=	file_name_mp4Array[0];
				file_name_mp4Array.splice(0, 1);
				file_name_mp4Array.reverse();
				var file_name_mp4	=	file_name_mp4Array.join("-");
				var new_file_name_mp4 	=	file_name_mp4+"-"+unix_mp4+"."+file_ext_mp4;
				mp4_file_name 	=	new_file_name_mp4;
				mp4_filedata	=	this.readtextmp4file;
			}
			
			// Read Data for OGG File
			var ogg_file_name 	=	'';
			var ogg_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var ogg_filedata 	=	'';
			var ogg_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_ogg)===false){
			}else{
				//add timestamp in file name
				var unix_ogg = Math.round(+new Date()/1000);
				var file_name_ogg 	=	this.video_ogg.name;
				let file_name_oggArray = file_name_ogg.split(".");
				file_name_oggArray.reverse();
				let file_ext_ogg 	=	file_name_oggArray[0];
				file_name_oggArray.splice(0, 1);
				file_name_oggArray.reverse();
				var file_name_ogg	=	file_name_oggArray.join("-");
				var new_file_name_ogg 	=	file_name_ogg+"-"+unix_ogg+"."+file_ext_ogg;
				ogg_file_name 	=	new_file_name_ogg;
				ogg_filedata	=	this.readtextoggfile;
			}
			// Read Data for WEBM File
			var webm_file_name 	=	'';
			var webm_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var webm_filedata 	=	'';
			var webm_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_webm)===false){
			}else{
				//add timestamp in file name
				var unix_webm = Math.round(+new Date()/1000);
				var file_name_webm 	=	this.video_webm.name;
				let file_name_webmArray = file_name_webm.split(".");
				file_name_webmArray.reverse();
				let file_ext_webm 	=	file_name_webmArray[0];
				file_name_webmArray.splice(0, 1);
				file_name_webmArray.reverse();
				var file_name_webm	=	file_name_webmArray.join("-");
				var new_file_name_webm 	=	file_name_webm+"-"+unix_webm+"."+file_ext_webm;
				webm_file_name 	=	new_file_name_webm;
				webm_filedata	=	this.readtextwebmfile;
			}
			// Read Data for Video poster Image
			var vimage_file_name 	=	'';
			var vimage_foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
			var vimage_filedata 	=	'';
			var vimage_href 		=	'';
			if(CustomValidator.emptyValidation(this.video_poster)===false){
			}else{
				//add timestamp in file name
				var unix_vimage = Math.round(+new Date()/1000);
				var file_name_vimage 	=	this.video_poster.name;
				let file_name_vimageArray = file_name_vimage.split(".");
				file_name_vimageArray.reverse();
				let file_ext_vimage 	=	file_name_vimageArray[0];
				file_name_vimageArray.splice(0, 1);
				file_name_vimageArray.reverse();
				var file_name_vimage	=	file_name_vimageArray.join("-");
				var new_file_name_vimage 	=	file_name_vimage+"-"+unix_vimage+"."+file_ext_vimage;
				vimage_file_name 	=	new_file_name_vimage;
				vimage_filedata	=	this.readtextposeterfile;
			}

			
			
			
			// create an array of Tags.
			let selected_tags 	=	this.model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			var formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_VideoSectionLayout"}}, {"name":"PageTitle","data":{"stringValue":this.model.PageTitle}}, {"name":"PageMetaDescription","data":{"stringValue":this.model.PageMetaDescription}}, {"name":"PageKeywords", "data":{"stringValue":this.model.PageKeywords}}, {"name":"PageName","data":{"stringValue": this.model.PageName}}, {"name":"PageID","data":{"stringValue": this.model.PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"NewsType","data":{"stringValue":"Press Release"}},{"name":"FeaturedVideo","data":{"stringValue": this.data.FeaturedVideo}}, {"name":"ThumbnailImage","data":{"blobValue":{"filename":new_file_name,"foldername":"/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/","filedata": this.readtextfile,"href":""}}}, {"name":"ThumbnailAlt","data":{"stringValue":this.model.ThumbnailAlt}},{"name":"ThumbnailTooltip","data":{"stringValue":this.model.ThumbnailTooltip}}, {"name":"CreatedDate","data":{"dateValue":this.model.CreatedDate}}, {"name":"Title","data":{"stringValue":this.model.Title}}, {"name":"SubTitle","data":{"stringValue":this.model.SubTitle}}, {"name":"ShortContent","data":{"stringValue":this.model.ShortContent}}, {"name":"Content","data":{"stringValue":this.model.Content}}, {"name":"VideoType","data":{"stringValue":this.model.VideoType}}, {"name":"YouTubeID","data":{"stringValue":this.model.YouTubeID}}, {"name":"ExternalVideoURL","data":{"stringValue":this.model.ExternalVideoURL}}, {"name":"MP4","data":{"blobValue":{"filename":mp4_file_name,"foldername":mp4_foldername,"filedata": mp4_filedata,"href":mp4_href}}}, {"name":"OGG","data":{"blobValue":{"filename":ogg_file_name,"foldername":ogg_foldername,"filedata": ogg_filedata,"href":ogg_href}}}, {"name":"WEBM","data":{"blobValue":{"filename":webm_file_name,"foldername":webm_foldername,"filedata": webm_filedata,"href":webm_href}}}, {"name":"VideoImage","data":{"blobValue":{"filename":vimage_file_name,"foldername":vimage_foldername,"filedata": vimage_filedata,"href":vimage_href}}}, {"name":"VideoImageAlt","data":{"stringValue":this.model.VideoImageAlt}}, {"name":"VideoImageTooltip","data":{"stringValue":this.model.VideoImageTooltip}}, {"name":"DataReason","data":{"stringValue":this.model.DataReason}}, {"name":"EmailSubject","data":{"stringValue":this.model.EmailSubject}}, {"name":"EmailBody","data":{"stringValue":this.model.EmailBody}}, {"name":"name", "data":{"stringValue":this.model.name}}, {"name":"createdby", "data":{"stringValue":this.data.createdby}}], "name":this.model.name, "createdby":this.data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_VideoSection" , "createddate": this.model.CreatedDate}
			
			this.rest.CallAddVideo(formData, this.ticket).subscribe(response2 => {
					localStorage.setItem("success_msg", "Your Video has been created successfully.");
					this.success 	=	"Your Video has been created successfully.";
					let idString =	response2.id;
					let idArray = idString.split(":");
					let id 	=	idArray[1];
					this.loading = false;
					this.router.navigate(['/edit_video/'+id]);

				}, error => {
					this.loading = false;
						localStorage.setItem("error_msg", "You are not authorize to access this.");
						this.router.navigate(['/create-edit-content']);
					});
		}, error => {
				this.loading = false;
				this.router.navigate(['']);
		});
	}, error => {
			this.loading = false;
			this.router.navigate(['']);
	});
  }
  selectOption(selet_option){
	  var textValue = $('#'+selet_option).text();
	  //this.model.video_type = textValue;
						
		$('.youtube-video').hide();
		$('.video-url').hide();
		$('.video-set').hide();
		switch(selet_option){
			case 'YouTube ID':
				$(".youtube-video").show();
				break;
			case 'Internal Video':
				$(".video-set").show();
				break;
			case 'External Video URL':
				$(".video-url").show();
				break;
			
		}
		
  }
/* Video Type Section  */

}
