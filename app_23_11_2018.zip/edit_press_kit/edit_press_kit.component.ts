import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomValidator } from '../custom/validation';
import { Functions } from '../global/functions';
import { Press } from './press';
import { Files } from './files';
declare var $;
declare var CKEDITOR;

let uniqueId = 0;

@Component({
  selector: 'app-edit_press_kit',
  templateUrl: './edit_press_kit.component.html',
  styleUrls: ['./edit_press_kit.component.css']
})
export class EditPressKitComponent implements OnInit {

	
	model: any = {};
	data:any = {};
	errors:any = {};
	config:any;
	id: any;
	sub: any;
	ticket: any	=	'';
	error:any 	=	'';
	success:any 	=	'';
	pdfFile:any =  null;
	readtextpdffile:any ='';
	filetextpdfcode:any ='';
	filetextsinglecode:any ='';
	public loading = false;
	filetextcode:Array<String>	=	new Array<String>();
	currentFile:any ='';
	
	pressArray:Array<Press>=new Array<Press>();
	selectedFile:Array<Files>=new Array<Files>();
	
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { 
		this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
	   ]};
	   this.filetextcode 	=	[];
		var username	=	localStorage.hasOwnProperty("username");
		if(!username){
			this.router.navigate(['']);
		}
	}

	ngOnInit() {
		
		this.sub = this.route.params.subscribe(params => {
			this.data.id = params['id'];
			this.GetPressKit();
		});
		this.success 			= 	localStorage.getItem("success_msg");
		this.error 				= 	localStorage.getItem("error_msg");
		localStorage.removeItem("success_msg");
		localStorage.removeItem("error_msg");
		
		
	}
	  
	onSubmit() {
			var arrFile = new Array();
			
			var error_flag = 0;
		 this.pressArray.forEach(function(field_value, field_index){
		     if(field_value.type==2){
			    arrFile.push(field_value.id);
			 }else{
			 // Type ckEditor
			     $('#ckeditor_error_'+field_value.id).html('');
				 if(CustomValidator.emptyValidation(field_value.data.Content)===false){
				   $('#ckeditor_error_'+field_value.id).html('This field is required.');
				     error_flag = 1;
				 }
			 
			 }
		
		 });
		 /*  Image Validation */
		 if (this.selectedFile.length === 0) {
			   let all_files 	=	this.pressArray; 
			   
			   arrFile.forEach(function(v, k){
				   all_files.forEach(function(field_value, field_index){
						if(field_value.type==2){
							if(field_value.data.ImageHref==undefined && field_value.id==v){
								$('#image_error_'+v).html('This field is required.');
								error_flag = 1;
							}
						}
					
					})
				   
		 	    
			   });
 
         }else{
				this.selectedFile.forEach(function(value, key) {
					  $('#image_error_'+value.id).html('');
					 if(CustomValidator.imageExtensionValidation(value.file)===false){
					 
						$('#image_error_'+value.id).html('Wrong format file.');
						error_flag = 1;
						
					  }
				
				});
		}
		   
		  if(error_flag==1){
		     return false;
		  }
		  //console.log(error_flag);
			this.EditPressKit();
	  }  

	GetPressKit() {
		
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.createdby 		= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		this.rest.CallLogin(this.data).subscribe(response => {
		this.data.requestUrl 	=	response.headers.get('Location');
		this.rest.GetServiceTicket(this.data).subscribe(response1 => {
			//console.log(response1.body);
			this.ticket 	=	response1.body;
				this.rest.CallGetPressKit(this.data, this.ticket).subscribe(response2 => {
					let fields  = Functions.getSingleData(response2);
					this.model.name 				=	response2.name;
					this.model.template 			=	fields.template.stringValue;
					this.model.Hub_PageTitle 			=	fields.Hub_PageTitle.stringValue;
					this.model.Hub_MetaDescription 				=	'';
					if(fields.Hub_MetaDescription!=null){
						this.model.Hub_MetaDescription 		=	fields.Hub_MetaDescription.stringValue;
					}
					this.model.Hub_Keywords 				=	'';
					if(fields.Hub_Keywords!=null){
						this.model.Hub_Keywords 		=	fields.Hub_Keywords.stringValue;
					}
					this.model.Hub_BodyID 				=	'';
					if(fields.Hub_BodyID!=null){
						this.model.Hub_BodyID 		=	fields.Hub_BodyID.stringValue;
					}
					this.model.Hub_PageH1Tag 				=	'';
					if(fields.Hub_PageH1Tag!=null){
						this.model.Hub_PageH1Tag 		=	fields.Hub_PageH1Tag.stringValue;
					}
					this.model.Hub_PageName 				=	'';
					if(fields.Hub_PageName!=null){
						this.model.Hub_PageName 			=	fields.Hub_PageName.stringValue;
					}
					this.model.Hub_PageID 				=	'';
					if(fields.Hub_PageID!=null){
						this.model.Hub_PageID 			=	fields.Hub_PageID.stringValue;
					}
					if(fields.CustomTags!=null){
						let selected_tags	=	fields.CustomTags;
							selected_tags	=	selected_tags.stringList;
						this.model.page_tags 		=	selected_tags.join(",");
						this.model.selected_tags 				=	selected_tags;
						
					}else{
						this.model.page_tags 				=	'';
					}
					if(fields.Hub_ScrollOverlay!=null){
						this.model.Hub_ScrollOverlay 	=	0;
						var str = fields.Hub_ScrollOverlay.stringValue;
							var featured = str.toLowerCase();
						if(featured=="yes"){
							this.model.Hub_ScrollOverlay	=	1;
						}
						
					}else{
						this.model.Hub_ScrollOverlay 				=	0;
					}
					
					if(fields.Hub_PDF!=null){
						this.model.pdf_file 			=	fields.Hub_PDF.blobValue.href;
						this.data.Hub_PDF 					=	fields.Hub_PDF.blobValue;
						
					}else{
						this.model.pdf_file 			=	'';
					}
					if(fields.Hub_PDFTitle!=null){
						this.model.Hub_PDFTitle 			=	fields.Hub_PDFTitle.stringValue;
						
					}else{
						this.model.Hub_PDFTitle 			=	'';
					}
					if(fields.Hub_ContentBlock!=null){
						let content_block	=	fields.Hub_ContentBlock;
						content_block	=	content_block.stringList;
						var content_blocks:any 	= [];						
						content_block.forEach((item, index) => {
							var block_array 	=	item.split(":");
							var block_type 		=	block_array[0];
							var block_id 		=	block_array[1];
							this.rest.CallGetPageBlock(block_id, this.ticket).subscribe(response3 => {
									var single_block:any 	= [];
									single_block['id']			=	block_id;
									let block_fields  = Functions.getSingleData(response3);
									let subtype 	=	response3.subtype;
									if(subtype == 'Hub_ContentImage'){
										if(block_fields.ImageFile!=null){
											single_block['ImageFile']	=	block_fields.ImageFile;
											single_block['ImageHref']	=	block_fields.ImageFile.blobValue.href;
										}
										if(block_fields.Alt!=null){
											single_block['Alt']		=	block_fields.Alt.stringValue;
											
										}else{
											single_block['Alt']		=	'';
										}
										
										if(block_fields.Tooltip!=null){
											single_block['Tooltip']		=	block_fields.Tooltip.stringValue;
											
										}else{
											single_block['Tooltip']		=	'';
										}
										single_block['ZoomImage']	=	0;
										var str = block_fields.ZoomImage.stringValue;
											var featured = str.toLowerCase();
										if(featured=="yes"){
											single_block['ZoomImage']	=	1;
										}
										
										
										var press: Press  = new Press(uniqueId++,'',2, single_block);
										this.pressArray.push(press);
									}else{
										single_block['Content']		=	block_fields.Content.stringValue;
										var press: Press  = new Press(uniqueId++,'',1, single_block);
										this.pressArray.push(press);
									}
									
									content_blocks[index]	=	single_block;
									
							});
							
						});
						this.model.Hub_ContentBlock 	=	content_blocks;
					}else{
						this.model.Hub_ContentBlock 				=	'';
					}
					
					if(fields.Hub_EmailSubject!=null){
						this.model.Hub_EmailSubject 			=	fields.Hub_EmailSubject.stringValue;
						
					}else{
						this.model.Hub_EmailSubject 			=	'';
					}
					if(fields.Hub_EmailBody!=null){
						this.model.Hub_EmailBody 			=	fields.Hub_EmailBody.stringValue;
						
					}else{
						this.model.Hub_EmailBody 			=	'';
					}
					if(fields.Hub_CreatedDate!=null){
						this.model.Hub_CreatedDate 			=	fields.Hub_CreatedDate.dateValue;
						
					}else{
						this.model.Hub_CreatedDate 			=	'';
					}
					
				}, error => {
				//this.router.navigate(['']);
			});
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});

	}  

	EditPressKit() {
		// create the Sub Content Block
		let content_blocks	=	[];
		let upload_file_code	=	this.filetextcode;
		var formData:any 	=	"";
		var current_model_data 	=	this.data;
		var current_model 	=	this.model;
		var restAPI 	=	this.rest;
		var this_object 	=	this;
		this_object.loading = true;
		console.log(this.pressArray);
		console.log(upload_file_code);
		this.pressArray.forEach(function(field_value, field_index){
			var file_number:number 	=	Number(field_value.id);
			if(field_value.type==2){  
				// Image Block
				var file_name 	=	'';
				var foldername 	=	'';
				var filedata 	=	'';
				var href 		=	'';			
				
				var new_image 	=	0;
				upload_file_code.forEach(function(image_value, image_index){
					var current_file_number:number	=	Number(image_value[0]);
					
						if(file_number==current_file_number){
							file_name 	=	image_value[2];
							foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
							filedata 	=	image_value[1];
							href 		=	'';
							new_image 	=	1;
						}
					});
				if(new_image==0){
					file_name 	=	field_value.data.ImageFile.blobValue.filename;
					foldername 	=	field_value.data.ImageFile.blobValue.foldername;
					filedata 	=	field_value.data.ImageFile.blobValue.filedata;
					href 		=	field_value.data.ImageFile.blobValue.href;
					
				}
				var zoom_image 	=	"";
				if(field_value.data.ZoomImage){
					zoom_image 	=	"Yes";
				}else{
					zoom_image 	=	"No";
				}
				if(field_value.data.id==undefined){
					formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_ContentImageLayout"}}, {"name":"ImageFile","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Alt","data":{"stringValue":field_value.data.Alt}},{"name":"Tooltip","data":{"stringValue":field_value.data.Tooltip}}, {"name":"ZoomImage","data":{"stringValue":zoom_image}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_ContentImage", "createdby":current_model_data.createdby }
				}else{
					formData 	=	{"attribute":[{"name":"id", "data":{"longValue":field_value.data.id}}, {"name":"template","data":{"stringValue":"Hub_ContentImageLayout"}}, {"name":"ImageFile","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Alt","data":{"stringValue":field_value.data.Alt}},{"name":"Tooltip","data":{"stringValue":field_value.data.Tooltip}}, {"name":"ZoomImage","data":{"stringValue":zoom_image}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "id":'Hub_PageBlock_C:'+field_value.data.id, "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_ContentImage", "createdby":current_model_data.createdby }
				}
				
				
				
			}else{
				// Content Block
				
				if(field_value.data.id==undefined){
					formData 	=	{"attribute":[{"name":"template","data":{"stringValue":"Hub_ContentLayout"}}, {"name":"Content","data":{"stringValue":field_value.data.Content}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_Content", "createdby":current_model_data.createdby }
				}else{
					formData 	=	{"attribute":[{"name":"id", "data":{"longValue":field_value.data.id}}, {"name":"template","data":{"stringValue":"Hub_ContentLayout"}}, {"name":"Content","data":{"stringValue":field_value.data.Content}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}], "id":'Hub_PageBlock_C:'+field_value.data.id, "name":current_model.name, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_Content", "createdby":current_model_data.createdby }
				}
				
				
			}
			
			// call the Rest API for add the Content Block
			var id  	=	0;
			if(field_value.data.id!=undefined){
				id 	=	field_value.data.id;
			}
				restAPI.CallAddPageBlock(formData, '', id).subscribe(response2 => {
					content_blocks.push(response2.id);
					
				});
		 });
		 var total_wait 	=	10000*this.pressArray.length;
		 setTimeout(function(){  
			
		 // create a Post request for Press kit Form:
			current_model_data.Hub_ScrollOverlay 		    = 	'No';
			if(current_model.Hub_ScrollOverlay){		
			  current_model_data.Hub_ScrollOverlay 		= 	'Yes';	
			}
			current_model_data.id 	=	Number(current_model_data.id);
		 // Condition for thumbnail image
			var file_name 	=	'';
			var foldername 	=	'';
			var filedata 	=	'';
			var href 	=	'';
			if(CustomValidator.emptyValidation(this_object.pdfFile)===false && current_model_data.Hub_PDF!=null){
				file_name 	=	current_model_data.Hub_PDF.filename;
				foldername 	=	current_model_data.Hub_PDF.foldername;
				filedata 	=	current_model_data.Hub_PDF.filedata;
				href 	=	current_model_data.Hub_PDF.href;
			}else{
				//file_name 	=	this.selectedFile.name;
				if(this_object.pdfFile!=null){
					var unix = Math.round(+new Date()/1000);
					var old_file_name 	=	this_object.pdfFile.name;
					let file_nameArray = old_file_name.split(".");
					file_nameArray.reverse();
					let file_ext 	=	file_nameArray[0];
					file_nameArray.splice(0, 1);
					file_nameArray.reverse();
					file_name	=	file_nameArray.join("-");
					var new_file_name 	=	file_name+"-"+unix+"."+file_ext;
					file_name 	=	new_file_name;
					foldername 	=	'/appdata/sf/Oracle/Middleware/11.1.1.8/shared/ccurl/';
					filedata 	=	this_object.readtextpdffile;
					href 		=	'';
				}
				
			}
			let selected_tags 	=	current_model.page_tags;
			let tags_array 		=	'';
			if (selected_tags.indexOf(",") !=-1) {
				tags_array 		=	selected_tags.split(",");
			}else{
				tags_array	=	selected_tags;
			}
			
			
			let formData_pressKit 	=	{"attribute":[{"name":"id", "data":{"longValue":current_model_data.id}}, {"name":"template","data":{"stringValue":"Hub_PressKitPageLayout"}}, {"name":"Hub_PageTitle","data":{"stringValue":current_model.Hub_PageTitle}}, {"name":"Hub_MetaDescription","data":{"stringValue":current_model.Hub_MetaDescription}}, {"name":"Hub_Keywords", "data":{"stringValue":current_model.Hub_Keywords}}, {"name":"Hub_BodyID","data":{"stringValue": current_model.Hub_BodyID}}, {"name":"Hub_PageH1Tag","data":{"stringValue": current_model.Hub_PageH1Tag}}, {"name":"Hub_PageName","data":{"stringValue": current_model.Hub_PageName}}, {"name":"Hub_PageID","data":{"stringValue": current_model.Hub_PageID}}, {"name":"CustomTags","data":{"stringList":tags_array}},{"name":"Hub_ScrollOverlay","data":{"stringValue": current_model_data.Hub_ScrollOverlay}}, {"name":"Hub_PDF","data":{"blobValue":{"filename":file_name,"foldername":foldername,"filedata": filedata,"href":href}}}, {"name":"Hub_PDFTitle","data":{"stringValue":current_model.Hub_PDFTitle}},{"name":"Hub_ContentBlock","data":{"stringList":content_blocks}}, {"name":"Hub_EmailSubject","data":{"stringValue":current_model.Hub_EmailSubject}}, {"name":"Hub_EmailBody","data":{"stringValue":current_model.Hub_EmailBody}}, {"name":"name", "data":{"stringValue":current_model.name}}, {"name":"createdby", "data":{"stringValue":current_model_data.createdby}}, {"name":"Hub_CreatedDate","data":{"dateValue":current_model.Hub_CreatedDate}}], "id":'Page:'+current_model_data.id, "name":current_model.name, "createdby":current_model_data.createdby, "description":"",  publist:Functions.getPublist(), "subtype": "Hub_PressKitPage", "createddate": current_model.Hub_CreatedDate }
		 
			this_object.rest.CallEditPressKit(formData_pressKit, this_object.ticket, current_model_data).subscribe(response2 => {
					this_object.loading = false;
					//localStorage.setItem("success_msg", "Your Press Release has been updated successfully.");
					this_object.success 	=	"Your Press Kit has been updated successfully.";
					//this.router.navigate(['/create-edit-content']);

			}, error => {
						this_object.loading = false;
						//localStorage.setItem("error_msg", "You are not authorize to access this.");
						//this.router.navigate(['/create-edit-content']);
					});
		}, total_wait);
		 
		 return false; 
	}
	
	DeletePresKit(){
		if(confirm("Are you sure to delete Press Kit?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					let block_count 	=	0;
					this.rest.CallGetPressKit(this.data, this.ticket).subscribe(response2 => {
						let fields  = Functions.getSingleData(response2);
						if(fields.Hub_ContentBlock!=null){
							let content_block	=	fields.Hub_ContentBlock;
							content_block	=	content_block.stringList;
							block_count	=	content_block.length;
							var content_blocks:any 	= [];						
							content_block.forEach((item, index) => {
								var block_array 	=	item.split(":");
								var block_type 		=	block_array[0];
								var block_id 		=	block_array[1];
								this.rest.CallDeletePageBlock(block_id, this.ticket).subscribe(response3 => {										
								});
								
							});
						}
						
					}, error => {
						//this.router.navigate(['']);
					});
					
					var total_wait 	=	10000*block_count;
					let this_object 	=	this;
					 setTimeout(function(){
							this_object.rest.CallDeletePressKit(this_object.data, this_object.ticket).subscribe(response2 => {
								this_object.loading = false;
								localStorage.setItem("success_msg", "Your Press Kit has been deleted successfully.");
								this_object.router.navigate(['/create-edit-content']);

							}, error => {
								this_object.loading = false;
									localStorage.setItem("error_msg", "You are not authorize to access this.");
									this_object.router.navigate(['/create-edit-content']);
								});
					 }, total_wait);
					
					
					
					/*  */
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	}
	onPdfSelected(event){
         this.pdfFile = event.target.files[0];
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string:any;
				string		=	fileReader.result;
				var solution	=	string.split("base64,");
				this.readtextpdffile 	=	solution[1];
				//console.log(this.readtextpdffile);
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextpdfcode	=	fileReader.readAsDataURL(this.pdfFile);
	     $('#pdf-1').html(this.pdfFile.name);
	  }
	  
	  
	ApproveAsset(){
		 if(confirm("Are you sure to Approve Press Kit?")) {
			this.loading = true;
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.ticket 	=	response1.body;
					this.rest.CallApproveAsset(this.data, this.ticket).subscribe(response2 => {
						this.loading = false;
						this.success 	=	"Your Press Kit has been approved successfully.";
						this.router.navigate(['/edit-press-kit/'+this.data.id]);

					}, error => {
						this.loading = false;
							this.success 	=	"Your Press Kit has been approved successfully.";
							this.router.navigate(['/edit-press-kit/'+this.data.id]);
						});
				}, error => {
					this.loading = false;
					this.router.navigate(['']);
				});
			}, error => {
				this.loading = false;
				this.router.navigate(['']);
			});
			
		}
	  }
	ngAfterViewInit() {
	  $(document).ready(function(){
			if ( $('.create-content-menu').length ) {
				$('.create-content-menu').each(function() {
					var these = $(this),
						saveButton = these.find('.save_button'),
						editButton = these.find('.edit'),
						approveButton = these.find('.approve'),
						deleteButton = these.find('.delete'),
						previewButton = these.find('.preview'),
						pageLocked = these.find('.page-locked'),
						requiredField = $('.required'),
						pageType = $('body').attr('page-type'),
						pageTypeContainer = these.find('.page-type');

					//Disable all inputs by default once page loads
					$('.create-content').addClass('disabled');
						
					//Add yellow title to menu bar    
					pageTypeContainer.text(pageType);

					//EDIT button functionality
					editButton.click(function(event) {
						event.preventDefault();
						$(this).addClass('active');
						$('.create-content').removeClass('disabled');
						saveButton.removeClass('inactive');
						deleteButton.removeClass('inactive');
						pageLocked.removeClass('inactive'); 
					});

					//SAVE button functionality
				   //APPROVE button functionality
					approveButton.click(function(event) {
						event.preventDefault();
						previewButton.removeClass('inactive');
						deleteButton.addClass('inactive');
					});

					//PREVIEW button functionality
					previewButton.click(function(event) {
						event.preventDefault();
						console.log('preview')
					});

				});
		}

		});

	}
	
	textAdd(block_type){
     var press: Press  = new Press(uniqueId++,'',block_type,[0, '', '', '', '', '']);
     this.pressArray.push(press);
  }

  deletePress(index:any){
    this.pressArray.splice(index,1);

  }
  
  clickUpload(id){
     $('#'+id).trigger('click');
  }
  
   onFileSelected(event,id){
		var index = null;
		this.currentFile = event.target.files[0];
	    var file_data: Files  = new Files(id, <File>event.target.files[0]);
		
		var file_data_encode:any	=	new Array();
		 let fileReader = new FileReader();
			fileReader.onload = (e) => {			
				let string:any;
				string		=	fileReader.result;
				var solution	=	string.split("base64,");
				file_data_encode 	=	[id, solution[1], this.currentFile.name];
				this.filetextcode.push(file_data_encode);
			}
			//this.filetextcode	=	fileReader.readAsText(this.selectedFile);
			this.filetextsinglecode	=	fileReader.readAsDataURL(this.currentFile);
			 this.selectedFile.forEach(function(value,key) {
		       	if (value.id == id){
				    index = key;
				}
			});
			if(index != null){
			   this.selectedFile.splice(index,1);
			   //this.filetextcode.splice(index,1);
			}
			
		   this.selectedFile.push(file_data);
	     $('#image_'+id).html(event.target.files[0].name);
	}
	

	PreviewAsset(){ 
		  var previewURL 	=	this.rest.CallGetPressKitPreviewURL(this.data);
		  window.open(previewURL);
			return false;
	  }
     
  
}
