import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { Functions } from '../global/functions';
declare var $;

@Component({
  selector: 'app-manage-content',
  templateUrl: './manage-content.component.html',
  styleUrls: ['./manage-content.component.css']
})
export class ManageContentComponent implements OnInit {
	data:any;
	errors:any;
	lists:any;
	announcement:any;
	press:any;
	events:any;
	downloadable:any;
	video:any;
	white_paper:any;
	tags:any;
  constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { 
	this.data 					= {};
	this.errors 				= {};
	this.lists 				= {};
	var username	=	localStorage.hasOwnProperty("username");
	if(!username){
		this.router.navigate(['']);
	}
  }

  ngOnInit() {
	  this.getContentList();
	  this.data.success_msg 			= 	localStorage.getItem("success_msg");
	  this.data.error_msg 			= 	localStorage.getItem("error_msg");
	  localStorage.removeItem("success_msg");
	  localStorage.removeItem("error_msg");
	  
  }
  
   getContentList() {
     

	this.data.created_by = localStorage.getItem("username");
		this.data.is_featured = 0; 
		this.data.username 			= 	localStorage.getItem("username");	
		this.data.password 			= 	localStorage.getItem("password");
		
		/* Call for Announcement List */
		this.rest.CallLogin(this.data).subscribe(response => {
			this.data.requestUrl 	=	response.headers.get('Location');
			this.rest.GetServiceTicket(this.data).subscribe(response1 => {
				this.data.tickets 	=	response1.body;
				this.rest.ContentAnnouncement(this.data).subscribe(response => {
					let announcement  = Functions.getExtractData(response, 'Announcement');
					let lists:any=	[];	
					for(let object of announcement) {
					 this.data.id 	=	object.id_value;
					 object['created_date']	=	"";
					 //console.log(this.data.id);
					 this.rest.CallGetAnnouncement(this.data, this.data.tickets).subscribe(response2 => {
							let fields  = Functions.getSingleData(response2);
							let object_date 	=	fields.CreatedDate.dateValue;
							object.created_date	=	object_date;
							//lists[]	=	object;
							lists.push(object);
						 }, error => {
								console.warn(error);
						  });
					}
					
					this.announcement 	=	lists;
					
					
				 }, error => {
						console.warn(error);
				  });
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
		
		/* Call for Press Release List */
		this.rest.CallLogin(this.data).subscribe(response => {
			this.data.requestUrl 	=	response.headers.get('Location');
			this.rest.GetServiceTicket(this.data).subscribe(response1 => {
				this.data.tickets 	=	response1.body;
				this.rest.ContentPress(this.data).subscribe(response => {
					let press  = Functions.getExtractData(response, 'Press Release');
					let lists:any=	[];	
					for(let object of press) {
					 this.data.id 	=	object.id_value;
					 object['created_date']	=	"";
					 //console.log(this.data.id);
					 this.rest.CallGetAnnouncement(this.data, this.data.tickets).subscribe(response2 => {
							let fields  = Functions.getSingleData(response2);
							let object_date 	=	fields.CreatedDate.dateValue;
							object.created_date	=	object_date;
							//lists[]	=	object;
							lists.push(object);
						 }, error => {
								console.warn(error);
						  });
					}
					
					this.press 	=	lists;
					
					
				 }, error => {
						console.warn(error);
				  });
			}, error => {
					this.router.navigate(['']);
			});
		}, error => {
				this.router.navigate(['']);
		});
		
		/* Call for Event List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentEvent(this.data).subscribe(response => {
						let events  = Functions.getExtractData(response, 'Event');
						let lists:any=	[];	
						for(let object of events) {
						 this.data.id 	=	object.id_value;
						 object['created_date']	=	"";
						 //console.log(this.data.id);
						 this.rest.CallGetEvent(this.data, this.data.tickets).subscribe(response2 => {
								let fields  = Functions.getSingleData(response2);
								let object_date 	=	fields.CreatedDate.dateValue;
								object.created_date	=	object_date;
								//lists[]	=	object;
								lists.push(object);
							 }, error => {
									console.warn(error);
							  });
						}
						
						this.events 	=	lists;
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
       /* Call for Downloadable List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentDownloadable(this.data).subscribe(response => {
						this.downloadable = Functions.getExtractData(response, 'Downloadable');
						
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
		
       /* Call for Video List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentVideo(this.data).subscribe(response => {
						this.video  = Functions.getExtractData(response, 'Video');
						
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
       /* Call for WhitePaper List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentWhitPaper(this.data).subscribe(response => {
						this.white_paper  = Functions.getExtractData(response, 'WhitePaper');
						
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
		/* Call for Content Tag List */
			this.rest.CallLogin(this.data).subscribe(response => {
				this.data.requestUrl 	=	response.headers.get('Location');
				this.rest.GetServiceTicket(this.data).subscribe(response1 => {
					this.data.tickets 	=	response1.body;
					this.rest.ContentTag(this.data).subscribe(response => {
						let tags  = Functions.getExtractData(response, 'Tag');
						
						let lists:any=	[];	
						for(let object of tags) {
						 this.data.id 	=	object.id_value;
						 object['created_date']	=	"";
						 this.rest.CallGetTag(this.data, this.data.tickets).subscribe(response2 => {
								let object_date 	=	response2.createddate;
								object.created_date	=	object_date;
								lists.push(object);
								
							 }, error => {
									console.warn(error);
							  });
						}
						
						
						this.tags 	=	lists;
						
					 }, error => {
							console.warn(error);
					  });
				}, error => {
						this.router.navigate(['']);
				});
			}, error => {
					this.router.navigate(['']);
			});
		
  }


   	ngAfterViewInit() {
		
		
		
      $(document).ready(function(){
	  
	  	if ( $('.edit-content-section').length ) {
            $('.edit-content-section').each(function() {
                var these = $(this),
                    showHideContent = these.find('.show-hide-childs'),
                    addActiveClass = $('.show').parent('li').find('>.show-hide-childs'),
                    searchPage = these.find('.search-page'),
                    contentFolders = these.find('.edit-content-folders'),
                    searchResultsContainer = these.find('.edit-content-search-results'),
                    searchResultsItems = searchResultsContainer.find('.results-items'),
                    closeSearhResults = these.find('.close-search');
                addActiveClass.addClass('active');
                var activeItems = these.find('.show-hide-childs.active');

                //Detect default active elements to show childs
                if(showHideContent.hasClass('active')) {
                    var asociateContent = activeItems.parent('li').find('> .child-content');
                    asociateContent.show();
                }

                //Manage show and hide child elements
                showHideContent.click(function(event) {
                    event.preventDefault();
                    var asociateContent = $(this).parent('li').find('> .child-content');
                    if($(this).hasClass('active')) {
                        $(this).removeClass('active');
                        asociateContent.slideUp();
                    } else {
                        $(this).addClass('active');
                        asociateContent.slideDown();
                    }
                });

                //Find Pages
                searchPage.click(function(event) {
                    event.preventDefault();
                    var searchPageInput = these.find('.search-value').val().toLowerCase(),
                        postItems = contentFolders.find('.post-page');
                    searchResultsItems.empty();
                    if (searchPageInput.length) {
                        postItems.each(function() {
                            var postPageName = $(this).find('.content-hub-posts_title').text().toLowerCase();
                            if(postPageName.indexOf(searchPageInput) != -1){
                                $(this).clone().appendTo(searchResultsItems); 
                            }
                        });
                        var resultItems = searchResultsItems.find('.post-page');
                        if ( resultItems.length ) {
                            searchResultsContainer.slideDown();
                        } else {
                            searchResultsContainer.slideDown();
                            searchResultsItems.append('<p class="error-message">There are no matches in your search</p>');
                        }
                    } else {
                        searchResultsContainer.slideUp();
                    }   
                });

                closeSearhResults.click(function(event) {
                    event.preventDefault();
                    searchResultsContainer.slideUp();
                    searchResultsItems.empty();
                });


            });
        }
	  
	  });
    }
  
}
