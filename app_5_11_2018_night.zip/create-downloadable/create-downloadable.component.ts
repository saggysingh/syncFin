import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { CustomValidator } from '../custom/validation';
import { Downloadable } from '../model/downloadable_model';
declare var $;

@Component({
  selector: 'app-create-downloadable',
  templateUrl: './create-downloadable.component.html',
  styleUrls: ['./create-downloadable.component.css']
})
export class CreateDownloadableComponent implements OnInit {

    model: any = {};
	data:any = {};
	errors:any = {};
	lists:any;
	config:any;
	selectedFile:any =  null;
	pdfFile:any =  null;
	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) {
	this.lists 			= {};
     this.config = {toolbar :  [
		[ 'Format','FontSize','Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo','SelectAll' ],
		{ name: 'colors', items: [ 'TextColor' ] },
		{ name: 'basicstyles', items: ['NumberedList','BulletedList','Bold', 'Italic','Underline'] },
		{ name: 'links', items: [ 'Link' ,'Unlink'] },
		{ name: 'insert', items: [ 'Table' ] },
		{ name: 'tools', items: [ 'Maximize' ] },
		{ name: 'document', items: [ 'Source' ] },
	   ]};
	   
	   
	  this.model = new Downloadable('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''); 
	}

	ngOnInit() {
	}
	  
  	onSubmit() {
	
		 var error_flag = 0;
		 this.errors.thumbnail_image = '';
		   if(CustomValidator.emptyValidation(this.selectedFile)===false){
		     this.errors.thumbnail_image = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.imageExtensionValidation(this.selectedFile)===false){
			     this.errors.thumbnail_image = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }
		   
		 this.errors.pdf_file = '';
		   if(CustomValidator.emptyValidation(this.pdfFile)===false){
		     this.errors.pdf_file = 'Thumbnail image is required'; 
		      error_flag = 1;
		   }else{
		       if(CustomValidator.pdfExtensionValidation(this.pdfFile,'pdf')===false){
			     this.errors.pdf_file = 'Wrong format file.'; 
		          error_flag = 1;
			   }
		   }  
		   
		   
		   
		   
		if(error_flag ==1){
			  return false;
		}
	
	
	
	    this.data.api_type 			    = 	'Login';	
	    this.data.createdby             = localStorage.getItem("UserName");
		this.data.PageTitle 			= 	this.model.page_title;
	    this.data.PageMetaDescription 	= 	this.model.page_description;
        this.data.PageKeywords 			= 	this.model.page_keywords;
	    this.data.PageName 			    = 	this.model.page_name;			
		this.data.PageID 		        = 	this.model.page_id;
        this.data.CustomTags 			= 	this.model.page_tags;			
 		this.data.FeaturedDownload  	= 	'no';
        if(this.model.featured===true){		
		  this.data.FeaturedDownload 	= 	'yes';	
		}
		this.data.ThumbnailImage 		= 	btoa(this.selectedFile);	
		this.data.ThumbnailImageTooltip 		= 	this.model.thumb_title;	
		this.data.ThumbnailImageAlt 			= 	this.model.thumb_alt;	
		this.data.CreatedDate 			= 	this.model.creation_date;	
		this.data.Title 			    = 	this.model.post_title;	
		this.data.SubTitle  			= 	this.model.sub_title;	
		this.data.ShortDescription 		= 	this.model.short_description;	
		this.data.Content    			= 	this.model.content;	
		this.data.PDF 		            = 	btoa(this.pdfFile);
		this.data.DownloadableTitle  	= 	this.model.downloadable_title;	
		this.data.DownloadableLinkText  = 	this.model.downloadable_link;	
		
        //console.warn(this.data); return false;
		
		this.Create();
	  }  
  
  Create() {
	this.rest.AddHubDownloadable(this.data).subscribe(response => {
		if(response.error==1){
			this.errors 	=	response.error;
			console.log(this.errors);
		}else{
			console.log(response.msg);
			this.router.navigate(['/dashboard']);
		}

	}, error => {
			alert("Server Busy, Please try again later.");
		});
  }
  
  	  onFileSelected(event){
         this.selectedFile = event.target.files[0];
	     $('#image-1').html(this.selectedFile.name);
	  }
	  
	  onPdfSelected(event){
         this.pdfFile = event.target.files[0];
	     $('#pdf-1').html(this.pdfFile.name);
	  }


}
